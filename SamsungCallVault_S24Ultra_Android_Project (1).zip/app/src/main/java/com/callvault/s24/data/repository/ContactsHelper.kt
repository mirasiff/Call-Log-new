package com.callvault.s24.data.repository

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.ContactsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

data class DeviceContact(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val isStarred: Boolean = false
)

object ContactsHelper {
    @SuppressLint("Range")
    suspend fun loadAllContacts(context: Context): List<DeviceContact> = withContext(Dispatchers.IO) {
        val list = mutableListOf<DeviceContact>()
        val seen = HashSet<String>()
        runCatching {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.STARRED
                ),
                null,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val id = cursor.getString(0) ?: ""
                    val name = cursor.getString(1) ?: "Unknown"
                    val number = cursor.getString(2)?.trim() ?: ""
                    val starred = cursor.getInt(3) == 1
                    val key = "$name|$number"
                    if (number.isNotBlank() && seen.add(key)) {
                        list.add(DeviceContact(id, name, number, starred))
                    }
                }
            }
        }
        list
    }

    fun isNumberInContacts(context: Context, rawNumber: String): Boolean {
        return runCatching {
            val uri = android.net.Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                android.net.Uri.encode(rawNumber)
            )
            context.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)
                ?.use { it.moveToFirst() } ?: false
        }.getOrDefault(false)
    }

    @Suppress("DEPRECATION")
    fun getAppSigningSha1(context: Context): String {
        return runCatching {
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNING_CERTIFICATES
                )
            } else {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNATURES
                )
            }
            val sigBytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
            } else {
                info.signatures?.firstOrNull()?.toByteArray()
            } ?: return "Unavailable"

            val digest = MessageDigest.getInstance("SHA-1").digest(sigBytes)
            digest.joinToString(":") { "%02X".format(it) }
        }.getOrElse { "Unavailable" }
    }
}
