package com.callvault.s24

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.ui.MainViewModel
import com.callvault.s24.ui.screens.AnalyticsDashboardScreen
import com.callvault.s24.ui.screens.CallDetailBottomSheet
import com.callvault.s24.ui.screens.CallRecordingsScreen
import com.callvault.s24.ui.screens.ContactTimelineSheet
import com.callvault.s24.ui.screens.ContactsListScreen
import com.callvault.s24.ui.screens.SettingsAndBackupSheet
import com.callvault.s24.ui.screens.T9DialPadSheet
import com.callvault.s24.ui.screens.UnlimitedCallLogScreen
import com.callvault.s24.ui.theme.CallVaultTheme
import com.callvault.s24.ui.theme.SamsungGreenCall
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import com.google.api.services.drive.DriveScopes

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            CallVaultTheme {
                var currentTab by remember { mutableIntStateOf(0) }
                var showDialPad by remember { mutableStateOf(false) }
                var showSettingsSheet by remember { mutableStateOf(false) }
                var selectedCall by remember { mutableStateOf<CallLogEntry?>(null) }
                var selectedContactHistory by remember { mutableStateOf<Pair<String, String>?>(null) }
                val snackbarHostState = remember { SnackbarHostState() }

                val calls by viewModel.filteredCallLogs.collectAsState()
                val totalCount by viewModel.totalCallCount.collectAsState()
                val contacts by viewModel.contacts.collectAsState()
                val recordedCalls by viewModel.recordedCalls.collectAsState()
                val summaryStats by viewModel.summaryStats.collectAsState()
                val contactStats by viewModel.contactAnalytics.collectAsState()
                val settings by viewModel.settings.collectAsState()
                val searchQuery by viewModel.searchQuery.collectAsState()
                val callTypeFilter by viewModel.callTypeFilter.collectAsState()
                val onlyRecorded by viewModel.onlyRecordedFilter.collectAsState()
                val simFilter by viewModel.simFilter.collectAsState()
                val starredOnly by viewModel.starredRecordingsOnly.collectAsState()
                val analyticsRangeDays by viewModel.analyticsRangeDays.collectAsState()
                val statusBanner by viewModel.statusBanner.collectAsState()
                val audioState by viewModel.audioState.collectAsState()
                val availableBackups by viewModel.availableBackups.collectAsState()
                val blockedNumbers by viewModel.blockedNumbers.collectAsState()
                val speedDials by viewModel.speedDials.collectAsState()

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) {
                    viewModel.syncSystemCallLogNow()
                }

                val googleSignInLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                    try {
                        val account = task.getResult(ApiException::class.java)
                        if (!account?.email.isNullOrBlank()) {
                            viewModel.updateGoogleAccountEmail(account!!.email!!)
                        } else {
                            viewModel.showStatusMessage("Google Sign-In returned empty email.")
                        }
                    } catch (e: ApiException) {
                        val hint = if (e.statusCode == 10) {
                            "Google Drive OAuth not registered yet (Error 10). Copy SHA-1 in Settings & add an Android OAuth Client ID in Google Cloud Console."
                        } else {
                            "Google Sign-In failed (Code ${e.statusCode}): ${e.localizedMessage}"
                        }
                        viewModel.showStatusMessage(hint)
                    }
                }

                val dialerRoleLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) {
                    viewModel.syncSystemCallLogNow()
                }

                val restoreFileLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocument()
                ) { uri ->
                    if (uri != null) {
                        viewModel.restoreFromUri(uri)
                    }
                }

                LaunchedEffect(statusBanner) {
                    val msg = statusBanner
                    if (msg != null) {
                        snackbarHostState.showSnackbar(message = msg, actionLabel = "OK")
                        viewModel.dismissBanner()
                    }
                }

                LaunchedEffect(Unit) {
                    val perms = mutableListOf(
                        Manifest.permission.READ_CALL_LOG,
                        Manifest.permission.WRITE_CALL_LOG,
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.RECORD_AUDIO
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        perms.add(Manifest.permission.READ_PHONE_NUMBERS)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.READ_MEDIA_AUDIO)
                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
                    }
                    permissionLauncher.launch(perms.toTypedArray())
                }

                Scaffold(
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    floatingActionButton = {
                        if (currentTab == 0 || currentTab == 1) {
                            FloatingActionButton(
                                onClick = { showDialPad = true },
                                shape = CircleShape,
                                containerColor = SamsungGreenCall,
                                contentColor = Color.White
                            ) {
                                Icon(Icons.Default.Dialpad, contentDescription = "Open Keypad")
                            }
                        }
                    },
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = currentTab == 0,
                                onClick = { currentTab = 0 },
                                icon = { Icon(Icons.Default.Call, contentDescription = "Recents") },
                                label = { Text("Recents") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 1,
                                onClick = {
                                    currentTab = 1
                                    viewModel.loadContacts()
                                },
                                icon = { Icon(Icons.Default.Contacts, contentDescription = "Contacts") },
                                label = { Text("Contacts") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 2,
                                onClick = { currentTab = 2 },
                                icon = { Icon(Icons.Default.Analytics, contentDescription = "Analytics") },
                                label = { Text("Analytics") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 3,
                                onClick = { currentTab = 3 },
                                icon = { Icon(Icons.Default.GraphicEq, contentDescription = "Recordings") },
                                label = { Text("Recordings") }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                        when (currentTab) {
                            0 -> UnlimitedCallLogScreen(
                                calls = calls,
                                totalVaultCount = totalCount,
                                contacts = contacts,
                                settings = settings,
                                searchQuery = searchQuery,
                                onSearchChange = viewModel::setSearchQuery,
                                selectedFilter = callTypeFilter,
                                onFilterChange = viewModel::setCallTypeFilter,
                                onlyRecorded = onlyRecorded,
                                onToggleOnlyRecorded = viewModel::toggleOnlyRecordedFilter,
                                simFilter = simFilter,
                                onSimFilterChange = viewModel::setSimFilter,
                                onToggleCollapse = viewModel::updateCollapseConsecutiveCalls,
                                onLoadMore = viewModel::loadMoreCalls,
                                onSyncNow = viewModel::syncSystemCallLogNow,
                                onOpenSettings = {
                                    viewModel.refreshAvailableBackupSlots()
                                    showSettingsSheet = true
                                },
                                onSelectCall = { selectedCall = it }
                            )
                            1 -> ContactsListScreen(
                                contacts = contacts,
                                onOpenSettings = {
                                    viewModel.refreshAvailableBackupSlots()
                                    showSettingsSheet = true
                                },
                                onOpenHistory = { num, name -> selectedContactHistory = num to name }
                            )
                            2 -> AnalyticsDashboardScreen(
                                summary = summaryStats,
                                contactStats = contactStats,
                                selectedRangeDays = analyticsRangeDays,
                                onRangeChange = viewModel::setAnalyticsRangeDays,
                                onOpenSettings = {
                                    viewModel.refreshAvailableBackupSlots()
                                    showSettingsSheet = true
                                },
                                onOpenContactHistory = { num, name -> selectedContactHistory = num to name }
                            )
                            3 -> CallRecordingsScreen(
                                recordedCalls = recordedCalls,
                                settings = settings,
                                audioState = audioState,
                                starredOnly = starredOnly,
                                onToggleStarredOnly = viewModel::toggleStarredRecordingsOnly,
                                onTogglePlay = viewModel::togglePlayRecording,
                                onSeekAudio = viewModel::seekAudioTo,
                                onCycleSpeed = viewModel::cyclePlaybackSpeed,
                                onShareRecording = viewModel::shareRecordingFile,
                                onToggleStar = viewModel::toggleStarRecording,
                                onToggleAutoRecord = viewModel::updateAutoRecord,
                                onRescanSamsungRecordings = viewModel::syncSystemCallLogNow,
                                onOpenSettings = {
                                    viewModel.refreshAvailableBackupSlots()
                                    showSettingsSheet = true
                                }
                            )
                        }



                        if (showDialPad) {
                            T9DialPadSheet(
                                contacts = contacts,
                                speedDials = speedDials,
                                hapticsEnabled = settings.dialpadHapticsEnabled,
                                onDismiss = { showDialPad = false }
                            )
                        }

                        selectedCall?.let { call ->
                            val isFav = settings.favoriteNumbers.any { call.normalizedNumber.endsWith(it.takeLast(10)) }
                            CallDetailBottomSheet(
                                call = call,
                                audioState = audioState,
                                isFavorite = isFav,
                                onDismiss = { selectedCall = null },
                                onTogglePlay = viewModel::togglePlayRecording,
                                onSeekAudio = viewModel::seekAudioTo,
                                onCycleSpeed = viewModel::cyclePlaybackSpeed,
                                onShareRecording = viewModel::shareRecordingFile,
                                onToggleStarRecording = viewModel::toggleStarRecording,
                                onSaveNote = viewModel::saveCallNote,
                                onToggleFavorite = viewModel::toggleFavoriteNumber,
                                onBlockNumber = viewModel::blockNumber,
                                onOpenContactHistory = { num, name -> selectedContactHistory = num to name }
                            )
                        }

                        selectedContactHistory?.let { (num, title) ->
                            ContactTimelineSheet(
                                contactTitle = title,
                                normalizedNumber = num,
                                callsFlow = viewModel.observeHistoryForContact(num),
                                onDismiss = { selectedContactHistory = null },
                                onSelectCall = { selectedCall = it }
                            )
                        }

                        if (showSettingsSheet) {
                            SettingsAndBackupSheet(
                                settings = settings,
                                availableBackups = availableBackups,
                                blockedNumbers = blockedNumbers,
                                onDismiss = { showSettingsSheet = false },
                                onSavePhoneNumber = viewModel::updateRegisteredPhoneNumber,
                                onConnectGoogleAccount = {
                                    val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                                        .requestEmail()
                                        .requestScopes(Scope(DriveScopes.DRIVE_FILE))
                                        .build()
                                    val client = GoogleSignIn.getClient(this@MainActivity, gso)
                                    googleSignInLauncher.launch(client.signInIntent)
                                },
                                onToggleAutoBackup = viewModel::updateAutoBackupEnabled,
                                onBackupNow = viewModel::triggerImmediateBackup,
                                onRefreshBackups = viewModel::refreshAvailableBackupSlots,
                                onRestoreSlot = viewModel::restoreFromSlot,
                                onExportCsv = viewModel::exportAndShareCsv,
                                onExportJson = viewModel::exportAndShareJson,
                                onImportJsonFile = { restoreFileLauncher.launch(arrayOf("application/json", "*/*")) },
                                onToggleHideNotification = viewModel::updateHideRecordingNotification,
                                onSelectEngineMode = viewModel::updateRecordingEngineMode,
                                onSelectRecordingRule = viewModel::updateRecordingRule,
                                onToggleHaptics = viewModel::updateDialpadHaptics,
                                onUnblockNumber = viewModel::unblockNumber,
                                onRequestDefaultDialerRole = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        val roleManager = getSystemService(RoleManager::class.java)
                                        if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                                            dialerRoleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER))
                                        }
                                    } else {
                                        val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).apply {
                                            putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                                        }
                                        dialerRoleLauncher.launch(intent)
                                    }
                                },
                                onShowMessage = viewModel::showStatusMessage
                            )
                        }
                    }
                }
            }
        }
    }
}
