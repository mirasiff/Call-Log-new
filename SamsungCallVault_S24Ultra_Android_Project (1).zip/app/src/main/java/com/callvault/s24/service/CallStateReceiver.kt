package com.callvault.s24.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import com.callvault.s24.data.local.AppDatabase
import com.callvault.s24.data.local.AppPreferences
import com.callvault.s24.data.repository.CallLogRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class CallStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state == TelephonyManager.EXTRA_STATE_IDLE || intent.action == Intent.ACTION_BOOT_COMPLETED) {
            CoroutineScope(Dispatchers.IO).launch {
                delay(2500L)
                val dao = AppDatabase.getInstance(context).callLogDao()
                val repo = CallLogRepository(context, dao)
                val prefs = AppPreferences(context).settingsFlow.first()
                repo.syncSystemCallLogToUnlimitedVault(prefs.registeredPhoneNumber)
            }
        }
    }
}
