package com.callvault.s24.service

import android.telecom.Call
import android.telecom.CallScreeningService
import com.callvault.s24.data.local.AppDatabase
import com.callvault.s24.data.repository.CallLogRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Silently rejects incoming calls from numbers on the user's Blocked Numbers list
 * with zero battery impact (only invoked by Android Telecom on incoming calls).
 */
class VaultCallScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        val number = callDetails.handle?.schemeSpecificPart ?: ""
        CoroutineScope(Dispatchers.IO).launch {
            val dao = AppDatabase.getInstance(applicationContext).callLogDao()
            val repo = CallLogRepository(applicationContext, dao)
            val normalized = repo.normalizePhoneNumber(number)
            val isBlocked = dao.isNumberBlocked(normalized)

            val response = if (isBlocked) {
                CallResponse.Builder()
                    .setDisallowCall(true)
                    .setRejectCall(true)
                    .setSkipCallLog(false)
                    .setSkipNotification(true)
                    .build()
            } else {
                CallResponse.Builder().build()
            }
            respondToCall(callDetails, response)
        }
    }
}
