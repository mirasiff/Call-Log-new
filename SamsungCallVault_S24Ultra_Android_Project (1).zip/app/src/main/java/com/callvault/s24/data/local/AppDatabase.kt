package com.callvault.s24.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.callvault.s24.data.model.BlockedNumberEntity
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.SpeedDialEntity

@Database(
    entities = [CallLogEntry::class, BlockedNumberEntity::class, SpeedDialEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun callLogDao(): CallLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "callvault_unlimited_s24.db"
                )
                    .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING) // Fast concurrent reads for 100k+ logs
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
