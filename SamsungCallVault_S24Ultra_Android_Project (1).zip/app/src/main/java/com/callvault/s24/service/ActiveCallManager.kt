package com.callvault.s24.service

import android.content.Context
import android.media.AudioManager
import android.telecom.Call
import android.telecom.VideoProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ActiveCallUiState(
    val hasActiveCall: Boolean = false,
    val phoneNumber: String = "",
    val contactName: String? = null,
    val callState: Int = Call.STATE_DISCONNECTED,
    val connectTimeMillis: Long = 0L,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = false,
    val isOnHold: Boolean = false,
    val isRecording: Boolean = false
)

object ActiveCallManager {
    private var currentCall: Call? = null
    private var inCallServiceRef: VaultInCallService? = null

    private val _uiState = MutableStateFlow(ActiveCallUiState())
    val uiState: StateFlow<ActiveCallUiState> = _uiState.asStateFlow()

    fun attachService(service: VaultInCallService) {
        inCallServiceRef = service
    }

    fun updateCall(call: Call?, isRecording: Boolean = _uiState.value.isRecording) {
        currentCall = call
        if (call == null) {
            _uiState.value = ActiveCallUiState()
            return
        }
        val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
        val name = call.details?.callerDisplayName?.takeIf { it.isNotBlank() }
        val state = call.details?.state ?: Call.STATE_NEW
        val connectTime = call.details?.connectTimeMillis ?: 0L

        _uiState.value = _uiState.value.copy(
            hasActiveCall = state != Call.STATE_DISCONNECTED,
            phoneNumber = number,
            contactName = name,
            callState = state,
            connectTimeMillis = connectTime,
            isOnHold = state == Call.STATE_HOLDING,
            isRecording = isRecording
        )
    }

    fun answerCall() {
        currentCall?.answer(VideoProfile.STATE_AUDIO_ONLY)
    }

    fun disconnectCall() {
        currentCall?.disconnect()
    }

    fun toggleHold() {
        val call = currentCall ?: return
        if (call.details?.state == Call.STATE_HOLDING) {
            call.unhold()
        } else {
            call.hold()
        }
    }

    fun toggleMute(context: Context) {
        val nextMuted = !_uiState.value.isMuted
        inCallServiceRef?.setMuted(nextMuted)
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        audioManager?.isMicrophoneMute = nextMuted
        _uiState.value = _uiState.value.copy(isMuted = nextMuted)
    }

    fun toggleSpeaker(context: Context) {
        val nextSpeaker = !_uiState.value.isSpeakerOn
        val route = if (nextSpeaker) {
            android.telecom.CallAudioState.ROUTE_SPEAKER
        } else {
            android.telecom.CallAudioState.ROUTE_EARPIECE
        }
        inCallServiceRef?.setAudioRoute(route)
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        @Suppress("DEPRECATION")
        audioManager?.isSpeakerphoneOn = nextSpeaker
        _uiState.value = _uiState.value.copy(isSpeakerOn = nextSpeaker)
    }

    fun sendDtmf(digit: Char) {
        currentCall?.playDtmfTone(digit)
        currentCall?.stopDtmfTone()
    }
}
