package com.callvault.s24

import android.app.Application
import com.callvault.s24.worker.AutoBackupWorker

class CallVaultApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AutoBackupWorker.schedulePeriodicBackup(this, intervalHours = 12L)
    }
}
