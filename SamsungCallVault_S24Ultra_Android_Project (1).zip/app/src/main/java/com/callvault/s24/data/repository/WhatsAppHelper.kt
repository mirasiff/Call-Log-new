package com.callvault.s24.data.repository

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract

object WhatsAppHelper {

    /**
     * Formats phone numbers cleanly for WhatsApp wa.me links.
     * Preserves international '+' codes, strips spaces/dashes, and handles local 10-digit numbers.
     */
    private fun formatForWhatsApp(rawNumber: String): String {
        val digitsOnly = rawNumber.replace(Regex("[^0-9+]"), "")
        return when {
            digitsOnly.startsWith("+") -> digitsOnly.removePrefix("+")
            digitsOnly.startsWith("00") -> digitsOnly.removePrefix("00")
            digitsOnly.length == 10 -> "91$digitsOnly" // Default India country code for 10-digit local numbers
            digitsOnly.startsWith("0") && digitsOnly.length == 11 -> "91${digitsOnly.drop(1)}"
            else -> digitsOnly
        }
    }

    fun openWhatsAppChat(context: Context, rawNumber: String): Boolean {
        val waNumber = formatForWhatsApp(rawNumber)
        if (waNumber.isBlank()) return false

        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$waNumber")
        val packagesToTry = listOf("com.whatsapp", "com.whatsapp.w4b")

        for (pkg in packagesToTry) {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage(pkg)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (runCatching { context.startActivity(intent) }.isSuccess) {
                return true
            }
        }

        // Fallback to browser/chooser if package check fails
        return runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        }.isSuccess
    }

    /**
     * Queries Android ContactsContract for WhatsApp's VoIP call MIME entry so saved contacts
     * launch directly into a WhatsApp Voice Call. Falls back to WhatsApp Chat if unsaved.
     */
    @SuppressLint("Range")
    fun startWhatsAppVoiceCall(context: Context, rawNumber: String): Boolean {
        val targetLast10 = rawNumber.replace(Regex("[^0-9]"), "").takeLast(10)
        if (targetLast10.length >= 7) {
            runCatching {
                val projection = arrayOf(
                    ContactsContract.Data._ID,
                    ContactsContract.Data.DATA1,
                    ContactsContract.Data.DATA3
                )
                val selection = "${ContactsContract.Data.MIMETYPE} = ?"
                val selectionArgs = arrayOf("vnd.android.cursor.item/vnd.com.whatsapp.voip.call")

                context.contentResolver.query(
                    ContactsContract.Data.CONTENT_URI,
                    projection,
                    selection,
                    selectionArgs,
                    null
                )?.use { cursor ->
                    while (cursor.moveToNext()) {
                        val dataId = cursor.getLong(0)
                        val data1 = cursor.getString(1) ?: ""
                        val data1Digits = data1.replace(Regex("[^0-9]"), "")
                        if (data1Digits.endsWith(targetLast10)) {
                            val callUri = Uri.parse("content://com.android.contacts/data/$dataId")
                            val callIntent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(callUri, "vnd.android.cursor.item/vnd.com.whatsapp.voip.call")
                                setPackage("com.whatsapp")
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            if (runCatching { context.startActivity(callIntent) }.isSuccess) {
                                return true
                            }
                        }
                    }
                }
            }
        }
        // Graceful fallback: open WhatsApp chat where the Call button is 1 tap away
        return openWhatsAppChat(context, rawNumber)
    }
}
