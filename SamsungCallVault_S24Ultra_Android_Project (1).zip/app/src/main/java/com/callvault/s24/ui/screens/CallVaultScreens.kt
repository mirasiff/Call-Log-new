package com.callvault.s24.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CallLog
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.callvault.s24.backup.RemotePhoneBackupSlot
import com.callvault.s24.data.local.UserSettings
import com.callvault.s24.data.model.BlockedNumberEntity
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.CallSummaryStats
import com.callvault.s24.data.model.ContactAnalyticsItem
import com.callvault.s24.data.model.RecordingEngineMode
import com.callvault.s24.data.model.RecordingRule
import com.callvault.s24.data.model.SpeedDialEntity
import com.callvault.s24.data.repository.ContactsHelper
import com.callvault.s24.data.repository.DeviceContact
import com.callvault.s24.data.repository.WhatsAppHelper
import com.callvault.s24.ui.AudioPlayerState
import com.callvault.s24.ui.theme.SamsungBlue
import com.callvault.s24.ui.theme.SamsungGoldStar
import com.callvault.s24.ui.theme.SamsungGreenCall
import com.callvault.s24.ui.theme.SamsungOrangeMessage
import com.callvault.s24.ui.theme.SamsungPurpleRecord
import com.callvault.s24.ui.theme.SamsungRedMissed
import com.callvault.s24.ui.theme.WhatsAppGreen
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

fun placeCallIntent(context: Context, phoneNumber: String) {
    val uri = Uri.parse("tel:${Uri.encode(phoneNumber)}")
    val callIntent = Intent(Intent.ACTION_CALL, uri).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    runCatching { context.startActivity(callIntent) }.onFailure {
        val dialIntent = Intent(Intent.ACTION_DIAL, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(dialIntent)
    }
}

fun openMessagesIntent(context: Context, phoneNumber: String) {
    val uri = Uri.parse("smsto:${Uri.encode(phoneNumber)}")
    val smsIntent = Intent(Intent.ACTION_SENDTO, uri).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    runCatching { context.startActivity(smsIntent) }
}

fun formatDurationHuman(seconds: Long): String {
    if (seconds <= 0L) return "0s"
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return buildString {
        if (hrs > 0) append("${hrs}h ")
        if (mins > 0) append("${mins}m ")
        if (secs > 0 || isEmpty()) append("${secs}s")
    }.trim()
}

fun formatTimeOnly(epochMillis: Long): String {
    val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
    return sdf.format(Date(epochMillis))
}

fun formatTimestamp(epochMillis: Long): String {
    if (epochMillis <= 0L) return "Never"
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    return sdf.format(Date(epochMillis))
}

fun formatDateHeader(epochMillis: Long): String {
    val cal = Calendar.getInstance()
    val todayDay = cal.get(Calendar.DAY_OF_YEAR)
    val todayYear = cal.get(Calendar.YEAR)

    cal.timeInMillis = epochMillis
    val targetDay = cal.get(Calendar.DAY_OF_YEAR)
    val targetYear = cal.get(Calendar.YEAR)

    return when {
        targetYear == todayYear && targetDay == todayDay -> "Today"
        targetYear == todayYear && targetDay == todayDay - 1 -> "Yesterday"
        else -> SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(Date(epochMillis))
    }
}

fun formatAudioMillis(ms: Int): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    return String.format("%d:%02d", totalSec / 60, totalSec % 60)
}

private fun nameMatchesT9(name: String, digits: String): Boolean {
    if (digits.isBlank()) return false
    val t9 = name.lowercase().map { ch ->
        when (ch) {
            'a', 'b', 'c' -> '2'
            'd', 'e', 'f' -> '3'
            'g', 'h', 'i' -> '4'
            'j', 'k', 'l' -> '5'
            'm', 'n', 'o' -> '6'
            'p', 'q', 'r', 's' -> '7'
            't', 'u', 'v' -> '8'
            'w', 'x', 'y', 'z' -> '9'
            else -> ch
        }
    }.joinToString("")
    return t9.contains(digits)
}

/**
 * Samsung-Style T9 Dial Pad with Speed Dial (long press 2..9) & Haptic Feedback
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun T9DialPadSheet(
    contacts: List<DeviceContact>,
    speedDials: List<SpeedDialEntity>,
    hapticsEnabled: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var dialedNumber by remember { mutableStateOf("") }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val matchedContacts = remember(dialedNumber, contacts) {
        if (dialedNumber.isBlank()) emptyList()
        else contacts.filter {
            it.phoneNumber.replace(Regex("[^0-9+]"), "").contains(dialedNumber) ||
                nameMatchesT9(it.name, dialedNumber)
        }.take(3)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (matchedContacts.isNotEmpty()) {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(matchedContacts) { contact ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().clickable {
                                placeCallIntent(context, contact.phoneNumber)
                                onDismiss()
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(contact.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(contact.phoneNumber, style = MaterialTheme.typography.bodySmall)
                                }
                                Icon(Icons.Default.Call, contentDescription = "Call", tint = SamsungGreenCall)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            Text(
                text = dialedNumber.ifEmpty { "Enter number or T9 name" },
                fontSize = if (dialedNumber.isEmpty()) 17.sp else 32.sp,
                fontWeight = if (dialedNumber.isEmpty()) FontWeight.Normal else FontWeight.Bold,
                color = if (dialedNumber.isEmpty()) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
                else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(14.dp))

            val dialRows = listOf(
                listOf("1" to "", "2" to "ABC", "3" to "DEF"),
                listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
                listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
                listOf("*" to "", "0" to "+", "#" to "")
            )

            dialRows.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    row.forEach { (digit, letters) ->
                        val speedSlot = speedDials.firstOrNull { it.digit.toString() == digit }
                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                            modifier = Modifier
                                .size(width = 88.dp, height = 62.dp)
                                .combinedClickable(
                                    onClick = {
                                        if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        dialedNumber += digit
                                    },
                                    onLongClick = {
                                        if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        if (digit == "0") {
                                            dialedNumber += "+"
                                        } else if (speedSlot != null) {
                                            placeCallIntent(context, speedSlot.phoneNumber)
                                            onDismiss()
                                        }
                                    }
                                )
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(digit, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                if (speedSlot != null) {
                                    Text(
                                        speedSlot.contactName.take(7),
                                        fontSize = 9.sp,
                                        color = SamsungBlue,
                                        fontWeight = FontWeight.Bold
                                    )
                                } else if (letters.isNotEmpty()) {
                                    Text(letters, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (dialedNumber.isNotBlank()) {
                            openMessagesIntent(context, dialedNumber)
                            onDismiss()
                        }
                    },
                    enabled = dialedNumber.isNotBlank()
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Message,
                        contentDescription = "Message",
                        tint = if (dialedNumber.isNotBlank()) SamsungOrangeMessage else Color.Gray,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(SamsungGreenCall)
                        .clickable {
                            if (dialedNumber.isNotBlank()) {
                                placeCallIntent(context, dialedNumber)
                                onDismiss()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Call, contentDescription = "Dial", tint = Color.White, modifier = Modifier.size(30.dp))
                }

                IconButton(
                    onClick = {
                        if (dialedNumber.isNotEmpty()) dialedNumber = dialedNumber.dropLast(1)
                    },
                    enabled = dialedNumber.isNotEmpty()
                ) {
                    Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = "Backspace", modifier = Modifier.size(26.dp))
                }
            }
        }
    }
}

/**
 * Progressive Disclosure: Clean Bottom Sheet when tapping any call card
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallDetailBottomSheet(
    call: CallLogEntry,
    audioState: AudioPlayerState,
    isFavorite: Boolean,
    onDismiss: () -> Unit,
    onTogglePlay: (String) -> Unit,
    onSeekAudio: (Int) -> Unit,
    onCycleSpeed: () -> Unit,
    onShareRecording: (String) -> Unit,
    onToggleStarRecording: (CallLogEntry) -> Unit,
    onSaveNote: (Long, String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onBlockNumber: (String) -> Unit,
    onOpenContactHistory: (String, String) -> Unit
) {
    val context = LocalContext.current
    var noteText by remember(call.id) { mutableStateOf(call.notes ?: "") }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = call.contactName ?: call.phoneNumber,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${call.phoneNumber} • ${call.simSlotLabel ?: "SIM 1"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Text(
                        text = "${formatTimestamp(call.timestamp)} • ${formatDurationHuman(call.durationSeconds)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = SamsungBlue
                    )
                }
                IconButton(onClick = { onToggleFavorite(call.phoneNumber) }) {
                    Icon(
                        if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) SamsungGoldStar else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // Primary Action Row (Call & SMS)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { placeCallIntent(context, call.phoneNumber) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SamsungGreenCall)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call")
                }
                OutlinedButton(
                    onClick = { openMessagesIntent(context, call.phoneNumber) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Message, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Message")
                }
            }

            // WhatsApp Integration Row (WhatsApp Call & WhatsApp Chat)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { WhatsAppHelper.startWhatsAppVoiceCall(context, call.phoneNumber) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WA Call", maxLines = 1)
                }
                OutlinedButton(
                    onClick = { WhatsAppHelper.openWhatsAppChat(context, call.phoneNumber) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(18.dp), tint = WhatsAppGreen)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WA Chat", color = WhatsAppGreen, maxLines = 1)
                }
            }

            // Interactive Seekable Audio Player (if recorded)
            if (call.recordingFilePath != null) {
                val isThisTrack = audioState.playingPath == call.recordingFilePath
                Surface(
                    color = SamsungPurpleRecord.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { onTogglePlay(call.recordingFilePath) }) {
                                    Icon(
                                        if (isThisTrack && audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = SamsungPurpleRecord,
                                        modifier = Modifier.size(30.dp)
                                    )
                                }
                                Column {
                                    Text("Call Recording", fontWeight = FontWeight.Bold, color = SamsungPurpleRecord)
                                    Text(
                                        text = if (call.recordingSource == "SAMSUNG_NATIVE") "Samsung Native Audio" else "CallVault Recorder",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                            Row {
                                TextButton(onClick = onCycleSpeed) {
                                    Text("${audioState.speed}x", fontWeight = FontWeight.Bold, color = SamsungPurpleRecord)
                                }
                                IconButton(onClick = { onToggleStarRecording(call) }) {
                                    Icon(
                                        if (call.isStarredRecording) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "Star Recording",
                                        tint = if (call.isStarredRecording) SamsungGoldStar else SamsungPurpleRecord
                                    )
                                }
                                IconButton(onClick = { onShareRecording(call.recordingFilePath) }) {
                                    Icon(Icons.Default.Share, contentDescription = "Share Audio", tint = SamsungPurpleRecord)
                                }
                            }
                        }

                        if (isThisTrack) {
                            Slider(
                                value = audioState.positionMs.toFloat(),
                                onValueChange = { onSeekAudio(it.toInt()) },
                                valueRange = 0f..audioState.durationMs.coerceAtLeast(1).toFloat()
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(formatAudioMillis(audioState.positionMs), style = MaterialTheme.typography.labelSmall)
                                Text(formatAudioMillis(audioState.durationMs), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            // Searchable Call Note
            OutlinedTextField(
                value = noteText,
                onValueChange = { noteText = it },
                label = { Text("Call Note (searchable in 10-year vault)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                trailingIcon = {
                    TextButton(onClick = { onSaveNote(call.id, noteText) }) {
                        Text("Save")
                    }
                }
            )

            // Secondary Tools Row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onOpenContactHistory(call.normalizedNumber, call.contactName ?: call.phoneNumber)
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Full History", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = {
                        onBlockNumber(call.phoneNumber)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp), tint = SamsungRedMissed)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Block", fontSize = 12.sp, color = SamsungRedMissed)
                }
            }
        }
    }
}

/**
 * Full Chronological Contact Timeline Sheet (10-Year Per-Person History)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactTimelineSheet(
    contactTitle: String,
    normalizedNumber: String,
    callsFlow: Flow<List<CallLogEntry>>,
    onDismiss: () -> Unit,
    onSelectCall: (CallLogEntry) -> Unit
) {
    val history by callsFlow.collectAsState(initial = emptyList())
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 560.dp)
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            Text(contactTitle, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                text = "${history.size} total calls • Total talk: ${formatDurationHuman(history.sumOf { it.durationSeconds })}",
                style = MaterialTheme.typography.bodySmall,
                color = SamsungBlue
            )
            Spacer(modifier = Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history, key = { it.id }) { item ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().clickable {
                            onDismiss()
                            onSelectCall(item)
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(formatTimestamp(item.timestamp), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                if (!item.notes.isNullOrBlank()) {
                                    Text("Note: ${item.notes}", style = MaterialTheme.typography.bodySmall, color = SamsungBlue)
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (item.recordingFilePath != null) {
                                    Icon(Icons.Default.Mic, contentDescription = null, tint = SamsungPurpleRecord, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                }
                                Text(formatDurationHuman(item.durationSeconds), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Tab 1: Clean One UI Recents Screen (Viewing Area + Thumb-Zone Controls + Date Headers + Favorites)
 */
@Composable
fun UnlimitedCallLogScreen(
    calls: List<CallLogEntry>,
    totalVaultCount: Int,
    contacts: List<DeviceContact>,
    settings: UserSettings,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    selectedFilter: Int,
    onFilterChange: (Int) -> Unit,
    onlyRecorded: Boolean,
    onToggleOnlyRecorded: () -> Unit,
    simFilter: String,
    onSimFilterChange: (String) -> Unit,
    onToggleCollapse: (Boolean) -> Unit,
    onLoadMore: () -> Unit,
    onSyncNow: () -> Unit,
    onOpenSettings: () -> Unit,
    onSelectCall: (CallLogEntry) -> Unit
) {
    val context = LocalContext.current

    // Optional consecutive call grouping
    val displayList = remember(calls, settings.collapseConsecutiveCalls) {
        if (!settings.collapseConsecutiveCalls) {
            calls.map { it to 1 }
        } else {
            val grouped = mutableListOf<Pair<CallLogEntry, Int>>()
            for (c in calls) {
                val last = grouped.lastOrNull()
                if (last != null && last.first.normalizedNumber == c.normalizedNumber &&
                    formatDateHeader(last.first.timestamp) == formatDateHeader(c.timestamp)
                ) {
                    grouped[grouped.lastIndex] = last.first to (last.second + 1)
                } else {
                    grouped.add(c to 1)
                }
            }
            grouped
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        // One UI Viewing Area (Clean & Compact)
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("CallVault", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    text = "$totalVaultCount calls preserved • Unlimited 10+ yr vault",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                )
            }
            Row {
                IconButton(onClick = onSyncNow) {
                    Icon(Icons.Default.Refresh, contentDescription = "Sync")
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings & Backup")
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search name, number, or call notes...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(24.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val filters = listOf(
                0 to "All",
                CallLog.Calls.INCOMING_TYPE to "Incoming",
                CallLog.Calls.OUTGOING_TYPE to "Outgoing",
                CallLog.Calls.MISSED_TYPE to "Missed"
            )
            items(filters) { (typeCode, label) ->
                FilterChip(selected = selectedFilter == typeCode, onClick = { onFilterChange(typeCode) }, label = { Text(label) })
            }
            item {
                FilterChip(
                    selected = onlyRecorded,
                    onClick = onToggleOnlyRecorded,
                    label = { Text("Recorded") },
                    leadingIcon = { Icon(Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(15.dp)) }
                )
            }
            item {
                FilterChip(
                    selected = simFilter != "ALL",
                    onClick = {
                        val next = when (simFilter) {
                            "ALL" -> "SIM 1"
                            "SIM 1" -> "SIM 2"
                            else -> "ALL"
                        }
                        onSimFilterChange(next)
                    },
                    label = { Text(if (simFilter == "ALL") "All SIMs" else simFilter) }
                )
            }
            item {
                FilterChip(
                    selected = settings.collapseConsecutiveCalls,
                    onClick = { onToggleCollapse(!settings.collapseConsecutiveCalls) },
                    label = { Text("Group Repeat") }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            var lastDateHeader = ""
            displayList.forEach { (entry, repeatCount) ->
                val dateHeader = formatDateHeader(entry.timestamp)
                if (dateHeader != lastDateHeader) {
                    lastDateHeader = dateHeader
                    item(key = "hdr_${dateHeader}_${entry.id}") {
                        Text(
                            text = dateHeader,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 8.dp, bottom = 2.dp, start = 4.dp)
                        )
                    }
                }
                item(key = entry.id) {
                    CleanSwipeableCallRow(
                        entry = entry,
                        repeatCount = repeatCount,
                        onCall = { placeCallIntent(context, entry.phoneNumber) },
                        onMessage = { openMessagesIntent(context, entry.phoneNumber) },
                        onClick = { onSelectCall(entry) }
                    )
                }
            }

            if (calls.size >= 500) {
                item(key = "load_more") {
                    TextButton(onClick = onLoadMore, modifier = Modifier.fillMaxWidth()) {
                        Text("Load Older Calls from 10-Year Vault...")
                    }
                }
            }
        }
    }
}

@Composable
fun CleanSwipeableCallRow(
    entry: CallLogEntry,
    repeatCount: Int,
    onCall: () -> Unit,
    onMessage: () -> Unit,
    onClick: () -> Unit
) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    val swipeThreshold = 200f

    val bgColor by animateColorAsState(
        targetValue = when {
            offsetX > 50f -> SamsungGreenCall.copy(alpha = 0.88f)
            offsetX < -50f -> SamsungOrangeMessage.copy(alpha = 0.88f)
            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
        },
        label = "swipeBg"
    )

    Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bgColor)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Call, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Call", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Message", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.AutoMirrored.Filled.Message, contentDescription = null, tint = Color.White)
            }
        }

        Card(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), 0) }
                .fillMaxWidth()
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        offsetX = (offsetX + delta).coerceIn(-300f, 300f)
                    },
                    onDragStopped = {
                        when {
                            offsetX >= swipeThreshold -> onCall()
                            offsetX <= -swipeThreshold -> onMessage()
                        }
                        offsetX = 0f
                    }
                )
                .clickable(onClick = onClick),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp).fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val (icon, tint) = when (entry.callType) {
                    CallLog.Calls.INCOMING_TYPE -> Icons.AutoMirrored.Filled.CallReceived to SamsungBlue
                    CallLog.Calls.OUTGOING_TYPE -> Icons.AutoMirrored.Filled.CallMade to SamsungGreenCall
                    CallLog.Calls.MISSED_TYPE -> Icons.AutoMirrored.Filled.CallMissed to SamsungRedMissed
                    CallLog.Calls.REJECTED_TYPE -> Icons.Default.Block to SamsungRedMissed
                    else -> Icons.Default.Call to SamsungBlue
                }

                Box(
                    modifier = Modifier.size(42.dp).clip(CircleShape).background(tint.copy(alpha = 0.13f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val baseTitle = entry.contactName ?: entry.phoneNumber
                        Text(
                            text = if (repeatCount > 1) "$baseTitle ($repeatCount)" else baseTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (entry.recordingFilePath != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.Default.Mic, contentDescription = "Recorded", tint = SamsungPurpleRecord, modifier = Modifier.size(15.dp))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = formatTimeOnly(entry.timestamp),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        if (!entry.simSlotLabel.isNullOrBlank()) {
                            Text(
                                text = " • ${entry.simSlotLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }
                        if (!entry.notes.isNullOrBlank()) {
                            Text(
                                text = " • 📝",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = formatDurationHuman(entry.durationSeconds),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = tint
                    )
                    if (entry.wasDisconnectedAbnormally) {
                        Text(
                            text = entry.disconnectCauseLabel,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = SamsungRedMissed
                        )
                    }
                }
            }
        }
    }
}

/**
 * Tab 2: Clean Contacts Screen
 */
@Composable
fun ContactsListScreen(
    contacts: List<DeviceContact>,
    onOpenSettings: () -> Unit,
    onOpenHistory: (String, String) -> Unit
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    val filtered = remember(query, contacts) {
        if (query.isBlank()) contacts
        else contacts.filter { it.name.contains(query, ignoreCase = true) || it.phoneNumber.contains(query) }
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Contacts", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("${contacts.size} contacts synced", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Settings")
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search contacts...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(24.dp)
        )
        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            items(filtered, key = { "${it.id}_${it.phoneNumber}" }) { contact ->
                ElevatedCard(
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().clickable {
                        onOpenHistory(contact.phoneNumber, contact.name)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier.size(40.dp).clip(CircleShape).background(SamsungBlue.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = SamsungBlue)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(contact.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(contact.phoneNumber, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Row {
                            IconButton(onClick = { placeCallIntent(context, contact.phoneNumber) }) {
                                Icon(Icons.Default.Call, contentDescription = "Call", tint = SamsungGreenCall)
                            }
                            IconButton(onClick = { openMessagesIntent(context, contact.phoneNumber) }) {
                                Icon(Icons.AutoMirrored.Filled.Message, contentDescription = "Message", tint = SamsungOrangeMessage)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Tab 3: Analytics Dashboard (With Per-Contact History Drilldown)
 */
@Composable
fun AnalyticsDashboardScreen(
    summary: CallSummaryStats,
    contactStats: List<ContactAnalyticsItem>,
    selectedRangeDays: Int,
    onRangeChange: (Int) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenContactHistory: (String, String) -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 96.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Call Analytics", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Tap any contact below for full timeline", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings")
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val ranges = listOf(0 to "All Time (10+ Yrs)", 365 to "1 Year", 90 to "90 Days", 30 to "30 Days", 7 to "7 Days")
                items(ranges) { (days, label) ->
                    FilterChip(selected = selectedRangeDays == days, onClick = { onRangeChange(days) }, label = { Text(label) })
                }
            }
        }

        item {
            ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Call Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(124.dp)) {
                            Canvas(modifier = Modifier.size(110.dp)) {
                                val total = summary.totalCalls.coerceAtLeast(1).toFloat()
                                val incSweep = (summary.incomingCalls / total) * 360f
                                val outSweep = (summary.outgoingCalls / total) * 360f
                                val misSweep = ((summary.missedCalls + summary.rejectedCalls) / total) * 360f
                                val strokeWidth = 26f
                                var startAngle = -90f
                                drawArc(SamsungBlue, startAngle, incSweep, false, style = Stroke(strokeWidth, cap = StrokeCap.Butt), size = Size(size.width, size.height), topLeft = Offset.Zero)
                                startAngle += incSweep
                                drawArc(SamsungGreenCall, startAngle, outSweep, false, style = Stroke(strokeWidth, cap = StrokeCap.Butt))
                                startAngle += outSweep
                                drawArc(SamsungRedMissed, startAngle, misSweep, false, style = Stroke(strokeWidth, cap = StrokeCap.Butt))
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${summary.totalCalls}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                Text("Calls", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            StatLegendRow("Outgoing", "${summary.outgoingCalls}", SamsungGreenCall)
                            StatLegendRow("Incoming", "${summary.incomingCalls}", SamsungBlue)
                            StatLegendRow("Missed", "${summary.missedCalls}", SamsungRedMissed)
                            StatLegendRow("Disconnected", "${summary.disconnectedDropCalls}", SamsungOrangeMessage)
                            StatLegendRow("Recorded", "${summary.recordedCallsCount}", SamsungPurpleRecord)
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Total Talk", style = MaterialTheme.typography.labelSmall)
                                Text(formatDurationHuman(summary.totalDurationSeconds), fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Outgoing", style = MaterialTheme.typography.labelSmall)
                                Text(formatDurationHuman(summary.outgoingDurationSeconds), fontWeight = FontWeight.SemiBold, color = SamsungGreenCall)
                            }
                            Column {
                                Text("Incoming", style = MaterialTheme.typography.labelSmall)
                                Text(formatDurationHuman(summary.incomingDurationSeconds), fontWeight = FontWeight.SemiBold, color = SamsungBlue)
                            }
                        }
                    }
                }
            }
        }

        items(contactStats, key = { it.normalizedNumber }) { item ->
            ElevatedCard(
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().clickable {
                    onOpenContactHistory(item.normalizedNumber, item.contactName ?: item.displayNumber)
                }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.contactName ?: item.displayNumber, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(item.displayNumber, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                        }
                        Row {
                            IconButton(onClick = { placeCallIntent(context, item.displayNumber) }) {
                                Icon(Icons.Default.Call, contentDescription = "Call", tint = SamsungGreenCall)
                            }
                            IconButton(onClick = { openMessagesIntent(context, item.displayNumber) }) {
                                Icon(Icons.AutoMirrored.Filled.Message, contentDescription = "Message", tint = SamsungOrangeMessage)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricPill("Talked", formatDurationHuman(item.totalDurationSeconds), SamsungBlue)
                        MetricPill("Calls", "${item.totalCalls}", MaterialTheme.colorScheme.primary)
                        MetricPill("Out / In", "${item.outgoingCount}/${item.incomingCount}", SamsungGreenCall)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricPill("Missed", "${item.missedCount}x", SamsungRedMissed)
                        MetricPill("Disconnected", "${item.disconnectedCount}x", SamsungOrangeMessage)
                        MetricPill("Avg", formatDurationHuman(item.averageDurationSeconds), SamsungPurpleRecord)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatLegendRow(label: String, value: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = "$label: ", style = MaterialTheme.typography.bodySmall)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MetricPill(label: String, value: String, accent: Color) {
    Surface(color = accent.copy(alpha = 0.1f), shape = RoundedCornerShape(12.dp)) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
            Text(text = value, style = MaterialTheme.typography.labelLarge, color = accent, fontWeight = FontWeight.Bold)
        }
    }
}

/**
 * Tab 4: Clean Call Recordings Vault (Starred Filter + Seekable Player + Selective Rules)
 */
@Composable
fun CallRecordingsScreen(
    recordedCalls: List<CallLogEntry>,
    settings: UserSettings,
    audioState: AudioPlayerState,
    starredOnly: Boolean,
    onToggleStarredOnly: () -> Unit,
    onTogglePlay: (String) -> Unit,
    onSeekAudio: (Int) -> Unit,
    onCycleSpeed: () -> Unit,
    onShareRecording: (String) -> Unit,
    onToggleStar: (CallLogEntry) -> Unit,
    onToggleAutoRecord: (Boolean) -> Unit,
    onRescanSamsungRecordings: () -> Unit,
    onOpenSettings: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 96.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Recordings Vault", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("${recordedCalls.size} saved recordings • Zero announcement", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Recording Settings")
                }
            }
        }

        item {
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto-Record Calls", fontWeight = FontWeight.Bold)
                            Text("Rule: ${settings.recordingRule.label} • Silent save", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = settings.autoRecordEnabled, onCheckedChange = onToggleAutoRecord)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = starredOnly,
                            onClick = onToggleStarredOnly,
                            label = { Text("Starred Only") },
                            leadingIcon = { Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                        OutlinedButton(onClick = onRescanSamsungRecordings, shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scan Samsung Audio", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        items(recordedCalls, key = { it.id }) { call ->
            val path = call.recordingFilePath ?: return@items
            val isThisTrack = audioState.playingPath == path

            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(call.contactName ?: call.phoneNumber, fontWeight = FontWeight.Bold)
                            Text("${formatTimestamp(call.timestamp)} • ${formatDurationHuman(call.durationSeconds)}", style = MaterialTheme.typography.bodySmall)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { onToggleStar(call) }) {
                                Icon(
                                    if (call.isStarredRecording) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "Star",
                                    tint = if (call.isStarredRecording) SamsungGoldStar else MaterialTheme.colorScheme.onSurface
                                )
                            }
                            IconButton(onClick = { onShareRecording(path) }) {
                                Icon(Icons.Default.Share, contentDescription = "Share", tint = SamsungBlue)
                            }
                            IconButton(onClick = { onTogglePlay(path) }) {
                                Icon(
                                    if (isThisTrack && audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = SamsungPurpleRecord,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }

                    if (isThisTrack) {
                        Slider(
                            value = audioState.positionMs.toFloat(),
                            onValueChange = { onSeekAudio(it.toInt()) },
                            valueRange = 0f..audioState.durationMs.coerceAtLeast(1).toFloat()
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${formatAudioMillis(audioState.positionMs)} / ${formatAudioMillis(audioState.durationMs)}", style = MaterialTheme.typography.labelSmall)
                            TextButton(onClick = onCycleSpeed) {
                                Text("Speed: ${audioState.speed}x", fontWeight = FontWeight.Bold, color = SamsungPurpleRecord)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Clean One UI Focus-Block Settings & Cloud Backup Modal Sheet
 * Includes Attribution: Developed by Mir Murtaza Asif from Srinagar, Jammu and Kashmir
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsAndBackupSheet(
    settings: UserSettings,
    availableBackups: List<RemotePhoneBackupSlot>,
    blockedNumbers: List<BlockedNumberEntity>,
    onDismiss: () -> Unit,
    onSavePhoneNumber: (String) -> Unit,
    onConnectGoogleAccount: () -> Unit,
    onToggleAutoBackup: (Boolean) -> Unit,
    onBackupNow: () -> Unit,
    onRefreshBackups: () -> Unit,
    onRestoreSlot: (RemotePhoneBackupSlot) -> Unit,
    onExportCsv: () -> Unit,
    onExportJson: () -> Unit,
    onImportJsonFile: () -> Unit,
    onToggleHideNotification: (Boolean) -> Unit,
    onSelectEngineMode: (RecordingEngineMode) -> Unit,
    onSelectRecordingRule: (RecordingRule) -> Unit,
    onToggleHaptics: (Boolean) -> Unit,
    onUnblockNumber: (String) -> Unit,
    onRequestDefaultDialerRole: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val sha1Fingerprint = remember { ContactsHelper.getAppSigningSha1(context) }
    var phoneInput by remember(settings.registeredPhoneNumber) { mutableStateOf(settings.registeredPhoneNumber) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 36.dp)
        ) {
            item {
                Text("Settings & Cloud Backup", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }

            // Focus Block 1: Per-Phone-Number Isolated Google Drive Backup
            item {
                ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SimCard, contentDescription = null, tint = SamsungBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Per-Phone-Number Backup", fontWeight = FontWeight.Bold)
                        }
                        Text("Each phone number gets its own folder on Google Drive so 5 phones never overwrite each other.", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            value = phoneInput,
                            onValueChange = { phoneInput = it },
                            label = { Text("Phone Number (e.g. +919876543210)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp)
                        )
                        Button(onClick = { onSavePhoneNumber(phoneInput) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                            Text("Save Phone Number")
                        }
                        HorizontalDivider()
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Auto-Backup (Battery Friendly)", fontWeight = FontWeight.SemiBold)
                                Text(settings.googleAccountEmail.ifBlank { "Local backup active • Link Google Drive below" }, style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = settings.autoDriveBackupEnabled, onCheckedChange = onToggleAutoBackup)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = onConnectGoogleAccount, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                                Text(if (settings.googleAccountEmail.isBlank()) "Link Drive" else "Switch", fontSize = 12.sp)
                            }
                            Button(onClick = onBackupNow, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Backup Now", fontSize = 12.sp)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = onExportCsv, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                                Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Export CSV", fontSize = 12.sp)
                            }
                            OutlinedButton(onClick = onExportJson, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Share JSON", fontSize = 12.sp)
                            }
                        }
                        OutlinedButton(onClick = onImportJsonFile, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Import / Restore Backup File (.json)", fontSize = 12.sp)
                        }
                        Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f), shape = RoundedCornerShape(12.dp)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Auto-saved to Documents/CallVault_Backups/ (survives uninstalls)", style = MaterialTheme.typography.labelSmall, color = SamsungGreenCall, fontWeight = FontWeight.Bold)
                                Text("To enable Google Drive Cloud Sync (fixes Error 10): Create a free project in Google Cloud Console → Enable Google Drive API → Create Android OAuth Client ID with package com.callvault.s24 and this SHA-1:", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                                Text(sha1Fingerprint, style = MaterialTheme.typography.labelSmall, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                TextButton(onClick = {
                                    val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cb.setPrimaryClip(ClipData.newPlainText("SHA-1", sha1Fingerprint))
                                    onShowMessage("SHA-1 copied to clipboard!")
                                }) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copy SHA-1", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Focus Block 2: Restore Backups
            if (availableBackups.isNotEmpty()) {
                item {
                    ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Restore by Phone Number", fontWeight = FontWeight.Bold)
                                IconButton(onClick = onRefreshBackups) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                                }
                            }
                            availableBackups.forEach { slot ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(slot.phoneNumber, fontWeight = FontWeight.SemiBold)
                                        Text(slot.folderName, style = MaterialTheme.typography.labelSmall)
                                    }
                                    Button(onClick = { onRestoreSlot(slot) }, shape = RoundedCornerShape(12.dp)) {
                                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Restore", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Focus Block 3: Recording Engine & Rules + Dialer Polish
            item {
                ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Recording & Dialer Controls", fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Hide 'Recording Saved' Alert", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = settings.hideRecordingSavedNotification, onCheckedChange = onToggleHideNotification)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Dialpad Haptic Vibration", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = settings.dialpadHapticsEnabled, onCheckedChange = onToggleHaptics)
                        }
                        HorizontalDivider()
                        Text("Recording Rule", style = MaterialTheme.typography.labelLarge, color = SamsungBlue)
                        RecordingRule.entries.forEach { rule ->
                            Row(
                                modifier = Modifier.fillMaxWidth().clickable { onSelectRecordingRule(rule) },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = settings.recordingRule == rule, onClick = { onSelectRecordingRule(rule) })
                                Text(rule.label, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        HorizontalDivider()
                        Text("S24 Ultra Recording Mode (Option C)", style = MaterialTheme.typography.labelLarge, color = SamsungBlue)
                        RecordingEngineMode.entries.forEach { mode ->
                            Row(
                                modifier = Modifier.fillMaxWidth().clickable { onSelectEngineMode(mode) }.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                RadioButton(selected = settings.recordingEngineMode == mode, onClick = { onSelectEngineMode(mode) })
                                Column(modifier = Modifier.padding(start = 4.dp)) {
                                    Text(mode.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                    Text(mode.subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                                }
                            }
                        }
                        OutlinedButton(onClick = onRequestDefaultDialerRole, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                            Text("Set / Test as Default Phone App")
                        }
                    }
                }
            }

            // Focus Block 4: Blocked Numbers
            if (blockedNumbers.isNotEmpty()) {
                item {
                    ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Blocked Numbers (${blockedNumbers.size})", fontWeight = FontWeight.Bold)
                            blockedNumbers.forEach { b ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(b.displayNumber)
                                    IconButton(onClick = { onUnblockNumber(b.normalizedNumber) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Unblock", tint = SamsungRedMissed)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Focus Block 5: About Section (Explicit Developer Attribution)
            item {
                ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(18.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(44.dp).clip(CircleShape).background(SamsungBlue.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Info, contentDescription = "About", tint = SamsungBlue)
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text("About CallVault", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                text = "Developed by Mir Murtaza Asif from Srinagar, Jammu and Kashmir",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = SamsungBlue
                            )
                            Text(
                                text = "Version 2.0.0 • Engineered for Samsung Galaxy S24 Ultra",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                    }
                }
            }
        }
    }
}
