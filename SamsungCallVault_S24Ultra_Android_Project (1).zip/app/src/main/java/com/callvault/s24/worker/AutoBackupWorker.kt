package com.callvault.s24.worker

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.callvault.s24.backup.DriveBackupManager
import com.callvault.s24.data.local.AppDatabase
import com.callvault.s24.data.local.AppPreferences
import com.callvault.s24.data.repository.CallLogRepository
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/**
 * Battery-friendly WorkManager job: only runs when network is connected and battery is not low.
 */
class AutoBackupWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val prefs = AppPreferences(applicationContext)
        val settings = prefs.settingsFlow.first()
        val dao = AppDatabase.getInstance(applicationContext).callLogDao()
        val repo = CallLogRepository(applicationContext, dao)

        runCatching { repo.syncSystemCallLogToUnlimitedVault(settings.registeredPhoneNumber) }

        if (settings.autoDriveBackupEnabled) {
            DriveBackupManager(applicationContext).performBackupNow()
        }
        return Result.success()
    }

    companion object {
        private const val WORK_NAME = "CallVault_Periodic_Sync_And_Backup"

        fun schedulePeriodicBackup(context: Context, intervalHours: Long = 12L) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .build()

            val request = PeriodicWorkRequestBuilder<AutoBackupWorker>(
                intervalHours.coerceAtLeast(1L),
                TimeUnit.HOURS
            )
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }
    }
}
