package com.callvault.s24.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * High-performance Unlimited Call Log Entity engineered for 100,000+ (lakhs) calls & 10+ years retention.
 */
@Serializable
@Entity(
    tableName = "unlimited_call_logs",
    indices = [
        Index(value = ["normalizedNumber"]),
        Index(value = ["timestamp"]),
        Index(value = ["callType"]),
        Index(value = ["isStarredRecording"]),
        Index(value = ["systemCallId", "timestamp"], unique = true)
    ]
)
data class CallLogEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val systemCallId: Long,
    val phoneNumber: String,
    val normalizedNumber: String,
    val contactName: String?,
    val photoUri: String? = null,
    val callType: Int, // 1=Incoming, 2=Outgoing, 3=Missed, 5=Rejected, 6=Blocked
    val timestamp: Long,
    val durationSeconds: Long,
    val simSlotId: String? = null,
    val simSlotLabel: String? = null, // "SIM 1" or "SIM 2"
    val devicePhoneNumber: String? = null,
    val disconnectCauseCode: Int = 0,
    val disconnectCauseLabel: String = "NORMAL",
    val wasDisconnectedAbnormally: Boolean = false,
    val recordingFilePath: String? = null,
    val recordingSource: String? = null, // "SAMSUNG_NATIVE" or "BUILTIN_RECORDER"
    val isStarredRecording: Boolean = false,
    val notes: String? = null
)

@Serializable
@Entity(tableName = "blocked_numbers")
data class BlockedNumberEntity(
    @PrimaryKey
    val normalizedNumber: String,
    val displayNumber: String,
    val blockedAtMillis: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "speed_dial_slots")
data class SpeedDialEntity(
    @PrimaryKey
    val digit: Int, // 2..9
    val phoneNumber: String,
    val contactName: String
)

@Serializable
data class CallSummaryStats(
    val totalCalls: Int = 0,
    val incomingCalls: Int = 0,
    val outgoingCalls: Int = 0,
    val missedCalls: Int = 0,
    val rejectedCalls: Int = 0,
    val totalDurationSeconds: Long = 0L,
    val incomingDurationSeconds: Long = 0L,
    val outgoingDurationSeconds: Long = 0L,
    val disconnectedDropCalls: Int = 0,
    val recordedCallsCount: Int = 0
)

@Serializable
data class ContactAnalyticsItem(
    val normalizedNumber: String,
    val displayNumber: String,
    val contactName: String?,
    val totalCalls: Int,
    val incomingCount: Int,
    val outgoingCount: Int,
    val missedCount: Int,
    val rejectedCount: Int,
    val disconnectedCount: Int,
    val totalDurationSeconds: Long,
    val averageDurationSeconds: Long,
    val lastCallTimestamp: Long
)

enum class RecordingEngineMode(val title: String, val subtitle: String) {
    HYBRID_AUTO(
        "Option C: Hybrid Smart Mode (Recommended)",
        "Auto-links Samsung native .m4a recordings when using Samsung Phone, and uses Built-in Silent Accessibility Recorder when set as Default Dialer."
    ),
    SAMSUNG_COMPANION(
        "Option A: Samsung Native Recording Sync",
        "Scans /Recordings/Call/ for Samsung One UI native recordings with zero pre-call announcement and links them automatically."
    ),
    BUILTIN_DEFAULT_DIALER(
        "Option B: Built-in Default Dialer Recorder",
        "Uses CallVault's InCallService + AccessibilityService for background recording and captures exact network/remote DisconnectCause codes."
    )
}

enum class RecordingRule(val label: String) {
    RECORD_ALL("Record All Calls"),
    UNKNOWN_ONLY("Record Unknown Numbers Only"),
    EXCLUDE_LIST("Exclude Selected Contacts")
}
