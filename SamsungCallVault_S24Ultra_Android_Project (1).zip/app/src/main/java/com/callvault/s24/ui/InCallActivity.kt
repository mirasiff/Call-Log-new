package com.callvault.s24.ui

import android.os.Bundle
import android.telecom.Call
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.callvault.s24.service.ActiveCallManager
import com.callvault.s24.ui.theme.CallVaultTheme
import com.callvault.s24.ui.theme.SamsungBlue
import com.callvault.s24.ui.theme.SamsungGreenCall
import com.callvault.s24.ui.theme.SamsungRedMissed
import kotlinx.coroutines.delay

class InCallActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CallVaultTheme(darkTheme = true) {
                val state by ActiveCallManager.uiState.collectAsState()
                val context = LocalContext.current
                var showDtmfKeypad by remember { mutableStateOf(false) }
                var elapsedSeconds by remember { mutableLongStateOf(0L) }

                LaunchedEffect(state.hasActiveCall, state.callState) {
                    if (!state.hasActiveCall && state.callState == Call.STATE_DISCONNECTED) {
                        delay(400)
                        finish()
                    }
                }

                LaunchedEffect(state.callState, state.connectTimeMillis) {
                    while (state.callState == Call.STATE_ACTIVE) {
                        val base = if (state.connectTimeMillis > 0L) state.connectTimeMillis else System.currentTimeMillis()
                        elapsedSeconds = ((System.currentTimeMillis() - base) / 1000L).coerceAtLeast(0L)
                        delay(1000L)
                    }
                }

                val statusText = when (state.callState) {
                    Call.STATE_RINGING -> "Incoming Call"
                    Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling..."
                    Call.STATE_HOLDING -> "On Hold"
                    Call.STATE_ACTIVE -> String.format("%02d:%02d", elapsedSeconds / 60, elapsedSeconds % 60)
                    else -> "Call Ended"
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF0E1726), Color(0xFF162238), Color(0xFF0A0E14))
                            )
                        )
                        .padding(horizontal = 24.dp, vertical = 48.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Spacer(modifier = Modifier.height(24.dp))
                            Text(
                                text = statusText,
                                color = if (state.callState == Call.STATE_ACTIVE) SamsungGreenCall else Color(0xFFB0C4DE),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = state.contactName ?: state.phoneNumber,
                                color = Color.White,
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (!state.contactName.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = state.phoneNumber,
                                    color = Color.White.copy(alpha = 0.7f),
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                            if (state.isRecording) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Surface(
                                    color = SamsungRedMissed.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Text(
                                        text = "● Silent Recording Active",
                                        color = Color(0xFFFF8A80),
                                        style = MaterialTheme.typography.labelMedium,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        if (showDtmfKeypad && state.callState != Call.STATE_RINGING) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                val rows = listOf(
                                    listOf('1', '2', '3'),
                                    listOf('4', '5', '6'),
                                    listOf('7', '8', '9'),
                                    listOf('*', '0', '#')
                                )
                                rows.forEach { row ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                                        row.forEach { ch ->
                                            Box(
                                                modifier = Modifier
                                                    .size(64.dp)
                                                    .clip(CircleShape)
                                                    .background(Color.White.copy(alpha = 0.12f))
                                                    .clickable { ActiveCallManager.sendDtmf(ch) },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(ch.toString(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            if (state.callState == Call.STATE_RINGING) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    CallActionCircle(Icons.Default.CallEnd, "Decline", SamsungRedMissed) {
                                        ActiveCallManager.disconnectCall()
                                    }
                                    CallActionCircle(Icons.Default.Call, "Answer", SamsungGreenCall) {
                                        ActiveCallManager.answerCall()
                                    }
                                }
                            } else {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    CallToggleButton(
                                        icon = if (state.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                        label = "Mute",
                                        active = state.isMuted,
                                        onClick = { ActiveCallManager.toggleMute(context) }
                                    )
                                    CallToggleButton(
                                        icon = Icons.Default.Dialpad,
                                        label = "Keypad",
                                        active = showDtmfKeypad,
                                        onClick = { showDtmfKeypad = !showDtmfKeypad }
                                    )
                                    CallToggleButton(
                                        icon = Icons.Default.VolumeUp,
                                        label = "Speaker",
                                        active = state.isSpeakerOn,
                                        onClick = { ActiveCallManager.toggleSpeaker(context) }
                                    )
                                    CallToggleButton(
                                        icon = Icons.Default.Pause,
                                        label = "Hold",
                                        active = state.isOnHold,
                                        onClick = { ActiveCallManager.toggleHold() }
                                    )
                                }
                                Spacer(modifier = Modifier.height(32.dp))
                                CallActionCircle(Icons.Default.CallEnd, "End Call", SamsungRedMissed) {
                                    ActiveCallManager.disconnectCall()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CallActionCircle(icon: ImageVector, label: String, bg: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(bg)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(32.dp))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(label, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun CallToggleButton(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(if (active) SamsungBlue else Color.White.copy(alpha = 0.14f))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(26.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(label, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall)
    }
}
