package com.callvault.s24.service

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import com.callvault.s24.data.local.AppDatabase
import com.callvault.s24.data.repository.CallLogRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SilentCallRecorderManager {

    private var mediaRecorder: MediaRecorder? = null
    private var currentOutputFile: File? = null
    private var currentPhoneNumber: String = ""
    private var isRecording = false

    fun startSilentRecording(context: Context, phoneNumber: String): File? {
        if (isRecording) return currentOutputFile

        val recordingsDir = File(context.filesDir, "recordings").apply { mkdirs() }
        val sanitizedNumber = phoneNumber.replace(Regex("[^0-9+]"), "").ifBlank { "Unknown" }
        val timestampStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(recordingsDir, "Call_${sanitizedNumber}_$timestampStr.m4a")

        val audioSourcesToTry = listOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.MIC
        )

        for (source in audioSourcesToTry) {
            try {
                val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    MediaRecorder(context)
                } else {
                    @Suppress("DEPRECATION")
                    MediaRecorder()
                }

                recorder.setAudioSource(source)
                recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                recorder.setAudioEncodingBitRate(128_000)
                recorder.setAudioSamplingRate(44_100)
                recorder.setOutputFile(outputFile.absolutePath)
                recorder.prepare()
                recorder.start()

                mediaRecorder = recorder
                currentOutputFile = outputFile
                currentPhoneNumber = phoneNumber
                isRecording = true
                return outputFile
            } catch (_: Exception) {
                runCatching { mediaRecorder?.release() }
                mediaRecorder = null
            }
        }
        return null
    }

    fun stopSilentRecording(context: Context, callStartMillis: Long) {
        if (!isRecording) return
        val savedFile = currentOutputFile
        val recordedNumber = currentPhoneNumber
        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
        } catch (_: Exception) {
        } finally {
            mediaRecorder = null
            isRecording = false
            currentOutputFile = null
            currentPhoneNumber = ""
        }

        if (savedFile != null && savedFile.exists() && savedFile.length() > 0) {
            CoroutineScope(Dispatchers.IO).launch {
                // Wait briefly for VaultInCallService to upsert the completed call row
                delay(800L)
                val dao = AppDatabase.getInstance(context).callLogDao()
                val repo = CallLogRepository(context, dao)
                val normalized = repo.normalizePhoneNumber(recordedNumber)
                val exactCall = dao.findExactCallForBuiltInRecording(normalized, callStartMillis)
                if (exactCall != null) {
                    dao.attachRecordingToCall(
                        callId = exactCall.id,
                        filePath = savedFile.absolutePath,
                        source = "BUILTIN_RECORDER"
                    )
                }
            }
        }
    }
}
