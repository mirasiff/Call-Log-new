package com.callvault.s24.data.repository

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import com.callvault.s24.data.local.CallLogDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class DeviceContact(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val photoUri: String? = null,
    val isStarred: Boolean = false,
    val lastActivitySummary: String = "No recent activity",
    val lastActivityTimestamp: Long = 0L
)

object ContactsHelper {

    private data class SmsInfo(val timestamp: Long, val isIncoming: Boolean)

    @SuppressLint("Range")
    suspend fun loadEnrichedContacts(context: Context, dao: CallLogDao): List<DeviceContact> =
        withContext(Dispatchers.IO) {
            val rawContacts = mutableListOf<DeviceContact>()
            val seen = HashSet<String>()

            runCatching {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER,
                        ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI,
                        ContactsContract.CommonDataKinds.Phone.STARRED
                    ),
                    null,
                    null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )?.use { cursor ->
                    while (cursor.moveToNext()) {
                        val id = cursor.getString(0) ?: ""
                        val name = cursor.getString(1) ?: "Unknown"
                        val number = cursor.getString(2)?.trim() ?: ""
                        val photo = cursor.getString(3)
                        val starred = cursor.getInt(4) == 1
                        val key = "$name|${number.replace(Regex("[^0-9+]"), "").takeLast(10)}"
                        if (number.isNotBlank() && seen.add(key)) {
                            rawContacts.add(DeviceContact(id, name, number, photo, starred))
                        }
                    }
                }
            }

            // Build lookup maps for latest call & latest SMS by last 10 digits
            val latestCallBySuffix = runCatching {
                dao.getLatestCallPerNumber().associateBy {
                    it.normalizedNumber.replace(Regex("[^0-9]"), "").takeLast(10)
                }
            }.getOrDefault(emptyMap())

            val latestSmsBySuffix = loadLatestSmsMap(context)

            rawContacts.map { contact ->
                val suffix = contact.phoneNumber.replace(Regex("[^0-9]"), "").takeLast(10)
                val lastCall = if (suffix.length >= 7) latestCallBySuffix[suffix] else null
                val lastSms = if (suffix.length >= 7) latestSmsBySuffix[suffix] else null

                val callTs = lastCall?.timestamp ?: 0L
                val smsTs = lastSms?.timestamp ?: 0L

                when {
                    callTs == 0L && smsTs == 0L -> contact
                    smsTs > callTs && lastSms != null -> {
                        val dir = if (lastSms.isIncoming) "Last message received" else "Last message sent"
                        contact.copy(
                            lastActivitySummary = "$dir • ${formatSmartRelativeTime(smsTs)}",
                            lastActivityTimestamp = smsTs
                        )
                    }
                    lastCall != null -> {
                        val label = when (lastCall.callType) {
                            CallLog.Calls.INCOMING_TYPE -> "Last incoming call"
                            CallLog.Calls.OUTGOING_TYPE -> "Last outgoing call"
                            CallLog.Calls.MISSED_TYPE -> "Last missed call"
                            CallLog.Calls.REJECTED_TYPE -> "Last rejected call"
                            else -> "Last called"
                        }
                        contact.copy(
                            lastActivitySummary = "$label • ${formatSmartRelativeTime(callTs)}",
                            lastActivityTimestamp = callTs
                        )
                    }
                    else -> contact
                }
            }
        }

    private fun loadLatestSmsMap(context: Context): Map<String, SmsInfo> {
        val map = HashMap<String, SmsInfo>()
        runCatching {
            context.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.DATE, Telephony.Sms.TYPE),
                null,
                null,
                "${Telephony.Sms.DATE} DESC LIMIT 400"
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val addr = cursor.getString(0) ?: continue
                    val date = cursor.getLong(1)
                    val type = cursor.getInt(2) // 1 = Inbox (received), 2 = Sent
                    val suffix = addr.replace(Regex("[^0-9]"), "").takeLast(10)
                    if (suffix.length >= 7 && !map.containsKey(suffix)) {
                        map[suffix] = SmsInfo(date, type == Telephony.Sms.MESSAGE_TYPE_INBOX)
                    }
                }
            }
        }
        return map
    }

    fun formatSmartRelativeTime(epochMillis: Long): String {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply { timeInMillis = epochMillis }
        val timePart = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(epochMillis))

        return when {
            now.get(Calendar.YEAR) == target.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == target.get(Calendar.DAY_OF_YEAR) -> "Today, $timePart"
            now.get(Calendar.YEAR) == target.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) - target.get(Calendar.DAY_OF_YEAR) == 1 -> "Yesterday, $timePart"
            now.get(Calendar.YEAR) == target.get(Calendar.YEAR) ->
                SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(epochMillis))
            else ->
                SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(epochMillis))
        }
    }

    fun isNumberInContacts(context: Context, rawNumber: String): Boolean {
        return runCatching {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(rawNumber)
            )
            context.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)
                ?.use { it.moveToFirst() } ?: false
        }.getOrDefault(false)
    }

    @Suppress("DEPRECATION")
    fun getAppSigningSha1(context: Context): String {
        return runCatching {
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNING_CERTIFICATES
                )
            } else {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNATURES
                )
            }
            val sigBytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
            } else {
                info.signatures?.firstOrNull()?.toByteArray()
            } ?: return "Unavailable"

            val digest = MessageDigest.getInstance("SHA-1").digest(sigBytes)
            digest.joinToString(":") { "%02X".format(it) }
        }.getOrElse { "Unavailable" }
    }
}
