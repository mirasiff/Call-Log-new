package com.callvault.s24.ui.components

import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.callvault.s24.ui.theme.WhatsAppGreen
import kotlin.math.abs

/**
 * Requirement #1: Distinct, recognizable WhatsApp Call Icon
 * (WhatsApp speech-bubble silhouette with phone handset inside)
 */
@Composable
fun WhatsAppCallIcon(
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    tint: Color = WhatsAppGreen
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = w * 0.10f

        // Outer WhatsApp speech bubble (circle + bottom-left tail)
        val bubblePath = Path().apply {
            moveTo(w * 0.18f, h * 0.72f)
            lineTo(w * 0.10f, h * 0.90f)
            lineTo(w * 0.30f, h * 0.84f)
        }
        drawCircle(
            color = tint,
            radius = w * 0.40f,
            center = Offset(w * 0.52f, h * 0.48f),
            style = Stroke(width = stroke)
        )
        drawPath(
            path = bubblePath,
            color = tint,
            style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // Crisp phone handset inside the bubble
        val phonePath = Path().apply {
            moveTo(w * 0.38f, h * 0.34f)
            quadraticTo(w * 0.35f, h * 0.52f, w * 0.52f, h * 0.62f)
            quadraticTo(w * 0.64f, h * 0.65f, w * 0.68f, h * 0.56f)
        }
        drawPath(
            path = phonePath,
            color = tint,
            style = Stroke(width = stroke * 1.15f, cap = StrokeCap.Round)
        )
    }
}

/**
 * Requirement #1: Distinct, recognizable WhatsApp Message Icon
 * (WhatsApp speech-bubble silhouette with 3 crisp chat dots inside)
 */
@Composable
fun WhatsAppMessageIcon(
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    tint: Color = WhatsAppGreen
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = w * 0.10f

        val bubblePath = Path().apply {
            moveTo(w * 0.18f, h * 0.72f)
            lineTo(w * 0.10f, h * 0.90f)
            lineTo(w * 0.30f, h * 0.84f)
        }
        drawCircle(
            color = tint,
            radius = w * 0.40f,
            center = Offset(w * 0.52f, h * 0.48f),
            style = Stroke(width = stroke)
        )
        drawPath(
            path = bubblePath,
            color = tint,
            style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // Three crisp message dots inside
        val dotRadius = w * 0.055f
        val cy = h * 0.48f
        drawCircle(color = tint, radius = dotRadius, center = Offset(w * 0.37f, cy))
        drawCircle(color = tint, radius = dotRadius, center = Offset(w * 0.52f, cy))
        drawCircle(color = tint, radius = dotRadius, center = Offset(w * 0.67f, cy))
    }
}

private val avatarPalette = listOf(
    Color(0xFF1E88E5) to Color(0xFFE3F2FD),
    Color(0xFF43A047) to Color(0xFFE8F5E9),
    Color(0xFF8E24AA) to Color(0xFFF3E5F5),
    Color(0xFFFB8C00) to Color(0xFFFFF3E0),
    Color(0xFF00897B) to Color(0xFFE0F2F1),
    Color(0xFF3949AB) to Color(0xFFE8EAF6),
    Color(0xFFD81B60) to Color(0xFFFCE4EC)
)

/**
 * Requirement #2: Modern Circular Contact Avatar
 * Loads contact's real profile photo if available, or generates a subtle tinted initial avatar.
 */
@Composable
fun ContactAvatar(
    name: String,
    photoUri: String? = null,
    size: Dp = 44.dp
) {
    val context = LocalContext.current
    val bitmap = remember(photoUri) {
        if (photoUri.isNullOrBlank()) null
        else runCatching {
            val uri = Uri.parse(photoUri)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri)).asImageBitmap()
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(context.contentResolver, uri).asImageBitmap()
            }
        }.getOrNull()
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap,
            contentDescription = name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(CircleShape)
        )
    } else {
        val initial = name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "#"
        val (fgColor, bgColor) = avatarPalette[abs(name.hashCode()) % avatarPalette.size]
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(bgColor),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = initial,
                color = fgColor,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.42f).sp
            )
        }
    }
}
