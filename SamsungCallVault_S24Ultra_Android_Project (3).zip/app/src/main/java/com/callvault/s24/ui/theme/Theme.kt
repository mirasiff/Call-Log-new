package com.callvault.s24.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

val SamsungBlue = Color(0xFF0381FE)
val SamsungGreenCall = Color(0xFF00C853)
val SamsungOrangeMessage = Color(0xFFFF6D00)
val SamsungRedMissed = Color(0xFFE53935)
val SamsungPurpleRecord = Color(0xFF7C4DFF)
val SamsungGoldStar = Color(0xFFFFB300)
val WhatsAppGreen = Color(0xFF25D366)

val MissedCallBgLight = Color(0xFFFFF1F2)
val MissedCallBgDark = Color(0xFF2B161A)

private val DarkColorPalette = darkColorScheme(
    primary = SamsungBlue,
    secondary = SamsungGreenCall,
    tertiary = SamsungOrangeMessage,
    background = Color(0xFF080B10),
    surface = Color(0xFF141923),
    surfaceVariant = Color(0xFF1D2432),
    onBackground = Color(0xFFF5F7FA),
    onSurface = Color(0xFFF5F7FA)
)

private val LightColorPalette = lightColorScheme(
    primary = SamsungBlue,
    secondary = SamsungGreenCall,
    tertiary = SamsungOrangeMessage,
    background = Color(0xFFF3F5F9),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE8EDF5),
    onBackground = Color(0xFF10141C),
    onSurface = Color(0xFF10141C)
)

@Composable
fun CallVaultTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorPalette
        else -> LightColorPalette
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
