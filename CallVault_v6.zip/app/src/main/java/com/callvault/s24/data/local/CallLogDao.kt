package com.callvault.s24.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.callvault.s24.data.model.BlockedNumberEntity
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.ContactAnalyticsItem
import com.callvault.s24.data.model.SpeedDialEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CallLogDao {

    @Query("SELECT * FROM unlimited_call_logs ORDER BY timestamp DESC")
    fun observeAllCalls(): Flow<List<CallLogEntry>>

    @Query("SELECT * FROM unlimited_call_logs ORDER BY timestamp DESC")
    suspend fun getAllCallsSnapshot(): List<CallLogEntry>

    @Query("""
        SELECT * FROM unlimited_call_logs
        WHERE (:callTypeFilter = 0 OR callType = :callTypeFilter)
          AND (:onlyRecorded = 0 OR recordingFilePath IS NOT NULL)
          AND (:simFilter = 'ALL' OR simSlotLabel = :simFilter)
          AND (:searchQuery = '' OR phoneNumber LIKE '%' || :searchQuery || '%' OR contactName LIKE '%' || :searchQuery || '%' OR notes LIKE '%' || :searchQuery || '%')
        ORDER BY timestamp DESC
        LIMIT :limitCount
    """)
    fun observeFilteredCalls(
        callTypeFilter: Int,
        onlyRecorded: Int,
        simFilter: String,
        searchQuery: String,
        limitCount: Int = 500
    ): Flow<List<CallLogEntry>>

    @Query("SELECT COUNT(*) FROM unlimited_call_logs")
    fun observeTotalCallCount(): Flow<Int>

    @Query("""
        SELECT * FROM unlimited_call_logs
        WHERE recordingFilePath IS NOT NULL
          AND (:starredOnly = 0 OR isStarredRecording = 1)
        ORDER BY timestamp DESC
    """)
    fun observeRecordedCalls(starredOnly: Int = 0): Flow<List<CallLogEntry>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCallsIgnoreDuplicate(calls: List<CallLogEntry>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCall(call: CallLogEntry): Long

    @Query("UPDATE unlimited_call_logs SET recordingFilePath = :filePath, recordingSource = :source WHERE id = :callId")
    suspend fun attachRecordingToCall(callId: Long, filePath: String, source: String)

    @Query("UPDATE unlimited_call_logs SET recordingFilePath = NULL, recordingSource = NULL WHERE id = :callId")
    suspend fun clearRecordingFromCall(callId: Long)

    @Query("SELECT recordingFilePath FROM unlimited_call_logs WHERE recordingFilePath IS NOT NULL")
    suspend fun getAllLinkedRecordingPaths(): List<String>

    @Query("SELECT * FROM unlimited_call_logs WHERE recordingFilePath IS NOT NULL")
    suspend fun getAllRecordedCallsSnapshot(): List<CallLogEntry>

    @Query("""
        SELECT * FROM unlimited_call_logs
        WHERE timestamp BETWEEN :minTimestamp AND :maxTimestamp
          AND durationSeconds > 0
          AND recordingFilePath IS NULL
        ORDER BY timestamp DESC
    """)
    suspend fun findUnlinkedCallsInWindow(minTimestamp: Long, maxTimestamp: Long): List<CallLogEntry>

    @Query("""
        SELECT * FROM unlimited_call_logs
        WHERE normalizedNumber = :normalizedNumber
          AND ABS(timestamp - :callStartMillis) <= 30000
        ORDER BY ABS(timestamp - :callStartMillis) ASC
        LIMIT 1
    """)
    suspend fun findExactCallForBuiltInRecording(normalizedNumber: String, callStartMillis: Long): CallLogEntry?

    @Query("UPDATE unlimited_call_logs SET isStarredRecording = :starred WHERE id = :callId")
    suspend fun setRecordingStarred(callId: Long, starred: Boolean)

    @Query("DELETE FROM unlimited_call_logs WHERE id = :callId")
    suspend fun deleteCallById(callId: Long)

    @Query("UPDATE unlimited_call_logs SET notes = :note WHERE id = :callId")
    suspend fun updateCallNote(callId: Long, note: String?)

    @Query("""
        SELECT 
            normalizedNumber AS normalizedNumber,
            MAX(phoneNumber) AS displayNumber,
            MAX(contactName) AS contactName,
            COUNT(*) AS totalCalls,
            SUM(CASE WHEN callType = 1 THEN 1 ELSE 0 END) AS incomingCount,
            SUM(CASE WHEN callType = 2 THEN 1 ELSE 0 END) AS outgoingCount,
            SUM(CASE WHEN callType = 3 THEN 1 ELSE 0 END) AS missedCount,
            SUM(CASE WHEN callType = 5 THEN 1 ELSE 0 END) AS rejectedCount,
            SUM(CASE WHEN wasDisconnectedAbnormally = 1 OR disconnectCauseLabel IN ('NETWORK_DROP', 'REMOTE_HANGUP', 'REJECTED', 'BUSY') THEN 1 ELSE 0 END) AS disconnectedCount,
            SUM(durationSeconds) AS totalDurationSeconds,
            CAST(AVG(CASE WHEN durationSeconds > 0 THEN durationSeconds ELSE NULL END) AS INTEGER) AS averageDurationSeconds,
            MAX(timestamp) AS lastCallTimestamp
        FROM unlimited_call_logs
        WHERE timestamp >= :sinceEpochMillis
          AND (:simFilter = 'ALL' OR simSlotLabel = :simFilter)
        GROUP BY normalizedNumber
        ORDER BY totalDurationSeconds DESC, totalCalls DESC
    """)
    fun observeContactAnalytics(
        sinceEpochMillis: Long = 0L,
        simFilter: String = "ALL"
    ): Flow<List<ContactAnalyticsItem>>

    @Query("SELECT * FROM unlimited_call_logs WHERE normalizedNumber = :normalizedNumber ORDER BY timestamp DESC")
    fun observeCallsForContact(normalizedNumber: String): Flow<List<CallLogEntry>>

    @Query("SELECT * FROM unlimited_call_logs WHERE id IN (SELECT MAX(id) FROM unlimited_call_logs GROUP BY normalizedNumber)")
    suspend fun getLatestCallPerNumber(): List<CallLogEntry>

    @Query("SELECT * FROM blocked_numbers ORDER BY blockedAtMillis DESC")
    fun observeBlockedNumbers(): Flow<List<BlockedNumberEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM blocked_numbers WHERE normalizedNumber = :normalizedNumber)")
    suspend fun isNumberBlocked(normalizedNumber: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun blockNumber(entity: BlockedNumberEntity)

    @Query("DELETE FROM blocked_numbers WHERE normalizedNumber = :normalizedNumber")
    suspend fun unblockNumber(normalizedNumber: String)

    @Query("SELECT * FROM speed_dial_slots ORDER BY digit ASC")
    fun observeSpeedDials(): Flow<List<SpeedDialEntity>>

    @Query("SELECT * FROM speed_dial_slots WHERE digit = :digit LIMIT 1")
    suspend fun getSpeedDialForDigit(digit: Int): SpeedDialEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSpeedDial(slot: SpeedDialEntity)

    @Query("DELETE FROM speed_dial_slots WHERE digit = :digit")
    suspend fun removeSpeedDial(digit: Int)
}
