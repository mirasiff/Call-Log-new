package com.callvault.s24.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.repository.ContactsHelper
import com.callvault.s24.data.repository.DeviceContact
import com.callvault.s24.data.repository.WhatsAppHelper
import com.callvault.s24.ui.components.ContactAvatar
import com.callvault.s24.ui.components.WhatsAppCallIcon
import com.callvault.s24.ui.components.WhatsAppMessageIcon
import com.callvault.s24.ui.theme.SamsungBlue
import com.callvault.s24.ui.theme.SamsungGreenCall
import com.callvault.s24.ui.theme.SamsungOrangeMessage
import com.callvault.s24.ui.theme.SamsungPurpleRecord
import com.callvault.s24.ui.theme.WhatsAppGreen
import kotlinx.coroutines.flow.Flow

/**
 * Full Samsung-Style Contact Detail View:
 * - All phone numbers (Mobile/Work/Home) with Phone Call, SMS, WhatsApp Call, WhatsApp Video, WhatsApp Msg
 * - Edit Contact & Share Contact (.vcf)
 * - Custom Ringtone Picker & Custom Vibration Pattern Picker (with live preview)
 * - Complete Call & Recording History for this contact
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDetailBottomSheet(
    contact: DeviceContact,
    selectedVibration: String,
    callsFlow: Flow<List<CallLogEntry>>,
    onDismiss: () -> Unit,
    onPickRingtone: (DeviceContact) -> Unit,
    onSelectVibration: (String, String) -> Unit,
    onSelectCall: (CallLogEntry) -> Unit
) {
    val context = LocalContext.current
    val history by callsFlow.collectAsState(initial = emptyList())
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 650.dp)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Profile Header
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ContactAvatar(name = contact.name, photoUri = contact.photoUri, size = 72.dp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = contact.name,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = contact.lastActivitySummary,
                        style = MaterialTheme.typography.bodySmall,
                        color = SamsungBlue
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { ContactsHelper.openEditContactIntent(context, contact) },
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Edit Contact", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = { ContactsHelper.shareContactAsVcf(context, contact) },
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share (.vcf)", fontSize = 12.sp)
                        }
                    }
                }
            }

            // All Associated Phone Numbers (Mobile / Work / Home)
            item {
                ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Phone Numbers (${contact.allNumbers.size.coerceAtLeast(1)})",
                            style = MaterialTheme.typography.labelLarge,
                            color = SamsungBlue,
                            fontWeight = FontWeight.Bold
                        )
                        val numbers = contact.allNumbers.ifEmpty {
                            listOf(com.callvault.s24.data.repository.ContactPhoneEntry(contact.phoneNumber, "Mobile"))
                        }
                        numbers.forEachIndexed { idx, entry ->
                            if (idx > 0) HorizontalDivider()
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(entry.number, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                                        Text(entry.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = { placeCallIntent(context, entry.number) }, modifier = Modifier.size(36.dp)) {
                                            Icon(Icons.Default.Call, contentDescription = "Call", tint = SamsungGreenCall, modifier = Modifier.size(20.dp))
                                        }
                                        IconButton(onClick = { openMessagesIntent(context, entry.number) }, modifier = Modifier.size(36.dp)) {
                                            Icon(Icons.AutoMirrored.Filled.Message, contentDescription = "SMS", tint = SamsungOrangeMessage, modifier = Modifier.size(20.dp))
                                        }
                                        IconButton(onClick = { WhatsAppHelper.startWhatsAppVoiceCall(context, entry.number) }, modifier = Modifier.size(36.dp)) {
                                            WhatsAppCallIcon(size = 20.dp, tint = WhatsAppGreen)
                                        }
                                        IconButton(onClick = { WhatsAppHelper.openWhatsAppChat(context, entry.number) }, modifier = Modifier.size(36.dp)) {
                                            WhatsAppMessageIcon(size = 20.dp, tint = WhatsAppGreen)
                                        }
                                        IconButton(onClick = { WhatsAppHelper.startWhatsAppVideoCall(context, entry.number) }, modifier = Modifier.size(36.dp)) {
                                            Icon(Icons.Default.Videocam, contentDescription = "WA Video", tint = WhatsAppGreen, modifier = Modifier.size(20.dp))
                                        }
                                    }
                                }
                            }
                        }

                        if (!contact.email.isNullOrBlank()) {
                            HorizontalDivider()
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Email, contentDescription = null, tint = SamsungBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(contact.email, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            // Ringtone & Vibration Tone Customization
            item {
                ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Ringtone & Vibration", style = MaterialTheme.typography.labelLarge, color = SamsungBlue, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                                onPickRingtone(contact)
                            }.padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = SamsungBlue, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Custom Ringtone", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        text = if (contact.customRingtoneUri.isNullOrBlank()) "Default system ringtone (tap to change)" else "Custom ringtone assigned (tap to change)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                    )
                                }
                            }
                        }

                        HorizontalDivider()

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Vibration, contentDescription = null, tint = SamsungPurpleRecord, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Vibration Pattern (tap to preview)", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(ContactsHelper.vibrationPatterns.keys.toList()) { pattern ->
                                FilterChip(
                                    selected = selectedVibration == pattern,
                                    onClick = { onSelectVibration(contact.id, pattern) },
                                    label = { Text(pattern, fontSize = 12.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // Recent Calls & Recordings for this Contact
            item {
                Text(
                    text = "Call & Recording History (${history.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            items(history.take(25), key = { it.id }) { item ->
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().clickable {
                        onDismiss()
                        onSelectCall(item)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(formatTimestamp(item.timestamp), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                            if (!item.notes.isNullOrBlank()) {
                                Text("Note: ${item.notes}", style = MaterialTheme.typography.labelSmall, color = SamsungBlue, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (item.recordingFilePath != null) {
                                Icon(Icons.Default.Mic, contentDescription = null, tint = SamsungPurpleRecord, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(formatDurationHuman(item.durationSeconds), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }
}
