package com.callvault.s24.data.repository

import android.annotation.SuppressLint
import android.content.Context
import android.media.MediaMetadataRetriever
import android.os.Environment
import android.provider.CallLog
import android.provider.MediaStore
import android.telephony.PhoneNumberUtils
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import com.callvault.s24.data.local.CallLogDao
import com.callvault.s24.data.model.BlockedNumberEntity
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.CallSummaryStats
import com.callvault.s24.data.model.ContactAnalyticsItem
import com.callvault.s24.data.model.SpeedDialEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.abs

data class UnmatchedRecordingFile(
    val filePath: String,
    val displayName: String,
    val timestampMillis: Long,
    val durationSeconds: Long,
    val fileSizeBytes: Long,
    val source: String
)

class CallLogRepository(
    private val context: Context,
    private val callLogDao: CallLogDao
) {
    fun observeTotalCallCount(): Flow<Int> = callLogDao.observeTotalCallCount()

    fun observeAllCalls(): Flow<List<CallLogEntry>> = callLogDao.observeAllCalls()

    suspend fun deleteCall(callId: Long) = callLogDao.deleteCallById(callId)

    fun observeFilteredCalls(
        callTypeFilter: Int,
        onlyRecorded: Boolean,
        simFilter: String,
        searchQuery: String,
        limitCount: Int
    ): Flow<List<CallLogEntry>> = callLogDao.observeFilteredCalls(
        callTypeFilter = callTypeFilter,
        onlyRecorded = if (onlyRecorded) 1 else 0,
        simFilter = simFilter,
        searchQuery = searchQuery.trim(),
        limitCount = limitCount
    )

    fun observeRecordedCalls(starredOnly: Boolean): Flow<List<CallLogEntry>> =
        callLogDao.observeRecordedCalls(if (starredOnly) 1 else 0)

    fun observeContactAnalytics(sinceEpochMillis: Long = 0L, simFilter: String = "ALL"): Flow<List<ContactAnalyticsItem>> =
        callLogDao.observeContactAnalytics(sinceEpochMillis, simFilter)

    fun observeCallsForContact(normalizedNumber: String): Flow<List<CallLogEntry>> =
        callLogDao.observeCallsForContact(normalizedNumber)

    fun observeBlockedNumbers(): Flow<List<BlockedNumberEntity>> = callLogDao.observeBlockedNumbers()

    fun observeSpeedDials(): Flow<List<SpeedDialEntity>> = callLogDao.observeSpeedDials()

    suspend fun setSpeedDial(digit: Int, phoneNumber: String, contactName: String) {
        callLogDao.setSpeedDial(SpeedDialEntity(digit, phoneNumber, contactName))
    }

    suspend fun removeSpeedDial(digit: Int) = callLogDao.removeSpeedDial(digit)

    suspend fun setRecordingStarred(callId: Long, starred: Boolean) =
        callLogDao.setRecordingStarred(callId, starred)

    suspend fun updateCallNote(callId: Long, note: String?) =
        callLogDao.updateCallNote(callId, note?.takeIf { it.isNotBlank() })

    suspend fun blockNumber(rawNumber: String) {
        val norm = normalizePhoneNumber(rawNumber)
        callLogDao.blockNumber(BlockedNumberEntity(norm, rawNumber))
    }

    suspend fun unblockNumber(normalizedNumber: String) =
        callLogDao.unblockNumber(normalizedNumber)

    fun observeSummaryStats(sinceEpochMillis: Long = 0L, simFilter: String = "ALL"): Flow<CallSummaryStats> =
        callLogDao.observeAllCalls().map { allCalls ->
            val calls = allCalls.filter { entry ->
                (sinceEpochMillis <= 0L || entry.timestamp >= sinceEpochMillis) &&
                    (simFilter == "ALL" || entry.simSlotLabel == simFilter)
            }
            CallSummaryStats(
                totalCalls = calls.size,
                incomingCalls = calls.count { it.callType == CallLog.Calls.INCOMING_TYPE },
                outgoingCalls = calls.count { it.callType == CallLog.Calls.OUTGOING_TYPE },
                missedCalls = calls.count { it.callType == CallLog.Calls.MISSED_TYPE },
                rejectedCalls = calls.count { it.callType == CallLog.Calls.REJECTED_TYPE },
                totalDurationSeconds = calls.sumOf { it.durationSeconds },
                incomingDurationSeconds = calls.filter { it.callType == CallLog.Calls.INCOMING_TYPE }.sumOf { it.durationSeconds },
                outgoingDurationSeconds = calls.filter { it.callType == CallLog.Calls.OUTGOING_TYPE }.sumOf { it.durationSeconds },
                disconnectedDropCalls = calls.count {
                    it.wasDisconnectedAbnormally ||
                        it.disconnectCauseLabel in listOf("NETWORK_DROP", "REMOTE_HANGUP", "REJECTED", "BUSY")
                },
                recordedCallsCount = calls.count { !it.recordingFilePath.isNullOrBlank() }
            )
        }

    @SuppressLint("MissingPermission")
    suspend fun syncSystemCallLogToUnlimitedVault(configuredPhoneNumber: String): Int =
        withContext(Dispatchers.IO) {
            val resolver = context.contentResolver
            val projection = arrayOf(
                CallLog.Calls._ID,
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.CACHED_PHOTO_URI,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE,
                CallLog.Calls.DURATION,
                CallLog.Calls.PHONE_ACCOUNT_ID
            )

            val simLabelMap = buildSimSlotMap()
            val entriesToInsert = mutableListOf<CallLogEntry>()
            val detectedSimNumber = configuredPhoneNumber.ifBlank { detectSimPhoneNumber() }

            resolver.query(
                CallLog.Calls.CONTENT_URI,
                projection,
                null,
                null,
                "${CallLog.Calls.DATE} DESC"
            )?.use { cursor ->
                val idIdx = cursor.getColumnIndex(CallLog.Calls._ID)
                val numIdx = cursor.getColumnIndex(CallLog.Calls.NUMBER)
                val nameIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)
                val photoIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_PHOTO_URI)
                val typeIdx = cursor.getColumnIndex(CallLog.Calls.TYPE)
                val dateIdx = cursor.getColumnIndex(CallLog.Calls.DATE)
                val durIdx = cursor.getColumnIndex(CallLog.Calls.DURATION)
                val accIdx = cursor.getColumnIndex(CallLog.Calls.PHONE_ACCOUNT_ID)

                while (cursor.moveToNext()) {
                    val sysId = if (idIdx >= 0) cursor.getLong(idIdx) else 0L
                    val rawNumber = (if (numIdx >= 0) cursor.getString(numIdx) else null) ?: "Unknown"
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx) else null
                    val photo = if (photoIdx >= 0) cursor.getString(photoIdx) else null
                    val type = if (typeIdx >= 0) cursor.getInt(typeIdx) else CallLog.Calls.INCOMING_TYPE
                    val date = if (dateIdx >= 0) cursor.getLong(dateIdx) else System.currentTimeMillis()
                    val duration = if (durIdx >= 0) cursor.getLong(durIdx) else 0L
                    val simId = if (accIdx >= 0) cursor.getString(accIdx) else null

                    val simLabel = simLabelMap.entries.firstOrNull { (key, _) ->
                        simId?.contains(key) == true
                    }?.value ?: if (simId == "0" || simId == "1") "SIM ${simId.toInt() + 1}" else "SIM 1"

                    val normalized = normalizePhoneNumber(rawNumber)
                    val disconnectLabel = when (type) {
                        CallLog.Calls.MISSED_TYPE -> "MISSED"
                        CallLog.Calls.REJECTED_TYPE -> "REJECTED"
                        CallLog.Calls.BLOCKED_TYPE -> "BLOCKED"
                        else -> if (duration in 1..4) "SHORT_DROP" else "NORMAL"
                    }
                    val abnormal = type == CallLog.Calls.REJECTED_TYPE || (type in 1..2 && duration in 1..4)

                    entriesToInsert.add(
                        CallLogEntry(
                            systemCallId = sysId,
                            phoneNumber = rawNumber,
                            normalizedNumber = normalized,
                            contactName = name?.takeIf { it.isNotBlank() },
                            photoUri = photo,
                            callType = type,
                            timestamp = date,
                            durationSeconds = duration,
                            simSlotId = simId,
                            simSlotLabel = simLabel,
                            devicePhoneNumber = detectedSimNumber,
                            disconnectCauseCode = 0,
                            disconnectCauseLabel = disconnectLabel,
                            wasDisconnectedAbnormally = abnormal
                        )
                    )
                }
            }

            val insertedIds = if (entriesToInsert.isNotEmpty()) {
                callLogDao.insertCallsIgnoreDuplicate(entriesToInsert)
            } else emptyList()

            verifyAndRepairRecordingLinks()
            scanAndLinkAllRecordings()
            insertedIds.count { it != -1L }
        }

    private suspend fun verifyAndRepairRecordingLinks() {
        val existingRecorded = callLogDao.getAllRecordedCallsSnapshot()
        val seenPaths = HashSet<String>()
        for (call in existingRecorded) {
            val path = call.recordingFilePath ?: continue
            val file = File(path)
            if (!file.exists() || call.durationSeconds <= 0L || !seenPaths.add(path)) {
                callLogDao.clearRecordingFromCall(call.id)
                continue
            }
            val parsedDigits = extractPhoneDigitsFromFilename(file.nameWithoutExtension)
            if (parsedDigits != null) {
                val callDigits = call.normalizedNumber.replace(Regex("[^0-9]"), "")
                val suffixLen = minOf(7, parsedDigits.length, callDigits.length)
                if (suffixLen >= 7 && !callDigits.endsWith(parsedDigits.takeLast(suffixLen))) {
                    callLogDao.clearRecordingFromCall(call.id)
                }
            }
        }
    }

    /**
     * Discovers call recordings from BOTH:
     * 1. Direct filesystem folders (/Recordings/Call, /Call, app private /recordings)
     * 2. Android MediaStore.Audio (works even before All Files Access is granted!)
     */
    private fun discoverAllRecordingFiles(): List<File> {
        val discovered = LinkedHashMap<String, File>()
        val root = Environment.getExternalStorageDirectory()
        val candidateFolders = listOf(
            File(root, "Recordings/Call"),
            File(root, "Call"),
            File(root, "Samsung/Call"),
            File(context.filesDir, "recordings")
        )

        for (folder in candidateFolders) {
            if (!folder.exists() || !folder.isDirectory) continue
            folder.listFiles { file ->
                file.isFile && file.extension.lowercase() in listOf("m4a", "aac", "mp3", "wav", "amr", "ogg", "3gp")
            }?.forEach { f ->
                discovered[f.absolutePath] = f
            }
        }

        // MediaStore.Audio fallback for Android 13/14/15 Scoped Storage
        runCatching {
            val projection = arrayOf(
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DISPLAY_NAME
            )
            val selection = "${MediaStore.Audio.Media.DATA} LIKE ? OR ${MediaStore.Audio.Media.DATA} LIKE ? OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("%Recordings/Call%", "%/Call/%", "Call recording%")
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                args,
                "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val path = cursor.getString(0) ?: continue
                    val f = File(path)
                    if (f.exists() && f.isFile) {
                        discovered[f.absolutePath] = f
                    }
                }
            }
        }

        return discovered.values.sortedByDescending { it.lastModified() }
    }

    /**
     * Links every verified recording to its exact call and returns both the count of newly linked
     * recordings AND any unmatched recordings (so old/ambiguous audio is never lost or mislinked).
     */
    suspend fun scanAndLinkAllRecordings(): Pair<Int, List<UnmatchedRecordingFile>> = withContext(Dispatchers.IO) {
        val allAudioFiles = discoverAllRecordingFiles()
        val alreadyLinkedPaths = callLogDao.getAllLinkedRecordingPaths().toHashSet()
        var linkedCount = 0
        val unmatchedList = mutableListOf<UnmatchedRecordingFile>()

        for (audioFile in allAudioFiles) {
            if (alreadyLinkedPaths.contains(audioFile.absolutePath)) continue

            val fileNameNoExt = audioFile.nameWithoutExtension
            val audioDurationSec = readAudioDurationSeconds(audioFile)
            val parsedTimestamp = extractTimestampFromFilename(fileNameNoExt) ?: audioFile.lastModified()
            val parsedDigits = extractPhoneDigitsFromFilename(fileNameNoExt)
            val parsedName = extractContactNameFromFilename(fileNameNoExt)

            // Search +/- 10 minutes around the recording timestamp
            val candidates = callLogDao.findUnlinkedCallsInWindow(
                parsedTimestamp - 600_000L,
                parsedTimestamp + 600_000L
            )

            val bestMatch = if (candidates.isNotEmpty()) {
                selectStrictMatchingCall(
                    candidates = candidates,
                    parsedDigits = parsedDigits,
                    parsedName = parsedName,
                    audioDurationSec = audioDurationSec,
                    recordingTimeMillis = parsedTimestamp
                )
            } else null

            val sourceTag = if (audioFile.absolutePath.contains(context.filesDir.absolutePath)) {
                "BUILTIN_RECORDER"
            } else {
                "SAMSUNG_NATIVE"
            }

            if (bestMatch != null) {
                callLogDao.attachRecordingToCall(
                    callId = bestMatch.id,
                    filePath = audioFile.absolutePath,
                    source = sourceTag
                )
                alreadyLinkedPaths.add(audioFile.absolutePath)
                linkedCount++
            } else {
                unmatchedList.add(
                    UnmatchedRecordingFile(
                        filePath = audioFile.absolutePath,
                        displayName = fileNameNoExt.removePrefix("Call recording ").trim().ifBlank { audioFile.name },
                        timestampMillis = parsedTimestamp,
                        durationSeconds = audioDurationSec ?: 0L,
                        fileSizeBytes = audioFile.length(),
                        source = sourceTag
                    )
                )
            }
        }

        linkedCount to unmatchedList
    }

    private fun selectStrictMatchingCall(
        candidates: List<CallLogEntry>,
        parsedDigits: String?,
        parsedName: String?,
        audioDurationSec: Long?,
        recordingTimeMillis: Long
    ): CallLogEntry? {
        val scored = candidates.mapNotNull { call ->
            if (call.durationSeconds <= 0L) return@mapNotNull null

            val callDigits = call.normalizedNumber.replace(Regex("[^0-9]"), "")
            val hasPhoneMatch = if (parsedDigits != null) {
                val suffixLen = minOf(7, parsedDigits.length, callDigits.length)
                if (suffixLen < 7) return@mapNotNull null
                val matches = callDigits.endsWith(parsedDigits.takeLast(suffixLen)) ||
                    parsedDigits.endsWith(callDigits.takeLast(suffixLen))
                if (!matches) return@mapNotNull null
                true
            } else false

            val hasNameMatch = if (!hasPhoneMatch && !parsedName.isNullOrBlank()) {
                val cName = call.contactName?.trim()?.lowercase() ?: ""
                val pName = parsedName.trim().lowercase()
                cName.isNotBlank() && (cName == pName || cName.contains(pName) || pName.contains(cName))
            } else false

            if (parsedDigits == null && !parsedName.isNullOrBlank() && !hasNameMatch) {
                return@mapNotNull null
            }

            val durationDiff = if (audioDurationSec != null && audioDurationSec > 0L) {
                abs(audioDurationSec - call.durationSeconds)
            } else 0L

            val maxAllowedDurDiff = maxOf(12L, (call.durationSeconds * 0.25).toLong())
            if (audioDurationSec != null && audioDurationSec > 0L && durationDiff > maxAllowedDurDiff) {
                return@mapNotNull null
            }

            val callEndMillis = call.timestamp + (call.durationSeconds * 1000L)
            val minTimeDiff = minOf(abs(recordingTimeMillis - call.timestamp), abs(recordingTimeMillis - callEndMillis))

            if (!hasPhoneMatch && !hasNameMatch) {
                if (minTimeDiff > 15_000L || durationDiff > 4L) return@mapNotNull null
            }

            val score = (if (hasPhoneMatch) 1000L else 0L) +
                (if (hasNameMatch) 500L else 0L) -
                (minTimeDiff / 1000L) -
                (durationDiff * 10L)

            call to score
        }

        if (scored.isEmpty()) return null
        val sorted = scored.sortedByDescending { it.second }
        if (parsedDigits == null && parsedName == null && sorted.size > 1) {
            if (abs(sorted[0].second - sorted[1].second) < 20L) return null
        }
        return sorted.first().first
    }

    private fun readAudioDurationSeconds(file: File): Long? {
        return runCatching {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(file.absolutePath)
            val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            retriever.release()
            durStr?.toLongOrNull()?.div(1000L)
        }.getOrNull()
    }

    /**
     * Space-tolerant phone digit extractor for Samsung filenames like:
     * "Call recording +91 98765 43210_261119_140512"
     */
    private fun extractPhoneDigitsFromFilename(name: String): String? {
        val withoutDateTail = name.replace(Regex("_\\d{6,8}_\\d{6}$"), "")
        val strippedPrefix = withoutDateTail.removePrefix("Call recording ").removePrefix("Call_").trim()
        val compact = strippedPrefix.replace(Regex("[\\s\\-()]"), "")
        val match = Regex("(\\+?\\d{7,15})").find(compact) ?: return null
        return match.value.replace(Regex("[^0-9]"), "")
    }

    private fun extractContactNameFromFilename(name: String): String? {
        val withoutDateTail = name.replace(Regex("_\\d{6,8}_\\d{6}$"), "")
        val cleaned = withoutDateTail.removePrefix("Call recording ").removePrefix("Call_").trim()
        if (cleaned.isBlank() || cleaned.all { it.isDigit() || it in setOf('+', '-', ' ', '(', ')') }) {
            return null
        }
        return cleaned
    }

    private fun extractTimestampFromFilename(name: String): Long? {
        val m8 = Regex("(\\d{8}_\\d{6})$").find(name)
        if (m8 != null) {
            return runCatching { SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).parse(m8.value)?.time }.getOrNull()
        }
        val m6 = Regex("(\\d{6}_\\d{6})$").find(name)
        if (m6 != null) {
            return runCatching { SimpleDateFormat("yyMMdd_HHmmss", Locale.US).parse(m6.value)?.time }.getOrNull()
        }
        return null
    }

    @SuppressLint("MissingPermission")
    private fun buildSimSlotMap(): Map<String, String> {
        val map = mutableMapOf<String, String>()
        runCatching {
            val subManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
            subManager?.activeSubscriptionInfoList?.forEach { info ->
                val label = "SIM ${info.simSlotIndex + 1}"
                map[info.subscriptionId.toString()] = label
                if (!info.iccId.isNullOrBlank()) map[info.iccId] = label
            }
        }
        return map
    }

    @SuppressLint("MissingPermission")
    fun detectSimPhoneNumber(): String {
        return try {
            val subManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
            val activeList = subManager?.activeSubscriptionInfoList
            val firstSimNumber = activeList?.firstOrNull { !it.number.isNullOrBlank() }?.number
            if (!firstSimNumber.isNullOrBlank()) {
                normalizePhoneNumber(firstSimNumber)
            } else {
                val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
                val line1 = tm?.line1Number
                if (!line1.isNullOrBlank()) normalizePhoneNumber(line1) else ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    fun normalizePhoneNumber(raw: String): String {
        val cleaned = PhoneNumberUtils.normalizeNumber(raw) ?: raw
        return if (cleaned.length > 10 && !cleaned.startsWith("+")) "+$cleaned" else cleaned.ifBlank { "Unknown" }
    }

    suspend fun getAllCallsForBackup(): List<CallLogEntry> = callLogDao.getAllCallsSnapshot()

    suspend fun restoreCallsFromBackup(backupCalls: List<CallLogEntry>): Int = withContext(Dispatchers.IO) {
        val results = callLogDao.insertCallsIgnoreDuplicate(backupCalls.map { it.copy(id = 0) })
        results.count { it != -1L }
    }
}
