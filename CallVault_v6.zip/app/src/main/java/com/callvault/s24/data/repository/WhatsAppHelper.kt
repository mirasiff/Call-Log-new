package com.callvault.s24.data.repository

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract

object WhatsAppHelper {

    private fun formatForWhatsApp(rawNumber: String): String {
        val digitsOnly = rawNumber.replace(Regex("[^0-9+]"), "")
        return when {
            digitsOnly.startsWith("+") -> digitsOnly.removePrefix("+")
            digitsOnly.startsWith("00") -> digitsOnly.removePrefix("00")
            digitsOnly.length == 10 -> "91$digitsOnly"
            digitsOnly.startsWith("0") && digitsOnly.length == 11 -> "91${digitsOnly.drop(1)}"
            else -> digitsOnly
        }
    }

    fun openWhatsAppChat(context: Context, rawNumber: String): Boolean {
        val waNumber = formatForWhatsApp(rawNumber)
        if (waNumber.isBlank()) return false

        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$waNumber")
        val packagesToTry = listOf("com.whatsapp", "com.whatsapp.w4b")

        for (pkg in packagesToTry) {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage(pkg)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (runCatching { context.startActivity(intent) }.isSuccess) {
                return true
            }
        }

        return runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        }.isSuccess
    }

    fun startWhatsAppVoiceCall(context: Context, rawNumber: String): Boolean {
        return launchWhatsAppMimeCall(
            context = context,
            rawNumber = rawNumber,
            mimeTypes = listOf(
                "vnd.android.cursor.item/vnd.com.whatsapp.voip.call" to "com.whatsapp",
                "vnd.android.cursor.item/vnd.com.whatsapp.w4b.voip.call" to "com.whatsapp.w4b"
            )
        )
    }

    fun startWhatsAppVideoCall(context: Context, rawNumber: String): Boolean {
        return launchWhatsAppMimeCall(
            context = context,
            rawNumber = rawNumber,
            mimeTypes = listOf(
                "vnd.android.cursor.item/vnd.com.whatsapp.video.call" to "com.whatsapp",
                "vnd.android.cursor.item/vnd.com.whatsapp.w4b.video.call" to "com.whatsapp.w4b"
            )
        )
    }

    @SuppressLint("Range")
    private fun launchWhatsAppMimeCall(
        context: Context,
        rawNumber: String,
        mimeTypes: List<Pair<String, String>>
    ): Boolean {
        val targetLast10 = rawNumber.replace(Regex("[^0-9]"), "").takeLast(10)
        if (targetLast10.length >= 7) {
            for ((mime, pkg) in mimeTypes) {
                runCatching {
                    context.contentResolver.query(
                        ContactsContract.Data.CONTENT_URI,
                        arrayOf(ContactsContract.Data._ID, ContactsContract.Data.DATA1, ContactsContract.Data.DATA3),
                        "${ContactsContract.Data.MIMETYPE} = ?",
                        arrayOf(mime),
                        null
                    )?.use { cursor ->
                        while (cursor.moveToNext()) {
                            val dataId = cursor.getLong(0)
                            val d1 = (cursor.getString(1) ?: "").replace(Regex("[^0-9]"), "")
                            val d3 = (cursor.getString(2) ?: "").replace(Regex("[^0-9]"), "")
                            if (d1.endsWith(targetLast10) || d3.endsWith(targetLast10)) {
                                val callUri = Uri.withAppendedPath(ContactsContract.Data.CONTENT_URI, dataId.toString())
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(callUri, mime)
                                    setPackage(pkg)
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                if (runCatching { context.startActivity(intent) }.isSuccess) {
                                    return true
                                }
                            }
                        }
                    }
                }
            }
        }
        return openWhatsAppChat(context, rawNumber)
    }
}
