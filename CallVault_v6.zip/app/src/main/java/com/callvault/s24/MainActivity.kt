package com.callvault.s24

import android.Manifest
import android.accounts.AccountManager
import android.app.Activity
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.repository.DeviceContact
import com.callvault.s24.ui.MainViewModel
import com.callvault.s24.ui.screens.AnalyticsDashboardScreen
import com.callvault.s24.ui.screens.CallDetailBottomSheet
import com.callvault.s24.ui.screens.CallLongPressMenuSheet
import com.callvault.s24.ui.screens.CallRecordingsScreen
import com.callvault.s24.ui.screens.ContactDetailBottomSheet
import com.callvault.s24.ui.screens.ContactLongPressMenuSheet
import com.callvault.s24.ui.screens.ContactTimelineSheet
import com.callvault.s24.ui.screens.ContactsListScreen
import com.callvault.s24.ui.screens.MessageMethodChoiceSheet
import com.callvault.s24.ui.screens.SettingsAndBackupSheet
import com.callvault.s24.ui.screens.T9DialPadSheet
import com.callvault.s24.ui.screens.TabSpecificSettingsSheet
import com.callvault.s24.ui.screens.UnlimitedCallLogScreen
import com.callvault.s24.ui.theme.CallVaultTheme
import com.callvault.s24.ui.theme.SamsungGreenCall

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            CallVaultTheme {
                var currentTab by remember { mutableIntStateOf(0) }
                var showDialPad by remember { mutableStateOf(false) }
                var showTabSettingsSheet by remember { mutableStateOf(false) }
                var showGlobalBackupSheet by remember { mutableStateOf(false) }
                var selectedCall by remember { mutableStateOf<CallLogEntry?>(null) }
                var longPressedCall by remember { mutableStateOf<CallLogEntry?>(null) }
                var longPressedContact by remember { mutableStateOf<DeviceContact?>(null) }
                var selectedContactHistory by remember { mutableStateOf<Pair<String, String>?>(null) }
                var swipeLeftMessageTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
                var selectedContactDetail by remember { mutableStateOf<DeviceContact?>(null) }
                var pendingRingtoneContactId by remember { mutableStateOf<String?>(null) }
                val snackbarHostState = remember { SnackbarHostState() }

                val calls by viewModel.filteredCallLogs.collectAsState()
                val totalCount by viewModel.totalCallCount.collectAsState()
                val contacts by viewModel.contacts.collectAsState()
                val unmatchedRecordings by viewModel.unmatchedRecordings.collectAsState()
                val recordedCalls by viewModel.recordedCalls.collectAsState()
                val summaryStats by viewModel.summaryStats.collectAsState()
                val dailyCallBars by viewModel.dailyCallBars.collectAsState()
                val timeOfDayBreakdown by viewModel.timeOfDayBreakdown.collectAsState()
                val contactStats by viewModel.contactAnalytics.collectAsState()
                val settings by viewModel.settings.collectAsState()
                val searchQuery by viewModel.searchQuery.collectAsState()
                val callTypeFilter by viewModel.callTypeFilter.collectAsState()
                val onlyRecorded by viewModel.onlyRecordedFilter.collectAsState()
                val simFilter by viewModel.simFilter.collectAsState()
                val starredOnly by viewModel.starredRecordingsOnly.collectAsState()
                val analyticsRangeDays by viewModel.analyticsRangeDays.collectAsState()
                val statusBanner by viewModel.statusBanner.collectAsState()
                val settingsFeedback by viewModel.settingsFeedback.collectAsState()
                val isDriveUploading by viewModel.isDriveUploading.collectAsState()
                val driveProgressMessage by viewModel.driveProgressMessage.collectAsState()
                val pendingConsentIntent by viewModel.pendingDriveConsentIntent.collectAsState()
                val audioState by viewModel.audioState.collectAsState()
                val availableBackups by viewModel.availableBackups.collectAsState()
                val blockedNumbers by viewModel.blockedNumbers.collectAsState()
                val speedDials by viewModel.speedDials.collectAsState()

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) {
                    viewModel.syncSystemCallLogNow()
                }

                val accountPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    if (result.resultCode == Activity.RESULT_OK) {
                        val accountName = result.data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME)
                        if (!accountName.isNullOrBlank()) {
                            viewModel.updateGoogleAccountEmail(accountName, triggerBackupImmediately = true)
                        }
                    }
                }

                val driveConsentLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    viewModel.clearPendingDriveConsent()
                    if (result.resultCode == Activity.RESULT_OK) {
                        viewModel.triggerImmediateBackup()
                    } else {
                        viewModel.showStatusMessage("Google Drive permission was cancelled.")
                    }
                }

                val dialerRoleLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) {
                    viewModel.syncSystemCallLogNow()
                }

                val ringtonePickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    val cid = pendingRingtoneContactId
                    pendingRingtoneContactId = null
                    if (result.resultCode == Activity.RESULT_OK && cid != null) {
                        @Suppress("DEPRECATION")
                        val uri = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                        viewModel.setContactRingtone(cid, uri)
                    }
                }

                val restoreFileLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocument()
                ) { uri ->
                    if (uri != null) viewModel.restoreFromUri(uri)
                }

                val requestDefaultDialerAction: () -> Unit = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val roleManager = getSystemService(RoleManager::class.java)
                        if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                            dialerRoleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER))
                        }
                    } else {
                        val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).apply {
                            putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                        }
                        dialerRoleLauncher.launch(intent)
                    }
                }

                val copyNumberToClipboard: (String) -> Unit = { number ->
                    val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cb.setPrimaryClip(ClipData.newPlainText("Phone", number))
                    viewModel.showStatusMessage("Copied $number")
                }

                LaunchedEffect(pendingConsentIntent) {
                    val intent = pendingConsentIntent
                    if (intent != null) driveConsentLauncher.launch(intent)
                }

                LaunchedEffect(statusBanner) {
                    val msg = statusBanner
                    if (msg != null) {
                        snackbarHostState.showSnackbar(message = msg, actionLabel = "OK")
                        viewModel.dismissBanner()
                    }
                }

                LaunchedEffect(Unit) {
                    val perms = mutableListOf(
                        Manifest.permission.READ_CALL_LOG,
                        Manifest.permission.WRITE_CALL_LOG,
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.WRITE_CONTACTS,
                        Manifest.permission.READ_SMS,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.RECORD_AUDIO
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        perms.add(Manifest.permission.READ_PHONE_NUMBERS)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.READ_MEDIA_AUDIO)
                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
                    }
                    permissionLauncher.launch(perms.toTypedArray())
                }

                Scaffold(
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    floatingActionButton = {
                        if (currentTab == 0 || currentTab == 1) {
                            FloatingActionButton(
                                onClick = { showDialPad = true },
                                shape = CircleShape,
                                containerColor = SamsungGreenCall,
                                contentColor = Color.White
                            ) {
                                Icon(Icons.Default.Dialpad, contentDescription = "Open Keypad")
                            }
                        }
                    },
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = currentTab == 0,
                                onClick = { currentTab = 0 },
                                icon = { Icon(Icons.Default.Call, contentDescription = "Recents") },
                                label = { Text("Recents") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 1,
                                onClick = {
                                    currentTab = 1
                                    viewModel.loadContacts()
                                },
                                icon = { Icon(Icons.Default.Contacts, contentDescription = "Contacts") },
                                label = { Text("Contacts") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 2,
                                onClick = { currentTab = 2 },
                                icon = { Icon(Icons.Default.Analytics, contentDescription = "Analytics") },
                                label = { Text("Analytics") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 3,
                                onClick = { currentTab = 3 },
                                icon = { Icon(Icons.Default.GraphicEq, contentDescription = "Recordings") },
                                label = { Text("Recordings") }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                        when (currentTab) {
                            0 -> UnlimitedCallLogScreen(
                                calls = calls,
                                totalVaultCount = totalCount,
                                settings = settings,
                                audioState = audioState,
                                searchQuery = searchQuery,
                                onSearchChange = viewModel::setSearchQuery,
                                selectedFilter = callTypeFilter,
                                onFilterChange = viewModel::setCallTypeFilter,
                                onlyRecorded = onlyRecorded,
                                onToggleOnlyRecorded = viewModel::toggleOnlyRecordedFilter,
                                simFilter = simFilter,
                                onSimFilterChange = viewModel::setSimFilter,
                                onToggleCollapse = viewModel::updateCollapseConsecutiveCalls,
                                onTogglePlayRecording = viewModel::togglePlayRecording,
                                onLoadMore = viewModel::loadMoreCalls,
                                onSyncNow = viewModel::syncSystemCallLogNow,
                                onOpenSettings = { showTabSettingsSheet = true },
                                onSelectCall = { selectedCall = it },
                                onLongPressCall = { longPressedCall = it },
                                onSwipeLeftMessageChoice = { name, num -> swipeLeftMessageTarget = name to num }
                            )
                            1 -> ContactsListScreen(
                                contacts = contacts,
                                showActivitySubtitles = settings.showContactActivitySubtitles,
                                storageLocation = settings.contactStorageLocation,
                                onOpenSettings = { showTabSettingsSheet = true },
                                onSelectContactDetail = { selectedContactDetail = it },
                                onLongPressContact = { longPressedContact = it },
                                onSwipeLeftMessageChoice = { name, num -> swipeLeftMessageTarget = name to num }
                            )
                            2 -> AnalyticsDashboardScreen(
                                summary = summaryStats,
                                dailyBars = dailyCallBars,
                                timeOfDaySlices = timeOfDayBreakdown,
                                contactStats = contactStats,
                                selectedRangeDays = analyticsRangeDays,
                                onRangeChange = viewModel::setAnalyticsRangeDays,
                                onOpenSettings = { showTabSettingsSheet = true },
                                onOpenContactHistory = { num, name -> selectedContactHistory = num to name }
                            )
                            3 -> CallRecordingsScreen(
                                recordedCalls = recordedCalls,
                                unmatchedRecordings = unmatchedRecordings,
                                settings = settings,
                                audioState = audioState,
                                starredOnly = starredOnly,
                                onToggleStarredOnly = viewModel::toggleStarredRecordingsOnly,
                                onTogglePlay = viewModel::togglePlayRecording,
                                onSeekAudio = viewModel::seekAudioTo,
                                onCycleSpeed = viewModel::cyclePlaybackSpeed,
                                onShareRecording = viewModel::shareRecordingFile,
                                onToggleStar = viewModel::toggleStarRecording,
                                onDeleteRecording = viewModel::deleteRecordingFile,
                                onToggleAutoRecord = viewModel::updateAutoRecord,
                                onRescanSamsungRecordings = viewModel::syncSystemCallLogNow,
                                onOpenSettings = { showTabSettingsSheet = true }
                            )
                        }

                        if (showDialPad) {
                            T9DialPadSheet(
                                contacts = contacts,
                                recentCalls = calls,
                                speedDials = speedDials,
                                storageLocation = settings.contactStorageLocation,
                                hapticsEnabled = settings.dialpadHapticsEnabled,
                                onDismiss = { showDialPad = false }
                            )
                        }

                        swipeLeftMessageTarget?.let { (name, num) ->
                            MessageMethodChoiceSheet(
                                displayName = name,
                                phoneNumber = num,
                                onDismiss = { swipeLeftMessageTarget = null }
                            )
                        }

                        longPressedCall?.let { call ->
                            CallLongPressMenuSheet(
                                call = call,
                                storageLocation = settings.contactStorageLocation,
                                onDismiss = { longPressedCall = null },
                                onCopyNumber = copyNumberToClipboard,
                                onBlockNumber = viewModel::blockNumber,
                                onDeleteCall = viewModel::deleteCallEntry
                            )
                        }

                        longPressedContact?.let { contact ->
                            ContactLongPressMenuSheet(
                                contact = contact,
                                onDismiss = { longPressedContact = null },
                                onCopyNumber = copyNumberToClipboard,
                                onAssignSpeedDial = viewModel::setSpeedDial
                            )
                        }

                        selectedCall?.let { call ->
                            val isFav = settings.favoriteNumbers.any { call.normalizedNumber.endsWith(it.takeLast(10)) }
                            CallDetailBottomSheet(
                                call = call,
                                audioState = audioState,
                                isFavorite = isFav,
                                storageLocation = settings.contactStorageLocation,
                                onDismiss = { selectedCall = null },
                                onTogglePlay = viewModel::togglePlayRecording,
                                onSeekAudio = viewModel::seekAudioTo,
                                onCycleSpeed = viewModel::cyclePlaybackSpeed,
                                onShareRecording = viewModel::shareRecordingFile,
                                onToggleStarRecording = viewModel::toggleStarRecording,
                                onSaveNote = viewModel::saveCallNote,
                                onToggleFavorite = viewModel::toggleFavoriteNumber,
                                onBlockNumber = viewModel::blockNumber,
                                onOpenContactHistory = { num, name -> selectedContactHistory = num to name }
                            )
                        }

                        selectedContactDetail?.let { contact ->
                            val vib = settings.contactVibrations[contact.id] ?: "Default"
                            val primaryNorm = contact.phoneNumber.replace(Regex("[^0-9+]"), "")
                            ContactDetailBottomSheet(
                                contact = contact,
                                selectedVibration = vib,
                                callsFlow = viewModel.observeHistoryForContact(primaryNorm),
                                onDismiss = { selectedContactDetail = null },
                                onPickRingtone = { c ->
                                    pendingRingtoneContactId = c.id
                                    val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE)
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Ringtone for ${c.name}")
                                        if (!c.customRingtoneUri.isNullOrBlank()) {
                                            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(c.customRingtoneUri))
                                        }
                                    }
                                    ringtonePickerLauncher.launch(intent)
                                },
                                onSelectVibration = viewModel::setContactVibration,
                                onSelectCall = { selectedCall = it }
                            )
                        }

                        selectedContactHistory?.let { (num, title) ->
                            ContactTimelineSheet(
                                contactTitle = title,
                                normalizedNumber = num,
                                callsFlow = viewModel.observeHistoryForContact(num),
                                onDismiss = { selectedContactHistory = null },
                                onSelectCall = { selectedCall = it }
                            )
                        }

                        if (showTabSettingsSheet) {
                            TabSpecificSettingsSheet(
                                activeTab = currentTab,
                                settings = settings,
                                speedDials = speedDials,
                                blockedNumbers = blockedNumbers,
                                simFilter = simFilter,
                                analyticsRangeDays = analyticsRangeDays,
                                onDismiss = { showTabSettingsSheet = false },
                                onOpenCloudBackupAndAbout = {
                                    viewModel.clearSettingsFeedback()
                                    viewModel.refreshAvailableBackupSlots()
                                    showGlobalBackupSheet = true
                                },
                                onToggleCollapse = viewModel::updateCollapseConsecutiveCalls,
                                onToggleHaptics = viewModel::updateDialpadHaptics,
                                onRemoveSpeedDial = viewModel::removeSpeedDial,
                                onUnblockNumber = viewModel::unblockNumber,
                                onSelectContactStorage = viewModel::updateContactStorageLocation,
                                onToggleContactSubtitles = viewModel::updateShowContactActivitySubtitles,
                                onSimFilterChange = viewModel::setSimFilter,
                                onAnalyticsRangeChange = viewModel::setAnalyticsRangeDays,
                                onExportCsv = viewModel::exportAndShareCsv,
                                onToggleAutoRecord = viewModel::updateAutoRecord,
                                onToggleHideNotification = viewModel::updateHideRecordingNotification,
                                onSelectEngineMode = viewModel::updateRecordingEngineMode,
                                onSelectRecordingRule = viewModel::updateRecordingRule,
                                onRequestDefaultDialerRole = requestDefaultDialerAction
                            )
                        }

                        if (showGlobalBackupSheet) {
                            SettingsAndBackupSheet(
                                settings = settings,
                                availableBackups = availableBackups,
                                blockedNumbers = blockedNumbers,
                                settingsFeedback = settingsFeedback,
                                isDriveUploading = isDriveUploading,
                                driveProgressMessage = driveProgressMessage,
                                onDismiss = { showGlobalBackupSheet = false },
                                onSavePhoneNumber = viewModel::updateRegisteredPhoneNumber,
                                onSelectGoogleAccount = {
                                    val pickerIntent = AccountManager.newChooseAccountIntent(
                                        null, null, arrayOf("com.google"), null, null, null, null
                                    )
                                    accountPickerLauncher.launch(pickerIntent)
                                },
                                onSignOutGoogleAccount = viewModel::signOutGoogleAccount,
                                onToggleAutoBackup = viewModel::updateAutoBackupEnabled,
                                onBackupNow = viewModel::triggerImmediateBackup,
                                onRefreshBackups = viewModel::refreshAvailableBackupSlots,
                                onRestoreSlot = viewModel::restoreFromSlot,
                                onExportCsv = viewModel::exportAndShareCsv,
                                onExportJson = viewModel::exportAndShareJson,
                                onImportJsonFile = { restoreFileLauncher.launch(arrayOf("application/json", "*/*")) },
                                onToggleHideNotification = viewModel::updateHideRecordingNotification,
                                onSelectEngineMode = viewModel::updateRecordingEngineMode,
                                onSelectRecordingRule = viewModel::updateRecordingRule,
                                onToggleHaptics = viewModel::updateDialpadHaptics,
                                onUnblockNumber = viewModel::unblockNumber,
                                onRequestDefaultDialerRole = requestDefaultDialerAction,
                                onShowMessage = viewModel::showStatusMessage
                            )
                        }
                    }
                }
            }
        }
    }
}
