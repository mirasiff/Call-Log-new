package com.callvault.s24.data.repository

import android.annotation.SuppressLint
import android.accounts.Account
import android.accounts.AccountManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import androidx.core.content.FileProvider
import com.callvault.s24.data.local.CallLogDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class ContactPhoneEntry(
    val number: String,
    val label: String // "Mobile", "Work", "Home", etc.
)

data class DeviceContact(
    val id: String,
    val lookupKey: String = "",
    val name: String,
    val phoneNumber: String, // Primary number
    val allNumbers: List<ContactPhoneEntry> = emptyList(),
    val email: String? = null,
    val customRingtoneUri: String? = null,
    val photoUri: String? = null,
    val isStarred: Boolean = false,
    val lastActivitySummary: String = "No recent activity",
    val lastActivityTimestamp: Long = 0L
)

object ContactsHelper {

    private data class SmsInfo(val timestamp: Long, val isIncoming: Boolean)

    val vibrationPatterns = mapOf(
        "Default" to longArrayOf(0, 250, 150, 250),
        "Short Pulse" to longArrayOf(0, 100, 80, 100, 80, 100),
        "Heartbeat" to longArrayOf(0, 120, 90, 280, 220, 120, 90, 280),
        "Long Wave" to longArrayOf(0, 500, 200, 500),
        "Silent" to longArrayOf(0)
    )

    @SuppressLint("MissingPermission")
    fun previewVibrationPattern(context: Context, patternName: String) {
        val timings = vibrationPatterns[patternName] ?: return
        if (timings.size <= 1) return
        runCatching {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(timings, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(timings, -1)
            }
        }
    }

    /**
     * Groups ALL phone numbers under each contact ID (Mobile, Work, Home), loads emails,
     * custom ringtones, photo URIs, and attaches intelligent Call/SMS activity summaries.
     */
    @SuppressLint("Range")
    suspend fun loadEnrichedContacts(context: Context, dao: CallLogDao): List<DeviceContact> =
        withContext(Dispatchers.IO) {
            val grouped = LinkedHashMap<String, MutableList<ContactPhoneEntry>>()
            val metaMap = HashMap<String, DeviceContact>()

            runCatching {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                        ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY,
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER,
                        ContactsContract.CommonDataKinds.Phone.TYPE,
                        ContactsContract.CommonDataKinds.Phone.LABEL,
                        ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI,
                        ContactsContract.CommonDataKinds.Phone.STARRED,
                        ContactsContract.CommonDataKinds.Phone.CUSTOM_RINGTONE
                    ),
                    null,
                    null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )?.use { cursor ->
                    while (cursor.moveToNext()) {
                        val id = cursor.getString(0) ?: continue
                        val lookup = cursor.getString(1) ?: ""
                        val name = cursor.getString(2)?.takeIf { it.isNotBlank() } ?: "Unknown"
                        val number = cursor.getString(3)?.trim() ?: continue
                        val type = cursor.getInt(4)
                        val customLabel = cursor.getString(5)
                        val photo = cursor.getString(6)
                        val starred = cursor.getInt(7) == 1
                        val ringtone = cursor.getString(8)

                        val typeLabel = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
                            context.resources, type, customLabel
                        ).toString()

                        val numList = grouped.getOrPut(id) { mutableListOf() }
                        val normalizedNew = number.replace(Regex("[^0-9+]"), "")
                        if (numList.none { it.number.replace(Regex("[^0-9+]"), "") == normalizedNew }) {
                            numList.add(ContactPhoneEntry(number, typeLabel))
                        }

                        if (!metaMap.containsKey(id)) {
                            metaMap[id] = DeviceContact(
                                id = id,
                                lookupKey = lookup,
                                name = name,
                                phoneNumber = number,
                                customRingtoneUri = ringtone,
                                photoUri = photo,
                                isStarred = starred
                            )
                        }
                    }
                }
            }

            // Load emails per contact ID
            val emailMap = HashMap<String, String>()
            runCatching {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Email.CONTACT_ID, ContactsContract.CommonDataKinds.Email.ADDRESS),
                    null, null, null
                )?.use { cursor ->
                    while (cursor.moveToNext()) {
                        val cid = cursor.getString(0) ?: continue
                        val addr = cursor.getString(1) ?: continue
                        if (!emailMap.containsKey(cid)) emailMap[cid] = addr
                    }
                }
            }

            val latestCallBySuffix = runCatching {
                dao.getLatestCallPerNumber().associateBy {
                    it.normalizedNumber.replace(Regex("[^0-9]"), "").takeLast(10)
                }
            }.getOrDefault(emptyMap())

            val latestSmsBySuffix = loadLatestSmsMap(context)

            metaMap.values.map { base ->
                val numbers = grouped[base.id].orEmpty()
                var bestTs = 0L
                var bestSummary = if (numbers.size > 1) "${numbers.size} phone numbers" else base.phoneNumber

                for (entry in numbers) {
                    val suffix = entry.number.replace(Regex("[^0-9]"), "").takeLast(10)
                    if (suffix.length < 7) continue

                    val lastCall = latestCallBySuffix[suffix]
                    val lastSms = latestSmsBySuffix[suffix]

                    if (lastCall != null && lastCall.timestamp > bestTs) {
                        bestTs = lastCall.timestamp
                        val label = when (lastCall.callType) {
                            CallLog.Calls.INCOMING_TYPE -> "Last incoming call"
                            CallLog.Calls.OUTGOING_TYPE -> "Last outgoing call"
                            CallLog.Calls.MISSED_TYPE -> "Last missed call"
                            CallLog.Calls.REJECTED_TYPE -> "Last rejected call"
                            else -> "Last called"
                        }
                        bestSummary = "$label • ${formatSmartRelativeTime(bestTs)}"
                    }
                    if (lastSms != null && lastSms.timestamp > bestTs) {
                        bestTs = lastSms.timestamp
                        val dir = if (lastSms.isIncoming) "Last message received" else "Last message sent"
                        bestSummary = "$dir • ${formatSmartRelativeTime(bestTs)}"
                    }
                }

                base.copy(
                    allNumbers = numbers,
                    email = emailMap[base.id],
                    lastActivitySummary = bestSummary,
                    lastActivityTimestamp = bestTs
                )
            }
        }

    fun getAvailableGoogleAccounts(context: Context): List<String> {
        return runCatching {
            AccountManager.get(context).getAccountsByType("com.google").map { it.name }
        }.getOrDefault(emptyList())
    }

    fun openAddNewContactIntent(
        context: Context,
        prefillNumber: String = "",
        storageLocation: String = "GOOGLE"
    ) {
        val intent = Intent(Intent.ACTION_INSERT).apply {
            type = ContactsContract.Contacts.CONTENT_TYPE
            if (prefillNumber.isNotBlank()) {
                putExtra(ContactsContract.Intents.Insert.PHONE, prefillNumber)
            }
            if (storageLocation.startsWith("GOOGLE:")) {
                val email = storageLocation.removePrefix("GOOGLE:")
                putExtra("com.android.contacts.extra.ACCOUNT", Account(email, "com.google"))
            } else if (storageLocation == "GOOGLE") {
                val firstGoogle = getAvailableGoogleAccounts(context).firstOrNull()
                if (firstGoogle != null) {
                    putExtra("com.android.contacts.extra.ACCOUNT", Account(firstGoogle, "com.google"))
                }
            }
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        runCatching { context.startActivity(intent) }
    }

    fun openAddToExistingContactIntent(context: Context, phoneNumber: String) {
        val intent = Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
            type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
            putExtra(ContactsContract.Intents.Insert.PHONE, phoneNumber)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        runCatching { context.startActivity(intent) }
    }

    fun openEditContactIntent(context: Context, contact: DeviceContact) {
        val contactUri = if (contact.lookupKey.isNotBlank()) {
            ContactsContract.Contacts.getLookupUri(contact.id.toLongOrNull() ?: 0L, contact.lookupKey)
        } else {
            ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contact.id.toLongOrNull() ?: 0L)
        }
        val intent = Intent(Intent.ACTION_EDIT).apply {
            setDataAndType(contactUri, ContactsContract.Contacts.CONTENT_ITEM_TYPE)
            putExtra("finishActivityOnSaveCompleted", true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        runCatching { context.startActivity(intent) }
    }

    fun shareContactAsVcf(context: Context, contact: DeviceContact) {
        runCatching {
            val exportsDir = File(context.filesDir, "exports").apply { mkdirs() }
            val safeName = contact.name.replace(Regex("[^A-Za-z0-9_ -]"), "").ifBlank { "Contact" }
            val vcfFile = File(exportsDir, "$safeName.vcf")
            val vcfText = buildString {
                appendLine("BEGIN:VCARD")
                appendLine("VERSION:3.0")
                appendLine("FN:${contact.name}")
                contact.allNumbers.forEach { entry ->
                    appendLine("TEL;TYPE=${entry.label.uppercase()}:${entry.number}")
                }
                if (!contact.email.isNullOrBlank()) {
                    appendLine("EMAIL:${contact.email}")
                }
                appendLine("END:VCARD")
            }
            vcfFile.writeText(vcfText)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", vcfFile)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/x-vcard"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share Contact (${contact.name})").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }

    fun updateContactCustomRingtone(context: Context, contactId: String, ringtoneUri: Uri?): Boolean {
        return runCatching {
            val idLong = contactId.toLongOrNull() ?: return false
            val contactUri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, idLong)
            val values = ContentValues().apply {
                put(ContactsContract.Contacts.CUSTOM_RINGTONE, ringtoneUri?.toString())
            }
            context.contentResolver.update(contactUri, values, null, null) > 0
        }.getOrDefault(false)
    }

    private fun loadLatestSmsMap(context: Context): Map<String, SmsInfo> {
        val map = HashMap<String, SmsInfo>()
        runCatching {
            context.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.DATE, Telephony.Sms.TYPE),
                null,
                null,
                "${Telephony.Sms.DATE} DESC LIMIT 500"
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val addr = cursor.getString(0) ?: continue
                    val date = cursor.getLong(1)
                    val type = cursor.getInt(2)
                    val suffix = addr.replace(Regex("[^0-9]"), "").takeLast(10)
                    if (suffix.length >= 7 && !map.containsKey(suffix)) {
                        map[suffix] = SmsInfo(date, type == Telephony.Sms.MESSAGE_TYPE_INBOX)
                    }
                }
            }
        }
        return map
    }

    fun formatSmartRelativeTime(epochMillis: Long): String {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply { timeInMillis = epochMillis }
        val timePart = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(epochMillis))

        return when {
            now.get(Calendar.YEAR) == target.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == target.get(Calendar.DAY_OF_YEAR) -> "Today, $timePart"
            now.get(Calendar.YEAR) == target.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) - target.get(Calendar.DAY_OF_YEAR) == 1 -> "Yesterday, $timePart"
            now.get(Calendar.YEAR) == target.get(Calendar.YEAR) ->
                SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(epochMillis))
            else ->
                SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(epochMillis))
        }
    }

    fun isNumberInContacts(context: Context, rawNumber: String): Boolean {
        return runCatching {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(rawNumber)
            )
            context.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)
                ?.use { it.moveToFirst() } ?: false
        }.getOrDefault(false)
    }

    @Suppress("DEPRECATION")
    fun getAppSigningSha1(context: Context): String {
        return runCatching {
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNING_CERTIFICATES
                )
            } else {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNATURES
                )
            }
            val sigBytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
            } else {
                info.signatures?.firstOrNull()?.toByteArray()
            } ?: return "Unavailable"

            val digest = MessageDigest.getInstance("SHA-1").digest(sigBytes)
            digest.joinToString(":") { "%02X".format(it) }
        }.getOrElse { "Unavailable" }
    }
}
