package com.callvault.s24.ui

import android.app.Application
import android.content.Intent
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.callvault.s24.backup.DriveBackupManager
import com.callvault.s24.backup.DriveBackupOutcome
import com.callvault.s24.backup.RemotePhoneBackupSlot
import com.callvault.s24.data.local.AppDatabase
import com.callvault.s24.data.local.AppPreferences
import com.callvault.s24.data.local.UserSettings
import com.callvault.s24.data.model.BlockedNumberEntity
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.CallSummaryStats
import com.callvault.s24.data.model.ContactAnalyticsItem
import com.callvault.s24.data.model.RecordingEngineMode
import com.callvault.s24.data.model.RecordingRule
import com.callvault.s24.data.model.SpeedDialEntity
import com.callvault.s24.data.repository.CallLogRepository
import com.callvault.s24.data.repository.ContactsHelper
import com.callvault.s24.data.repository.DeviceContact
import com.callvault.s24.data.repository.UnmatchedRecordingFile
import com.callvault.s24.worker.AutoBackupWorker
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

data class DailyCallBar(val dayLabel: String, val count: Int, val durationMinutes: Int)
data class TimeOfDaySlice(val label: String, val count: Int)

data class AudioPlayerState(
    val playingPath: String? = null,
    val isPlaying: Boolean = false,
    val positionMs: Int = 0,
    val durationMs: Int = 0,
    val speed: Float = 1.0f
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val repo = CallLogRepository(application, db.callLogDao())
    private val prefs = AppPreferences(application)
    private val backupManager = DriveBackupManager(application)

    private var mediaPlayer: MediaPlayer? = null

    val settings: StateFlow<UserSettings> = prefs.settingsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        UserSettings()
    )

    val totalCallCount: StateFlow<Int> = repo.observeTotalCallCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _callTypeFilter = MutableStateFlow(0)
    val callTypeFilter: StateFlow<Int> = _callTypeFilter.asStateFlow()

    private val _onlyRecordedFilter = MutableStateFlow(false)
    val onlyRecordedFilter: StateFlow<Boolean> = _onlyRecordedFilter.asStateFlow()

    private val _simFilter = MutableStateFlow("ALL")
    val simFilter: StateFlow<String> = _simFilter.asStateFlow()

    private val _pageLimit = MutableStateFlow(500)
    val pageLimit: StateFlow<Int> = _pageLimit.asStateFlow()

    private val _starredRecordingsOnly = MutableStateFlow(false)
    val starredRecordingsOnly: StateFlow<Boolean> = _starredRecordingsOnly.asStateFlow()

    private val _analyticsRangeDays = MutableStateFlow(0)
    val analyticsRangeDays: StateFlow<Int> = _analyticsRangeDays.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _settingsFeedback = MutableStateFlow<String?>(null)
    val settingsFeedback: StateFlow<String?> = _settingsFeedback.asStateFlow()

    private val _isDriveUploading = MutableStateFlow(false)
    val isDriveUploading: StateFlow<Boolean> = _isDriveUploading.asStateFlow()

    private val _driveProgressMessage = MutableStateFlow<String?>(null)
    val driveProgressMessage: StateFlow<String?> = _driveProgressMessage.asStateFlow()

    private val _pendingDriveConsentIntent = MutableStateFlow<Intent?>(null)
    val pendingDriveConsentIntent: StateFlow<Intent?> = _pendingDriveConsentIntent.asStateFlow()

    private val _audioState = MutableStateFlow(AudioPlayerState())
    val audioState: StateFlow<AudioPlayerState> = _audioState.asStateFlow()

    private val _availableBackups = MutableStateFlow<List<RemotePhoneBackupSlot>>(emptyList())
    val availableBackups: StateFlow<List<RemotePhoneBackupSlot>> = _availableBackups.asStateFlow()

    private val _contacts = MutableStateFlow<List<DeviceContact>>(emptyList())
    val contacts: StateFlow<List<DeviceContact>> = _contacts.asStateFlow()

    private val _unmatchedRecordings = MutableStateFlow<List<UnmatchedRecordingFile>>(emptyList())
    val unmatchedRecordings: StateFlow<List<UnmatchedRecordingFile>> = _unmatchedRecordings.asStateFlow()

    val blockedNumbers: StateFlow<List<BlockedNumberEntity>> = repo.observeBlockedNumbers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val speedDials: StateFlow<List<SpeedDialEntity>> = repo.observeSpeedDials()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredCallLogs: StateFlow<List<CallLogEntry>> = combine(
        _callTypeFilter,
        _onlyRecordedFilter,
        _simFilter,
        _searchQuery,
        _pageLimit
    ) { type, recOnly, sim, query, limit ->
        listOf(type, recOnly, sim, query, limit)
    }.flatMapLatest { params ->
        repo.observeFilteredCalls(
            callTypeFilter = params[0] as Int,
            onlyRecorded = params[1] as Boolean,
            simFilter = params[2] as String,
            searchQuery = params[3] as String,
            limitCount = params[4] as Int
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recordedCalls: StateFlow<List<CallLogEntry>> = _starredRecordingsOnly.flatMapLatest { starredOnly ->
        repo.observeRecordedCalls(starredOnly)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val summaryStats: StateFlow<CallSummaryStats> = combine(_analyticsRangeDays, _simFilter) { days, sim ->
        days to sim
    }.flatMapLatest { (days, sim) ->
        val since = if (days <= 0) 0L else System.currentTimeMillis() - (days * 86_400_000L)
        repo.observeSummaryStats(since, sim)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CallSummaryStats())

    val contactAnalytics: StateFlow<List<ContactAnalyticsItem>> = combine(_analyticsRangeDays, _simFilter) { days, sim ->
        days to sim
    }.flatMapLatest { (days, sim) ->
        val since = if (days <= 0) 0L else System.currentTimeMillis() - (days * 86_400_000L)
        repo.observeContactAnalytics(since, sim)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dailyCallBars: StateFlow<List<DailyCallBar>> = repo.observeAllCalls().combine(_simFilter) { all, sim ->
        val filtered = if (sim == "ALL") all else all.filter { it.simSlotLabel == sim }
        val cal = java.util.Calendar.getInstance()
        val sdf = java.text.SimpleDateFormat("EEE", java.util.Locale.getDefault())
        (6 downTo 0).map { daysAgo ->
            val c = java.util.Calendar.getInstance().apply {
                add(java.util.Calendar.DAY_OF_YEAR, -daysAgo)
                set(java.util.Calendar.HOUR_OF_DAY, 0)
                set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
            }
            val start = c.timeInMillis
            val end = start + 86_400_000L
            val dayCalls = filtered.filter { it.timestamp in start until end }
            DailyCallBar(
                dayLabel = sdf.format(c.time),
                count = dayCalls.size,
                durationMinutes = (dayCalls.sumOf { it.durationSeconds } / 60L).toInt()
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val timeOfDayBreakdown: StateFlow<List<TimeOfDaySlice>> = repo.observeAllCalls().combine(_analyticsRangeDays) { all, days ->
        val since = if (days <= 0) 0L else System.currentTimeMillis() - (days * 86_400_000L)
        val filtered = all.filter { it.timestamp >= since }
        var morning = 0; var afternoon = 0; var evening = 0; var night = 0
        val cal = java.util.Calendar.getInstance()
        for (call in filtered) {
            cal.timeInMillis = call.timestamp
            when (cal.get(java.util.Calendar.HOUR_OF_DAY)) {
                in 5..11 -> morning++
                in 12..16 -> afternoon++
                in 17..21 -> evening++
                else -> night++
            }
        }
        listOf(
            TimeOfDaySlice("Morning", morning),
            TimeOfDaySlice("Afternoon", afternoon),
            TimeOfDaySlice("Evening", evening),
            TimeOfDaySlice("Night", night)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            while (isActive) {
                val player = mediaPlayer
                if (player != null && _audioState.value.isPlaying) {
                    runCatching {
                        _audioState.value = _audioState.value.copy(
                            positionMs = player.currentPosition,
                            durationMs = player.duration.coerceAtLeast(1)
                        )
                    }
                }
                delay(300L)
            }
        }
    }

    fun observeHistoryForContact(normalizedNumber: String): Flow<List<CallLogEntry>> =
        repo.observeCallsForContact(normalizedNumber)

    fun setSearchQuery(q: String) { _searchQuery.value = q }
    fun setCallTypeFilter(type: Int) { _callTypeFilter.value = type }
    fun toggleOnlyRecordedFilter() { _onlyRecordedFilter.value = !_onlyRecordedFilter.value }
    fun setSimFilter(sim: String) { _simFilter.value = sim }
    fun loadMoreCalls() { _pageLimit.value += 500 }
    fun toggleStarredRecordingsOnly() { _starredRecordingsOnly.value = !_starredRecordingsOnly.value }
    fun setAnalyticsRangeDays(days: Int) { _analyticsRangeDays.value = days }
    fun showStatusMessage(message: String) { _statusBanner.value = message }
    fun dismissBanner() { _statusBanner.value = null }
    fun clearSettingsFeedback() { _settingsFeedback.value = null }
    fun clearPendingDriveConsent() { _pendingDriveConsentIntent.value = null }

    fun loadContacts() {
        viewModelScope.launch {
            _contacts.value = ContactsHelper.loadEnrichedContacts(getApplication(), db.callLogDao())
        }
    }

    fun syncSystemCallLogNow() {
        viewModelScope.launch {
            val currentNumber = settings.value.registeredPhoneNumber.ifBlank { repo.detectSimPhoneNumber() }
            if (settings.value.registeredPhoneNumber.isBlank() && currentNumber.isNotBlank()) {
                prefs.setRegisteredPhoneNumber(currentNumber)
            }
            val added = repo.syncSystemCallLogToUnlimitedVault(currentNumber)
            val (linked, unmatched) = repo.scanAndLinkAllRecordings()
            _unmatchedRecordings.value = unmatched
            loadContacts()
            if (added > 0 || linked > 0) {
                _statusBanner.value = "Synced $added new call(s) & linked $linked recording(s)."
            }
            refreshAvailableBackupSlots()
        }
    }

    fun togglePlayRecording(filePath: String) {
        val current = _audioState.value
        if (current.playingPath == filePath) {
            val player = mediaPlayer
            if (player != null) {
                if (current.isPlaying) {
                    player.pause()
                    _audioState.value = current.copy(isPlaying = false)
                } else {
                    player.start()
                    _audioState.value = current.copy(isPlaying = true)
                }
                return
            }
        }
        stopAudioPlayback()
        runCatching {
            val speed = _audioState.value.speed
            val player = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    playbackParams = PlaybackParams().setSpeed(speed)
                }
                start()
                setOnCompletionListener {
                    _audioState.value = AudioPlayerState(speed = _audioState.value.speed)
                }
            }
            mediaPlayer = player
            _audioState.value = AudioPlayerState(
                playingPath = filePath,
                isPlaying = true,
                positionMs = 0,
                durationMs = player.duration.coerceAtLeast(1),
                speed = speed
            )
        }.onFailure {
            _statusBanner.value = "Unable to play recording: ${it.localizedMessage}"
        }
    }

    fun seekAudioTo(ms: Int) {
        runCatching {
            mediaPlayer?.seekTo(ms)
            _audioState.value = _audioState.value.copy(positionMs = ms)
        }
    }

    fun cyclePlaybackSpeed() {
        val nextSpeed = when (_audioState.value.speed) {
            1.0f -> 1.5f
            1.5f -> 2.0f
            else -> 1.0f
        }
        _audioState.value = _audioState.value.copy(speed = nextSpeed)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && mediaPlayer != null) {
                mediaPlayer?.playbackParams = PlaybackParams().setSpeed(nextSpeed)
            }
        }
    }

    fun stopAudioPlayback() {
        runCatching {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
        mediaPlayer = null
        _audioState.value = AudioPlayerState(speed = _audioState.value.speed)
    }

    fun shareRecordingFile(filePath: String) {
        val app = getApplication<Application>()
        runCatching {
            val file = File(filePath)
            val uri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(Intent.createChooser(shareIntent, "Share Call Recording").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }.onFailure {
            _statusBanner.value = "Cannot share file: ${it.localizedMessage}"
        }
    }

    fun exportAndShareCsv() {
        viewModelScope.launch {
            val app = getApplication<Application>()
            runCatching {
                val csvFile = backupManager.exportCsvForShare()
                val uri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", csvFile)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                app.startActivity(Intent.createChooser(intent, "Export Call Log CSV").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }.onFailure { _settingsFeedback.value = "Export failed: ${it.localizedMessage}" }
        }
    }

    fun exportAndShareJson() {
        viewModelScope.launch {
            val app = getApplication<Application>()
            runCatching {
                val jsonFile = backupManager.exportJsonForShare()
                val uri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", jsonFile)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                app.startActivity(Intent.createChooser(intent, "Share JSON Backup").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }.onFailure { _settingsFeedback.value = "Export failed: ${it.localizedMessage}" }
        }
    }

    fun setContactVibration(contactId: String, patternName: String) {
        viewModelScope.launch {
            prefs.setContactVibrationPattern(contactId, patternName)
            ContactsHelper.previewVibrationPattern(getApplication(), patternName)
            _statusBanner.value = "Vibration set to $patternName"
        }
    }

    fun setContactRingtone(contactId: String, ringtoneUri: Uri?) {
        viewModelScope.launch {
            val ok = ContactsHelper.updateContactCustomRingtone(getApplication(), contactId, ringtoneUri)
            if (ok) {
                loadContacts()
                _statusBanner.value = "Custom ringtone updated!"
            } else {
                _statusBanner.value = "Could not update ringtone (check Contacts permission)."
            }
        }
    }

    fun deleteRecordingFile(filePath: String, callId: Long? = null) {
        viewModelScope.launch {
            runCatching {
                val f = File(filePath)
                if (f.exists()) f.delete()
                if (callId != null) db.callLogDao().clearRecordingFromCall(callId)
                val (_, unmatched) = repo.scanAndLinkAllRecordings()
                _unmatchedRecordings.value = unmatched
                _statusBanner.value = "Recording deleted."
            }
        }
    }

    fun deleteCallEntry(callId: Long) {
        viewModelScope.launch {
            repo.deleteCall(callId)
            _statusBanner.value = "Call entry deleted from vault."
        }
    }

    fun removeSpeedDial(digit: Int) {
        viewModelScope.launch {
            repo.removeSpeedDial(digit)
            _settingsFeedback.value = "Cleared speed dial slot $digit."
        }
    }

    fun updateContactStorageLocation(location: String) {
        viewModelScope.launch {
            prefs.setContactStorageLocation(location)
            _settingsFeedback.value = "Default contact storage set to $location"
        }
    }

    fun updateShowContactActivitySubtitles(show: Boolean) {
        viewModelScope.launch { prefs.setShowContactActivitySubtitles(show) }
    }

    fun toggleStarRecording(call: CallLogEntry) {
        viewModelScope.launch { repo.setRecordingStarred(call.id, !call.isStarredRecording) }
    }

    fun saveCallNote(callId: Long, note: String) {
        viewModelScope.launch {
            repo.updateCallNote(callId, note)
            _statusBanner.value = "Call note saved."
        }
    }

    fun blockNumber(rawNumber: String) {
        viewModelScope.launch {
            repo.blockNumber(rawNumber)
            _statusBanner.value = "Blocked $rawNumber"
        }
    }

    fun unblockNumber(normalizedNumber: String) {
        viewModelScope.launch {
            repo.unblockNumber(normalizedNumber)
            _settingsFeedback.value = "Unblocked $normalizedNumber"
        }
    }

    fun setSpeedDial(digit: Int, number: String, name: String) {
        viewModelScope.launch {
            repo.setSpeedDial(digit, number, name)
            _statusBanner.value = "Assigned speed dial $digit → $name"
        }
    }

    fun toggleFavoriteNumber(rawNumber: String) {
        viewModelScope.launch {
            val norm = repo.normalizePhoneNumber(rawNumber)
            prefs.toggleFavoriteNumber(norm)
        }
    }

    fun updateCollapseConsecutiveCalls(collapse: Boolean) {
        viewModelScope.launch { prefs.setCollapseConsecutiveCalls(collapse) }
    }

    fun updateDialpadHaptics(enabled: Boolean) {
        viewModelScope.launch { prefs.setDialpadHaptics(enabled) }
    }

    fun updateAutoRecord(enabled: Boolean) {
        viewModelScope.launch { prefs.setAutoRecordEnabled(enabled) }
    }

    fun updateHideRecordingNotification(hide: Boolean) {
        viewModelScope.launch { prefs.setHideRecordingNotification(hide) }
    }

    fun updateRecordingEngineMode(mode: RecordingEngineMode) {
        viewModelScope.launch { prefs.setRecordingEngineMode(mode) }
    }

    fun updateRecordingRule(rule: RecordingRule) {
        viewModelScope.launch { prefs.setRecordingRule(rule) }
    }

    fun updateRegisteredPhoneNumber(phone: String) {
        val cleaned = phone.trim()
        if (cleaned.isBlank()) {
            _settingsFeedback.value = "Please enter a valid phone number before saving."
            return
        }
        viewModelScope.launch {
            prefs.setRegisteredPhoneNumber(cleaned)
            _settingsFeedback.value = "✓ Saved! Backups isolated to Phone_$cleaned"
            refreshAvailableBackupSlots()
        }
    }

    fun updateGoogleAccountEmail(email: String, triggerBackupImmediately: Boolean = true) {
        viewModelScope.launch {
            prefs.setGoogleAccountEmail(email)
            _settingsFeedback.value = "✓ Selected Google account: $email"
            refreshAvailableBackupSlots()
            if (triggerBackupImmediately) {
                triggerImmediateBackup()
            }
        }
    }

    fun signOutGoogleAccount() {
        viewModelScope.launch {
            prefs.setGoogleAccountEmail("")
            _settingsFeedback.value = "Disconnected Google Drive account."
            refreshAvailableBackupSlots()
        }
    }

    fun updateAutoBackupEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setAutoDriveBackupEnabled(enabled)
            if (enabled) AutoBackupWorker.schedulePeriodicBackup(getApplication(), settings.value.backupFrequencyHours)
        }
    }

    fun triggerImmediateBackup() {
        viewModelScope.launch {
            _isDriveUploading.value = true
            _driveProgressMessage.value = "Preparing backup..."
            val outcome = backupManager.performBackupWithOutcome { progress ->
                _driveProgressMessage.value = progress
            }
            _isDriveUploading.value = false
            _driveProgressMessage.value = null
            when (outcome) {
                is DriveBackupOutcome.Success -> {
                    _settingsFeedback.value = "✓ ${outcome.message}"
                    _statusBanner.value = outcome.message
                }
                is DriveBackupOutcome.NeedsConsent -> {
                    _settingsFeedback.value = "Please allow Google Drive access in the popup..."
                    _pendingDriveConsentIntent.value = outcome.consentIntent
                }
                is DriveBackupOutcome.Failure -> {
                    _settingsFeedback.value = outcome.errorMessage
                }
            }
            refreshAvailableBackupSlots()
        }
    }

    fun refreshAvailableBackupSlots() {
        viewModelScope.launch { _availableBackups.value = backupManager.listAvailablePhoneNumberBackups() }
    }

    fun restoreFromSlot(slot: RemotePhoneBackupSlot) {
        viewModelScope.launch {
            _settingsFeedback.value = "Restoring calls from ${slot.folderName}..."
            val res = backupManager.restoreFromBackupSlot(slot)
            _settingsFeedback.value = res.fold(
                onSuccess = { count -> "✓ Restored $count calls from ${slot.phoneNumber}!" },
                onFailure = { err -> "Restore failed: ${err.localizedMessage}" }
            )
        }
    }

    fun restoreFromUri(uri: Uri) {
        viewModelScope.launch {
            _settingsFeedback.value = "Importing backup file..."
            val res = backupManager.restoreFromUri(uri)
            _settingsFeedback.value = res.fold(
                onSuccess = { count -> "✓ Restored $count calls from backup file!" },
                onFailure = { err -> "Import failed: ${err.localizedMessage}" }
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopAudioPlayback()
    }
}
