package com.callvault.s24.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.callvault.s24.data.local.UserSettings
import com.callvault.s24.data.model.BlockedNumberEntity
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.RecordingEngineMode
import com.callvault.s24.data.model.RecordingRule
import com.callvault.s24.data.model.SpeedDialEntity
import com.callvault.s24.data.repository.ContactsHelper
import com.callvault.s24.data.repository.DeviceContact
import com.callvault.s24.data.repository.WhatsAppHelper
import com.callvault.s24.ui.components.WhatsAppCallIcon
import com.callvault.s24.ui.components.WhatsAppMessageIcon
import com.callvault.s24.ui.theme.SamsungBlue
import com.callvault.s24.ui.theme.SamsungGreenCall
import com.callvault.s24.ui.theme.SamsungOrangeMessage
import com.callvault.s24.ui.theme.SamsungRedMissed
import com.callvault.s24.ui.theme.WhatsAppGreen

@Composable
private fun PowerMenuRow(
    icon: ImageVector? = null,
    customIcon: (@Composable () -> Unit)? = null,
    title: String,
    subtitle: String? = null,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (customIcon != null) {
                customIcon()
            } else if (icon != null) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold, color = tint, style = MaterialTheme.typography.bodyMedium)
                if (!subtitle.isNullOrBlank()) {
                    Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            }
        }
    }
}

/**
 * Long-Press Power Menu for any Call Log Entry in Recents
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallLongPressMenuSheet(
    call: CallLogEntry,
    storageLocation: String,
    onDismiss: () -> Unit,
    onCopyNumber: (String) -> Unit,
    onBlockNumber: (String) -> Unit,
    onDeleteCall: (Long) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val isUnsaved = call.contactName.isNullOrBlank()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(call.contactName ?: call.phoneNumber, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Quick Actions • ${call.phoneNumber}", style = MaterialTheme.typography.bodySmall, color = SamsungBlue)
            Spacer(modifier = Modifier.height(4.dp))

            if (isUnsaved) {
                PowerMenuRow(
                    icon = Icons.Default.PersonAdd,
                    title = "Save as New Contact",
                    subtitle = "Saves to $storageLocation",
                    tint = SamsungBlue
                ) {
                    ContactsHelper.openAddNewContactIntent(context, call.phoneNumber, storageLocation)
                    onDismiss()
                }
                PowerMenuRow(
                    icon = Icons.Default.PersonAdd,
                    title = "Add to Existing Contact",
                    tint = SamsungBlue
                ) {
                    ContactsHelper.openAddToExistingContactIntent(context, call.phoneNumber)
                    onDismiss()
                }
            }

            PowerMenuRow(icon = Icons.Default.Call, title = "Call ${call.phoneNumber}", tint = SamsungGreenCall) {
                placeCallIntent(context, call.phoneNumber); onDismiss()
            }
            PowerMenuRow(
                customIcon = { WhatsAppCallIcon(size = 22.dp, tint = WhatsAppGreen) },
                title = "WhatsApp Voice Call",
                tint = WhatsAppGreen
            ) {
                WhatsAppHelper.startWhatsAppVoiceCall(context, call.phoneNumber); onDismiss()
            }
            PowerMenuRow(
                customIcon = { WhatsAppMessageIcon(size = 22.dp, tint = WhatsAppGreen) },
                title = "WhatsApp Message",
                tint = WhatsAppGreen
            ) {
                WhatsAppHelper.openWhatsAppChat(context, call.phoneNumber); onDismiss()
            }
            PowerMenuRow(icon = Icons.Default.ContentCopy, title = "Copy Phone Number") {
                onCopyNumber(call.phoneNumber); onDismiss()
            }
            PowerMenuRow(icon = Icons.Default.Block, title = "Block This Number", tint = SamsungOrangeMessage) {
                onBlockNumber(call.phoneNumber); onDismiss()
            }
            PowerMenuRow(icon = Icons.Default.Delete, title = "Delete Call from Vault", tint = SamsungRedMissed) {
                onDeleteCall(call.id); onDismiss()
            }
        }
    }
}

/**
 * Long-Press Power Menu for any Contact in Contacts Tab (includes Speed Dial assignment)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactLongPressMenuSheet(
    contact: DeviceContact,
    onDismiss: () -> Unit,
    onCopyNumber: (String) -> Unit,
    onAssignSpeedDial: (Int, String, String) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showSpeedDialPicker by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(contact.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Contact Quick Actions • ${contact.phoneNumber}", style = MaterialTheme.typography.bodySmall, color = SamsungBlue)
            Spacer(modifier = Modifier.height(4.dp))

            PowerMenuRow(icon = Icons.Default.Call, title = "Phone Call", tint = SamsungGreenCall) {
                placeCallIntent(context, contact.phoneNumber); onDismiss()
            }
            PowerMenuRow(
                customIcon = { WhatsAppCallIcon(size = 22.dp, tint = WhatsAppGreen) },
                title = "WhatsApp Voice Call",
                tint = WhatsAppGreen
            ) {
                WhatsAppHelper.startWhatsAppVoiceCall(context, contact.phoneNumber); onDismiss()
            }
            PowerMenuRow(icon = Icons.Default.Videocam, title = "WhatsApp Video Call", tint = WhatsAppGreen) {
                WhatsAppHelper.startWhatsAppVideoCall(context, contact.phoneNumber); onDismiss()
            }
            PowerMenuRow(
                customIcon = { WhatsAppMessageIcon(size = 22.dp, tint = WhatsAppGreen) },
                title = "WhatsApp Message",
                tint = WhatsAppGreen
            ) {
                WhatsAppHelper.openWhatsAppChat(context, contact.phoneNumber); onDismiss()
            }
            PowerMenuRow(icon = Icons.Default.Speed, title = "Assign to Speed Dial (Keys 2–9)", tint = SamsungBlue) {
                showSpeedDialPicker = !showSpeedDialPicker
            }

            if (showSpeedDialPicker) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                    items((2..9).toList()) { digit ->
                        FilterChip(
                            selected = false,
                            onClick = {
                                onAssignSpeedDial(digit, contact.phoneNumber, contact.name)
                                onDismiss()
                            },
                            label = { Text("Key $digit") }
                        )
                    }
                }
            }

            PowerMenuRow(icon = Icons.Default.Edit, title = "Edit Contact") {
                ContactsHelper.openEditContactIntent(context, contact); onDismiss()
            }
            PowerMenuRow(icon = Icons.Default.Share, title = "Share Contact (.vcf)") {
                ContactsHelper.shareContactAsVcf(context, contact); onDismiss()
            }
            PowerMenuRow(icon = Icons.Default.ContentCopy, title = "Copy Number") {
                onCopyNumber(contact.phoneNumber); onDismiss()
            }
        }
    }
}

/**
 * Context-Aware Tab-Specific Settings Sheet:
 * Adapts cleanly to the active tab (0=Recents, 1=Contacts, 2=Analytics, 3=Recordings)
 * with 1-tap access to Global Cloud Backup & About CallVault.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TabSpecificSettingsSheet(
    activeTab: Int,
    settings: UserSettings,
    speedDials: List<SpeedDialEntity>,
    blockedNumbers: List<BlockedNumberEntity>,
    simFilter: String,
    analyticsRangeDays: Int,
    onDismiss: () -> Unit,
    onOpenCloudBackupAndAbout: () -> Unit,
    onToggleCollapse: (Boolean) -> Unit,
    onToggleHaptics: (Boolean) -> Unit,
    onRemoveSpeedDial: (Int) -> Unit,
    onUnblockNumber: (String) -> Unit,
    onSelectContactStorage: (String) -> Unit,
    onToggleContactSubtitles: (Boolean) -> Unit,
    onSimFilterChange: (String) -> Unit,
    onAnalyticsRangeChange: (Int) -> Unit,
    onExportCsv: () -> Unit,
    onToggleAutoRecord: (Boolean) -> Unit,
    onToggleHideNotification: (Boolean) -> Unit,
    onSelectEngineMode: (RecordingEngineMode) -> Unit,
    onSelectRecordingRule: (RecordingRule) -> Unit,
    onRequestDefaultDialerRole: () -> Unit
) {
    val context = LocalContext.current
    val googleAccounts = remember { ContactsHelper.getAvailableGoogleAccounts(context) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val title = when (activeTab) {
        0 -> "Recents & Dialer Settings"
        1 -> "Contacts Settings"
        2 -> "Analytics Settings"
        else -> "Call Recording Settings"
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            item {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }

            when (activeTab) {
                0 -> {
                    item {
                        ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Group Repeated Calls", fontWeight = FontWeight.SemiBold)
                                        Text("Collapse consecutive calls from the same contact", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Switch(checked = settings.collapseConsecutiveCalls, onCheckedChange = onToggleCollapse)
                                }
                                HorizontalDivider()
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Dialpad Haptic Vibration", fontWeight = FontWeight.SemiBold)
                                        Text("Tactile feedback when pressing keypad buttons", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Switch(checked = settings.dialpadHapticsEnabled, onCheckedChange = onToggleHaptics)
                                }
                                HorizontalDivider()
                                OutlinedButton(onClick = onRequestDefaultDialerRole, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                    Text("Set CallVault as Default Phone App")
                                }
                            }
                        }
                    }

                    item {
                        ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Speed Dial Slots (Long-Press Keys 2–9)", fontWeight = FontWeight.Bold)
                                if (speedDials.isEmpty()) {
                                    Text("Long-press any contact in the Contacts tab to assign a Speed Dial key.", style = MaterialTheme.typography.bodySmall)
                                } else {
                                    speedDials.forEach { slot ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Key ${slot.digit}: ${slot.contactName} (${slot.phoneNumber})", style = MaterialTheme.typography.bodySmall)
                                            IconButton(onClick = { onRemoveSpeedDial(slot.digit) }) {
                                                Icon(Icons.Default.Delete, contentDescription = "Clear", tint = SamsungRedMissed)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (blockedNumbers.isNotEmpty()) {
                        item {
                            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Blocked Numbers (${blockedNumbers.size})", fontWeight = FontWeight.Bold)
                                    blockedNumbers.forEach { b ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(b.displayNumber)
                                            IconButton(onClick = { onUnblockNumber(b.normalizedNumber) }) {
                                                Icon(Icons.Default.Delete, contentDescription = "Unblock", tint = SamsungRedMissed)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    item {
                        ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Default Contact Storage Location", fontWeight = FontWeight.Bold, color = SamsungBlue)
                                Text("Choose where new contacts saved from CallVault should be stored:", style = MaterialTheme.typography.bodySmall)

                                val storageOptions = buildList {
                                    if (googleAccounts.isEmpty()) {
                                        add("GOOGLE" to "Google Account (Default)")
                                    } else {
                                        googleAccounts.forEach { acc ->
                                            add("GOOGLE:$acc" to "Google: $acc")
                                        }
                                    }
                                    add("PHONE" to "Phone Storage (Local Device)")
                                }

                                storageOptions.forEach { (key, label) ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().clickable { onSelectContactStorage(key) }.padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(selected = settings.contactStorageLocation == key, onClick = { onSelectContactStorage(key) })
                                        Text(label, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }

                                HorizontalDivider()
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Show Smart Activity Subtitle", fontWeight = FontWeight.SemiBold)
                                        Text("Display last call / SMS timestamp under each contact", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Switch(checked = settings.showContactActivitySubtitles, onCheckedChange = onToggleContactSubtitles)
                                }
                            }
                        }
                    }
                }

                2 -> {
                    item {
                        ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Analytics Filter & Export", fontWeight = FontWeight.Bold, color = SamsungBlue)
                                Text("SIM Filter", style = MaterialTheme.typography.labelLarge)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("ALL", "SIM 1", "SIM 2").forEach { sim ->
                                        FilterChip(selected = simFilter == sim, onClick = { onSimFilterChange(sim) }, label = { Text(sim) })
                                    }
                                }
                                Text("Default Date Window", style = MaterialTheme.typography.labelLarge)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(0 to "All Time", 365 to "1 Year", 30 to "30 Days", 7 to "7 Days").forEach { (d, lbl) ->
                                        item {
                                            FilterChip(selected = analyticsRangeDays == d, onClick = { onAnalyticsRangeChange(d) }, label = { Text(lbl) })
                                        }
                                    }
                                }
                                HorizontalDivider()
                                OutlinedButton(onClick = onExportCsv, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                    Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Export Full Call Analytics (.csv)")
                                }
                            }
                        }
                    }
                }

                else -> {
                    item {
                        ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Auto-Record Calls", fontWeight = FontWeight.Bold)
                                    Switch(checked = settings.autoRecordEnabled, onCheckedChange = onToggleAutoRecord)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Hide 'Recording Saved' Alert", style = MaterialTheme.typography.bodyMedium)
                                    Switch(checked = settings.hideRecordingSavedNotification, onCheckedChange = onToggleHideNotification)
                                }
                                HorizontalDivider()
                                Text("Recording Rule", style = MaterialTheme.typography.labelLarge, color = SamsungBlue)
                                RecordingRule.entries.forEach { rule ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().clickable { onSelectRecordingRule(rule) },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(selected = settings.recordingRule == rule, onClick = { onSelectRecordingRule(rule) })
                                        Text(rule.label, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                                HorizontalDivider()
                                Text("S24 Ultra Recording Engine (Option C)", style = MaterialTheme.typography.labelLarge, color = SamsungBlue)
                                RecordingEngineMode.entries.forEach { mode ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().clickable { onSelectEngineMode(mode) }.padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        RadioButton(selected = settings.recordingEngineMode == mode, onClick = { onSelectEngineMode(mode) })
                                        Column(modifier = Modifier.padding(start = 4.dp)) {
                                            Text(mode.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                            Text(mode.subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Always 1-tap access to Global Cloud Backup & About CallVault
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth().clickable {
                        onDismiss()
                        onOpenCloudBackupAndAbout()
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CloudDone, contentDescription = null, tint = SamsungGreenCall, modifier = Modifier.size(26.dp))
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text("Google Drive Backup, Restore & About", fontWeight = FontWeight.Bold)
                            Text("Per-phone-number backup, SHA-1 & Developer Info", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                        }
                    }
                }
            }
        }
    }
}
