# CallVault Ultra S24 (Unlimited Call Log, Deep Analytics, Hybrid Call Recorder & Per-Number Google Drive Backup)

A custom native Kotlin + Jetpack Compose Android application engineered specifically for **Samsung Galaxy S24 Ultra** (and other Galaxy devices). Designed with a modern **Samsung One UI 7 + Material 3** interface and built automatically in the cloud via **GitHub Actions**.

---

## Key Features Built Into This Project

1. **Unlimited Call Log Vault (Zero Time or Call Count Limit)**
   - Automatically syncs and preserves every call from Android's `CallLog` provider into an indexed local **Room SQLite database** (`unlimited_call_logs`).
   - Never loses calls when Android trims past 500/1,000 calls or 30 days—easily holds **5+ years (100,000+ calls)** with instant search and filtering.

2. **Detailed Call Intelligence & Analytics**
   - **Call Summary Overview**: Total calls, Incoming calls, Outgoing calls, Missed calls, Rejected calls, Disconnected/Dropped calls, and Recorded calls with an interactive Compose Donut Chart.
   - **Per-Contact Breakdown**: Evaluates total talk duration (`h m s`), average call length, total calls made/received, how many times a call was **missed** from that contact, and how many times a call was **disconnected/dropped**.
   - **Timeframe Filters**: Filter analytics across **All Time (Unlimited 4–5+ Years)**, Last 1 Year, Last 90 Days, Last 30 Days, or Last 7 Days.

3. **Option C Hybrid Call Recording Engine (Samsung Native + Built-In Silent Recorder)**
   - **Turn On Once**: Toggle automatic background call recording in the **Recordings** tab.
   - **Silent Notification Option**: Toggle off the *"Call Recording Saved"* notification so recordings accumulate silently in the **Recordings** tab.
   - **Zero Pre-Call Announcement**: Never plays any TTS or beep before or during recording.
   - **Switchable 3-Mode Engine (Option C)**:
     - **Hybrid Smart Mode (Default)**: Automatically links crystal-clear two-way Samsung One UI native recordings (`/storage/emulated/0/Recordings/Call/*.m4a`) when using Samsung Dialer, and switches to the built-in `VaultInCallService` + `CallRecordingAccessibilityService` recorder when set as Default Dialer.
     - **Option A (Samsung Native Recording Sync Only)**: Keeps Samsung's system dialer active for 100% hardware-level two-way recording and links every recording inside CallVault Ultra.
     - **Option B (Built-in Default Dialer + Silent Accessibility Recorder)**: Uses `VaultInCallService` to capture exact `DisconnectCause` codes (`LOCAL_HANGUP`, `REMOTE_HANGUP`, `NETWORK_DROP`, `BUSY`, `REJECTED`) and records via `AudioSource.VOICE_RECOGNITION`.

4. **Samsung One UI Gestures & Direct Messaging**
   - **Swipe Right** on any call entry to **Call** immediately.
   - **Swipe Left** on any call entry to **Send a Message** (opens Samsung Messages / Google Messages directly to that number).
   - Tap any call card to expand quick **Call**, **Message**, and inline **Play Recording** controls.

5. **Per-Phone-Number Isolated Google Drive Auto-Backup & Restore**
   - **Multi-Phone Isolation**: Even if you install this app on **5 different phones using the exact same Google account**, backups **never overwrite each other**.
   - Each phone backs up into its own isolated Google Drive folder keyed by phone number:
     - `/CallVault_Unlimited_Backups/Phone_+919876543210/`
     - `/CallVault_Unlimited_Backups/Phone_+919123456789/`
   - **Scheduled Background Auto-Backup**: Uses `WorkManager` (`AutoBackupWorker`) to back up automatically in the background, plus a **Backup Now** and multi-phone **Restore** picker.

---

## How to Compile & Sign Your APK in the Cloud with GitHub Actions (Zero Local Setup Required)

1. **Create a new GitHub repository** (can be **Private** or **Public**).
2. **Upload / Push all files** from this project folder into the root of your repository (make sure the `.github/workflows/android-build.yml` file is included).
3. Go to your repository on GitHub and click the **Actions** tab at the top.
4. Click on **Build & Sign SamsungCallVault APK** workflow (it runs automatically on every push to `main`/`master`, or you can click **Run workflow** manually).
5. Wait ~2–3 minutes for the cloud build to finish, then scroll down to the **Artifacts** section at the bottom of the workflow summary:
   - Download **`SamsungCallVault-Signed-Release-APK`** (ready to sideload directly onto your Galaxy S24 Ultra).

---

## Sideloading & Setup on Samsung Galaxy S24 Ultra

1. Unzip the downloaded artifact and tap `app-release.apk` on your Galaxy S24 Ultra to install.
2. Open **CallVault Ultra** and grant the requested permissions (Call Log, Contacts, Phone, Microphone, and Storage/Audio so it can read `/Recordings/Call`).
3. **(Android 13/14/15/16 Sideloaded APK Tip)**: If you want to test **Option B/C Accessibility Service**, go to **Settings → Apps → CallVault Ultra → 3-dot menu (top right) → Allow restricted settings**, then enable **CallVault Ultra** inside **Settings → Accessibility → Installed apps**.
4. Go to the **Drive Backup** tab, verify or enter each phone's SIM number (e.g., `+91...`), and tap **Link Google Drive**.
