package com.callvault.s24.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * AccessibilityService required by Android 10-15+ so that sideloaded personal APKs
 * can capture voice audio in the background using AudioSource.VOICE_RECOGNITION.
 */
class CallRecordingAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Passive audio-stream privilege holder for SilentCallRecorderManager
    }

    override fun onInterrupt() {
        // No-op
    }
}
