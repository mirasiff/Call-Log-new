package com.callvault.s24.ui

import android.app.Application
import android.media.MediaPlayer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.callvault.s24.backup.DriveBackupManager
import com.callvault.s24.backup.RemotePhoneBackupSlot
import com.callvault.s24.data.local.AppDatabase
import com.callvault.s24.data.local.AppPreferences
import com.callvault.s24.data.local.UserSettings
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.CallSummaryStats
import com.callvault.s24.data.model.ContactAnalyticsItem
import com.callvault.s24.data.model.RecordingEngineMode
import com.callvault.s24.data.repository.CallLogRepository
import com.callvault.s24.worker.AutoBackupWorker
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val repo = CallLogRepository(application, db.callLogDao())
    private val prefs = AppPreferences(application)
    private val backupManager = DriveBackupManager(application)

    private var mediaPlayer: MediaPlayer? = null

    val settings: StateFlow<UserSettings> = prefs.settingsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        UserSettings()
    )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _callTypeFilter = MutableStateFlow(0) // 0=All, 1=Incoming, 2=Outgoing, 3=Missed, 5=Rejected
    val callTypeFilter: StateFlow<Int> = _callTypeFilter.asStateFlow()

    private val _onlyRecordedFilter = MutableStateFlow(false)
    val onlyRecordedFilter: StateFlow<Boolean> = _onlyRecordedFilter.asStateFlow()

    private val _analyticsRangeDays = MutableStateFlow(0) // 0=All Time (Unlimited 5+ yrs), 30=30d, 365=1yr
    val analyticsRangeDays: StateFlow<Int> = _analyticsRangeDays.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _currentlyPlayingPath = MutableStateFlow<String?>(null)
    val currentlyPlayingPath: StateFlow<String?> = _currentlyPlayingPath.asStateFlow()

    private val _availableBackups = MutableStateFlow<List<RemotePhoneBackupSlot>>(emptyList())
    val availableBackups: StateFlow<List<RemotePhoneBackupSlot>> = _availableBackups.asStateFlow()

    val filteredCallLogs: StateFlow<List<CallLogEntry>> = combine(
        _callTypeFilter,
        _onlyRecordedFilter,
        _searchQuery
    ) { type, recOnly, query ->
        Triple(type, recOnly, query)
    }.flatMapLatest { (type, recOnly, query) ->
        repo.observeFilteredCalls(type, recOnly, query)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recordedCalls: StateFlow<List<CallLogEntry>> = repo.observeRecordedCalls()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val summaryStats: StateFlow<CallSummaryStats> = _analyticsRangeDays.flatMapLatest { days ->
        val since = if (days <= 0) 0L else System.currentTimeMillis() - (days * 86_400_000L)
        repo.observeSummaryStats(since)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CallSummaryStats())

    val contactAnalytics: StateFlow<List<ContactAnalyticsItem>> = _analyticsRangeDays.flatMapLatest { days ->
        val since = if (days <= 0) 0L else System.currentTimeMillis() - (days * 86_400_000L)
        repo.observeContactAnalytics(since)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun setCallTypeFilter(type: Int) {
        _callTypeFilter.value = type
    }

    fun toggleOnlyRecordedFilter() {
        _onlyRecordedFilter.value = !_onlyRecordedFilter.value
    }

    fun setAnalyticsRangeDays(days: Int) {
        _analyticsRangeDays.value = days
    }

    fun dismissBanner() {
        _statusBanner.value = null
    }

    fun syncSystemCallLogNow() {
        viewModelScope.launch {
            val currentNumber = settings.value.registeredPhoneNumber.ifBlank {
                repo.detectSimPhoneNumber()
            }
            if (settings.value.registeredPhoneNumber.isBlank() && currentNumber.isNotBlank()) {
                prefs.setRegisteredPhoneNumber(currentNumber)
            }
            val added = repo.syncSystemCallLogToUnlimitedVault(currentNumber)
            val linked = repo.scanAndLinkSamsungNativeRecordings()
            if (added > 0 || linked > 0) {
                _statusBanner.value = "Synced $added new call(s) & linked $linked recording(s) into Unlimited Vault."
            } else {
                _statusBanner.value = "Unlimited Call Vault is up to date."
            }
            refreshAvailableBackupSlots()
        }
    }

    fun togglePlayRecording(filePath: String) {
        if (_currentlyPlayingPath.value == filePath) {
            stopAudioPlayback()
            return
        }
        stopAudioPlayback()
        runCatching {
            val player = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                start()
                setOnCompletionListener {
                    _currentlyPlayingPath.value = null
                }
            }
            mediaPlayer = player
            _currentlyPlayingPath.value = filePath
        }.onFailure {
            _statusBanner.value = "Unable to play recording file: ${it.localizedMessage}"
        }
    }

    fun stopAudioPlayback() {
        runCatching {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
        mediaPlayer = null
        _currentlyPlayingPath.value = null
    }

    fun updateAutoRecord(enabled: Boolean) {
        viewModelScope.launch { prefs.setAutoRecordEnabled(enabled) }
    }

    fun updateHideRecordingNotification(hide: Boolean) {
        viewModelScope.launch { prefs.setHideRecordingNotification(hide) }
    }

    fun updateRecordingEngineMode(mode: RecordingEngineMode) {
        viewModelScope.launch { prefs.setRecordingEngineMode(mode) }
    }

    fun updateRegisteredPhoneNumber(phone: String) {
        viewModelScope.launch {
            prefs.setRegisteredPhoneNumber(phone)
            _statusBanner.value = "Backup namespace updated to Phone_${phone.trim()}"
            refreshAvailableBackupSlots()
        }
    }

    fun updateGoogleAccountEmail(email: String) {
        viewModelScope.launch {
            prefs.setGoogleAccountEmail(email)
            _statusBanner.value = "Connected Google Drive account: $email"
            refreshAvailableBackupSlots()
        }
    }

    fun updateAutoBackupEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setAutoDriveBackupEnabled(enabled)
            if (enabled) {
                AutoBackupWorker.schedulePeriodicBackup(getApplication(), settings.value.backupFrequencyHours)
            }
        }
    }

    fun triggerImmediateBackup() {
        viewModelScope.launch {
            _statusBanner.value = "Running per-phone-number backup..."
            val res = backupManager.performBackupNow()
            _statusBanner.value = res.getOrElse { "Backup error: ${it.localizedMessage}" }
            refreshAvailableBackupSlots()
        }
    }

    fun refreshAvailableBackupSlots() {
        viewModelScope.launch {
            _availableBackups.value = backupManager.listAvailablePhoneNumberBackups()
        }
    }

    fun restoreFromSlot(slot: RemotePhoneBackupSlot) {
        viewModelScope.launch {
            _statusBanner.value = "Restoring calls from ${slot.folderName}..."
            val res = backupManager.restoreFromBackupSlot(slot)
            _statusBanner.value = res.fold(
                onSuccess = { count -> "Restored $count new calls from ${slot.phoneNumber} into Unlimited Vault!" },
                onFailure = { err -> "Restore failed: ${err.localizedMessage}" }
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopAudioPlayback()
    }
}
