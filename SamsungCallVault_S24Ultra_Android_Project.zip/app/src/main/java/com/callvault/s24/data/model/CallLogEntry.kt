package com.callvault.s24.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Unlimited Call Log Entity stored permanently in Room SQLite.
 * Survives Android's 500/1000 call or 30-day OS CallLog purge indefinitely (5+ years).
 */
@Serializable
@Entity(
    tableName = "unlimited_call_logs",
    indices = [
        Index(value = ["normalizedNumber"]),
        Index(value = ["timestamp"]),
        Index(value = ["callType"]),
        Index(value = ["systemCallId", "timestamp"], unique = true)
    ]
)
data class CallLogEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val systemCallId: Long,
    val phoneNumber: String,
    val normalizedNumber: String,
    val contactName: String?,
    val photoUri: String? = null,
    val callType: Int, // 1=Incoming, 2=Outgoing, 3=Missed, 5=Rejected, 6=Blocked
    val timestamp: Long, // Epoch millis
    val durationSeconds: Long,
    val simSlotId: String? = null,
    val devicePhoneNumber: String? = null, // The SIM phone number on this device
    val disconnectCauseCode: Int = 0, // From Telecom DisconnectCause (LOCAL, REMOTE, ERROR/DROP, MISSED, REJECTED)
    val disconnectCauseLabel: String = "NORMAL", // "LOCAL_HANGUP", "REMOTE_HANGUP", "NETWORK_DROP", "MISSED", "REJECTED", "BUSY"
    val wasDisconnectedAbnormally: Boolean = false,
    val recordingFilePath: String? = null,
    val recordingSource: String? = null, // "SAMSUNG_NATIVE" or "BUILTIN_RECORDER"
    val notes: String? = null
)

@Serializable
data class CallSummaryStats(
    val totalCalls: Int = 0,
    val incomingCalls: Int = 0,
    val outgoingCalls: Int = 0,
    val missedCalls: Int = 0,
    val rejectedCalls: Int = 0,
    val totalDurationSeconds: Long = 0L,
    val incomingDurationSeconds: Long = 0L,
    val outgoingDurationSeconds: Long = 0L,
    val disconnectedDropCalls: Int = 0,
    val recordedCallsCount: Int = 0
)

@Serializable
data class ContactAnalyticsItem(
    val normalizedNumber: String,
    val displayNumber: String,
    val contactName: String?,
    val totalCalls: Int,
    val incomingCount: Int,
    val outgoingCount: Int,
    val missedCount: Int,
    val rejectedCount: Int,
    val disconnectedCount: Int,
    val totalDurationSeconds: Long,
    val averageDurationSeconds: Long,
    val lastCallTimestamp: Long
)

enum class RecordingEngineMode(val title: String, val subtitle: String) {
    HYBRID_AUTO(
        "Option C: Hybrid Smart Mode (Recommended for S24 Ultra)",
        "Auto-links crystal-clear Samsung native recordings (.m4a) when using Samsung Dialer, and switches to Built-in Silent Accessibility Recorder when set as Default Dialer."
    ),
    SAMSUNG_COMPANION(
        "Option A: Samsung Native Recording Sync Only",
        "Scans /Recordings/Call/ for Samsung One UI native call recordings with zero pre-call announcement and links them to your unlimited call log."
    ),
    BUILTIN_DEFAULT_DIALER(
        "Option B: Built-in Default Dialer + Silent Recorder",
        "Uses CallVault's InCallService + AccessibilityService for background recording and captures exact network/remote DisconnectCause codes."
    )
}
