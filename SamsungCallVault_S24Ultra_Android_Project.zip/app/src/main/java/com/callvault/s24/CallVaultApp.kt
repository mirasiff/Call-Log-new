package com.callvault.s24

import android.app.Application
import com.callvault.s24.worker.AutoBackupWorker

class CallVaultApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Schedule automatic background CallLog preservation & Per-Number Google Drive Backup
        AutoBackupWorker.schedulePeriodicBackup(this, intervalHours = 12L)
    }
}
