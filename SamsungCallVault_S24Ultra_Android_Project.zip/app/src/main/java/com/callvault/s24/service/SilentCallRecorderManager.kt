package com.callvault.s24.service

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import com.callvault.s24.data.local.AppDatabase
import com.callvault.s24.data.local.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Option C Built-in Silent Background Call Recorder.
 * - Zero pre-call announcement (never plays any TTS or beep).
 * - Respects user's toggle to suppress "Call Recording Saved" notification.
 * - Automatically falls back from VOICE_RECOGNITION (used with AccessibilityService on S24 Ultra)
 *   to MIC if restricted by OS firmware.
 */
object SilentCallRecorderManager {

    private var mediaRecorder: MediaRecorder? = null
    private var currentOutputFile: File? = null
    private var isRecording = false

    fun startSilentRecording(context: Context, phoneNumber: String): File? {
        if (isRecording) return currentOutputFile

        val recordingsDir = File(context.filesDir, "recordings").apply { mkdirs() }
        val sanitizedNumber = phoneNumber.replace(Regex("[^0-9+]"), "").ifBlank { "Unknown" }
        val timestampStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(recordingsDir, "Call_${sanitizedNumber}_$timestampStr.m4a")

        val audioSourcesToTry = listOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.MIC
        )

        for (source in audioSourcesToTry) {
            try {
                val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    MediaRecorder(context)
                } else {
                    @Suppress("DEPRECATION")
                    MediaRecorder()
                }

                recorder.setAudioSource(source)
                recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                recorder.setAudioEncodingBitRate(128_000)
                recorder.setAudioSamplingRate(44_100)
                recorder.setOutputFile(outputFile.absolutePath)
                recorder.prepare()
                recorder.start()

                mediaRecorder = recorder
                currentOutputFile = outputFile
                isRecording = true
                return outputFile
            } catch (e: Exception) {
                runCatching { mediaRecorder?.release() }
                mediaRecorder = null
            }
        }
        return null
    }

    fun stopSilentRecording(context: Context, callStartMillis: Long) {
        if (!isRecording) return
        val savedFile = currentOutputFile
        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
        } catch (_: Exception) {
        } finally {
            mediaRecorder = null
            isRecording = false
            currentOutputFile = null
        }

        if (savedFile != null && savedFile.exists() && savedFile.length() > 0) {
            CoroutineScope(Dispatchers.IO).launch {
                val dao = AppDatabase.getInstance(context).callLogDao()
                val closest = dao.findClosestCallAroundTimestamp(callStartMillis)
                if (closest != null) {
                    dao.attachRecordingToCall(
                        callId = closest.id,
                        filePath = savedFile.absolutePath,
                        source = "BUILTIN_RECORDER"
                    )
                }
                // Check if user turned OFF "Recording Saved" notification (Samsung-style silent save)
                val prefs = AppPreferences(context).settingsFlow.first()
                if (!prefs.hideRecordingSavedNotification) {
                    // Notification is optional and off by default per user preference
                }
            }
        }
    }
}
