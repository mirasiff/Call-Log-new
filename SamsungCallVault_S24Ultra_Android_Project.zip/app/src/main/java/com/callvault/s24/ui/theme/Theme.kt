package com.callvault.s24.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

val SamsungBlue = Color(0xFF0381FE)
val SamsungGreenCall = Color(0xFF00C853)
val SamsungOrangeMessage = Color(0xFFFF6D00)
val SamsungRedMissed = Color(0xFFFF1744)
val SamsungPurpleRecord = Color(0xFF7C4DFF)

private val DarkColorPalette = darkColorScheme(
    primary = SamsungBlue,
    secondary = SamsungGreenCall,
    tertiary = SamsungOrangeMessage,
    background = Color(0xFF0B0E14),
    surface = Color(0xFF151A24),
    surfaceVariant = Color(0xFF1E2532),
    onBackground = Color(0xFFF5F7FA),
    onSurface = Color(0xFFF5F7FA)
)

private val LightColorPalette = lightColorScheme(
    primary = SamsungBlue,
    secondary = SamsungGreenCall,
    tertiary = SamsungOrangeMessage,
    background = Color(0xFFF4F6FA),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE9EEF6),
    onBackground = Color(0xFF10141C),
    onSurface = Color(0xFF10141C)
)

@Composable
fun CallVaultTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorPalette
        else -> LightColorPalette
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
