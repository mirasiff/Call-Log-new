package com.callvault.s24.data.repository

import android.annotation.SuppressLint
import android.content.Context
import android.os.Environment
import android.provider.CallLog
import android.telephony.PhoneNumberUtils
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import com.callvault.s24.data.local.CallLogDao
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.CallSummaryStats
import com.callvault.s24.data.model.ContactAnalyticsItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

class CallLogRepository(
    private val context: Context,
    private val callLogDao: CallLogDao
) {

    fun observeAllCalls(): Flow<List<CallLogEntry>> = callLogDao.observeAllCalls()

    fun observeFilteredCalls(
        callTypeFilter: Int,
        onlyRecorded: Boolean,
        searchQuery: String
    ): Flow<List<CallLogEntry>> = callLogDao.observeFilteredCalls(
        callTypeFilter = callTypeFilter,
        onlyRecorded = if (onlyRecorded) 1 else 0,
        searchQuery = searchQuery.trim()
    )

    fun observeRecordedCalls(): Flow<List<CallLogEntry>> = callLogDao.observeRecordedCalls()

    fun observeContactAnalytics(sinceEpochMillis: Long = 0L): Flow<List<ContactAnalyticsItem>> =
        callLogDao.observeContactAnalytics(sinceEpochMillis)

    fun observeCallsForContact(normalizedNumber: String): Flow<List<CallLogEntry>> =
        callLogDao.observeCallsForContact(normalizedNumber)

    fun observeSummaryStats(sinceEpochMillis: Long = 0L): Flow<CallSummaryStats> =
        callLogDao.observeAllCalls().map { allCalls ->
            val calls = if (sinceEpochMillis > 0) {
                allCalls.filter { it.timestamp >= sinceEpochMillis }
            } else {
                allCalls
            }
            CallSummaryStats(
                totalCalls = calls.size,
                incomingCalls = calls.count { it.callType == CallLog.Calls.INCOMING_TYPE },
                outgoingCalls = calls.count { it.callType == CallLog.Calls.OUTGOING_TYPE },
                missedCalls = calls.count { it.callType == CallLog.Calls.MISSED_TYPE },
                rejectedCalls = calls.count { it.callType == CallLog.Calls.REJECTED_TYPE },
                totalDurationSeconds = calls.sumOf { it.durationSeconds },
                incomingDurationSeconds = calls.filter { it.callType == CallLog.Calls.INCOMING_TYPE }
                    .sumOf { it.durationSeconds },
                outgoingDurationSeconds = calls.filter { it.callType == CallLog.Calls.OUTGOING_TYPE }
                    .sumOf { it.durationSeconds },
                disconnectedDropCalls = calls.count {
                    it.wasDisconnectedAbnormally ||
                        it.disconnectCauseLabel in listOf("NETWORK_DROP", "REMOTE_HANGUP", "REJECTED", "BUSY")
                },
                recordedCallsCount = calls.count { !it.recordingFilePath.isNullOrBlank() }
            )
        }

    /**
     * Reads all entries from Android's system CallLog provider and persists them permanently
     * into Room SQLite so they are never lost when Android trims past 500/1000 calls or 30 days.
     */
    @SuppressLint("MissingPermission")
    suspend fun syncSystemCallLogToUnlimitedVault(configuredPhoneNumber: String): Int =
        withContext(Dispatchers.IO) {
            val resolver = context.contentResolver
            val projection = arrayOf(
                CallLog.Calls._ID,
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.CACHED_PHOTO_URI,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE,
                CallLog.Calls.DURATION,
                CallLog.Calls.PHONE_ACCOUNT_ID
            )

            val entriesToInsert = mutableListOf<CallLogEntry>()
            val detectedSimNumber = configuredPhoneNumber.ifBlank { detectSimPhoneNumber() }

            resolver.query(
                CallLog.Calls.CONTENT_URI,
                projection,
                null,
                null,
                "${CallLog.Calls.DATE} DESC"
            )?.use { cursor ->
                val idIdx = cursor.getColumnIndex(CallLog.Calls._ID)
                val numIdx = cursor.getColumnIndex(CallLog.Calls.NUMBER)
                val nameIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)
                val photoIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_PHOTO_URI)
                val typeIdx = cursor.getColumnIndex(CallLog.Calls.TYPE)
                val dateIdx = cursor.getColumnIndex(CallLog.Calls.DATE)
                val durIdx = cursor.getColumnIndex(CallLog.Calls.DURATION)
                val accIdx = cursor.getColumnIndex(CallLog.Calls.PHONE_ACCOUNT_ID)

                while (cursor.moveToNext()) {
                    val sysId = if (idIdx >= 0) cursor.getLong(idIdx) else 0L
                    val rawNumber = (if (numIdx >= 0) cursor.getString(numIdx) else null) ?: "Unknown"
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx) else null
                    val photo = if (photoIdx >= 0) cursor.getString(photoIdx) else null
                    val type = if (typeIdx >= 0) cursor.getInt(typeIdx) else CallLog.Calls.INCOMING_TYPE
                    val date = if (dateIdx >= 0) cursor.getLong(dateIdx) else System.currentTimeMillis()
                    val duration = if (durIdx >= 0) cursor.getLong(durIdx) else 0L
                    val simId = if (accIdx >= 0) cursor.getString(accIdx) else null

                    val normalized = normalizePhoneNumber(rawNumber)
                    val disconnectLabel = when (type) {
                        CallLog.Calls.MISSED_TYPE -> "MISSED"
                        CallLog.Calls.REJECTED_TYPE -> "REJECTED"
                        CallLog.Calls.BLOCKED_TYPE -> "BLOCKED"
                        else -> if (duration in 1..4) "SHORT_DROP" else "NORMAL"
                    }
                    val abnormal = type == CallLog.Calls.REJECTED_TYPE || (type in 1..2 && duration in 1..4)

                    entriesToInsert.add(
                        CallLogEntry(
                            systemCallId = sysId,
                            phoneNumber = rawNumber,
                            normalizedNumber = normalized,
                            contactName = name?.takeIf { it.isNotBlank() },
                            photoUri = photo,
                            callType = type,
                            timestamp = date,
                            durationSeconds = duration,
                            simSlotId = simId,
                            devicePhoneNumber = detectedSimNumber,
                            disconnectCauseCode = 0,
                            disconnectCauseLabel = disconnectLabel,
                            wasDisconnectedAbnormally = abnormal
                        )
                    )
                }
            }

            val insertedIds = if (entriesToInsert.isNotEmpty()) {
                callLogDao.insertCallsIgnoreDuplicate(entriesToInsert)
            } else {
                emptyList()
            }

            // Also scan Samsung One UI's native /Recordings/Call directory and link audio files
            scanAndLinkSamsungNativeRecordings()

            insertedIds.count { it != -1L }
        }

    /**
     * Option A & C (Samsung Galaxy S24 Ultra Native Recording Matcher):
     * Scans "/storage/emulated/0/Recordings/Call" and "/storage/emulated/0/Call" for .m4a / .amr / .wav files
     * recorded silently by Samsung's system dialer and attaches them to matching CallLogEntry rows.
     */
    suspend fun scanAndLinkSamsungNativeRecordings(): Int = withContext(Dispatchers.IO) {
        val root = Environment.getExternalStorageDirectory()
        val candidateFolders = listOf(
            File(root, "Recordings/Call"),
            File(root, "Call"),
            File(context.filesDir, "recordings")
        )

        var linkedCount = 0
        for (folder in candidateFolders) {
            if (!folder.exists() || !folder.isDirectory) continue
            val audioFiles = folder.listFiles { file ->
                file.isFile && file.extension.lowercase() in listOf("m4a", "aac", "mp3", "wav", "amr", "ogg")
            } ?: continue

            for (audioFile in audioFiles) {
                val fileModifiedTime = audioFile.lastModified()
                val closestCall = callLogDao.findClosestCallAroundTimestamp(fileModifiedTime)
                if (closestCall != null && closestCall.recordingFilePath == null) {
                    val expectedEndMillis = closestCall.timestamp + (closestCall.durationSeconds * 1000L)
                    if (abs(fileModifiedTime - expectedEndMillis) <= 180_000L ||
                        abs(fileModifiedTime - closestCall.timestamp) <= 180_000L
                    ) {
                        val sourceTag = if (audioFile.absolutePath.contains(context.filesDir.absolutePath)) {
                            "BUILTIN_RECORDER"
                        } else {
                            "SAMSUNG_NATIVE"
                        }
                        callLogDao.attachRecordingToCall(
                            callId = closestCall.id,
                            filePath = audioFile.absolutePath,
                            source = sourceTag
                        )
                        linkedCount++
                    }
                }
            }
        }
        linkedCount
    }

    @SuppressLint("MissingPermission")
    fun detectSimPhoneNumber(): String {
        return try {
            val subManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
            val activeList = subManager?.activeSubscriptionInfoList
            val firstSimNumber = activeList?.firstOrNull { !it.number.isNullOrBlank() }?.number
            if (!firstSimNumber.isNullOrBlank()) {
                normalizePhoneNumber(firstSimNumber)
            } else {
                val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
                val line1 = tm?.line1Number
                if (!line1.isNullOrBlank()) normalizePhoneNumber(line1) else ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    fun normalizePhoneNumber(raw: String): String {
        val cleaned = PhoneNumberUtils.normalizeNumber(raw) ?: raw
        return if (cleaned.length > 10 && !cleaned.startsWith("+")) {
            "+$cleaned"
        } else {
            cleaned.ifBlank { "Unknown" }
        }
    }

    suspend fun getAllCallsForBackup(): List<CallLogEntry> = callLogDao.getAllCallsSnapshot()

    suspend fun restoreCallsFromBackup(backupCalls: List<CallLogEntry>): Int = withContext(Dispatchers.IO) {
        val results = callLogDao.insertCallsIgnoreDuplicate(backupCalls.map { it.copy(id = 0) })
        results.count { it != -1L }
    }
}
