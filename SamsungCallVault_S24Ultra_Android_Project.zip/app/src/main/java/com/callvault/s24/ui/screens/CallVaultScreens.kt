package com.callvault.s24.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CallLog
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.callvault.s24.backup.RemotePhoneBackupSlot
import com.callvault.s24.data.local.UserSettings
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.CallSummaryStats
import com.callvault.s24.data.model.ContactAnalyticsItem
import com.callvault.s24.data.model.RecordingEngineMode
import com.callvault.s24.ui.theme.SamsungBlue
import com.callvault.s24.ui.theme.SamsungGreenCall
import com.callvault.s24.ui.theme.SamsungOrangeMessage
import com.callvault.s24.ui.theme.SamsungPurpleRecord
import com.callvault.s24.ui.theme.SamsungRedMissed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Launches a direct phone call or dialer intent (Swipe Right gesture or Call button).
 */
fun placeCallIntent(context: Context, phoneNumber: String) {
    val uri = Uri.parse("tel:${Uri.encode(phoneNumber)}")
    val callIntent = Intent(Intent.ACTION_CALL, uri).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    runCatching { context.startActivity(callIntent) }.onFailure {
        val dialIntent = Intent(Intent.ACTION_DIAL, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(dialIntent)
    }
}

/**
 * Opens Samsung Messages / Google Messages directly to the thread for this contact (Swipe Left gesture or Message button).
 */
fun openMessagesIntent(context: Context, phoneNumber: String) {
    val uri = Uri.parse("smsto:${Uri.encode(phoneNumber)}")
    val smsIntent = Intent(Intent.ACTION_SENDTO, uri).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    runCatching { context.startActivity(smsIntent) }
}

fun formatDurationHuman(seconds: Long): String {
    if (seconds <= 0L) return "0s"
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return buildString {
        if (hrs > 0) append("${hrs}h ")
        if (mins > 0) append("${mins}m ")
        if (secs > 0 || isEmpty()) append("${secs}s")
    }.trim()
}

fun formatTimestamp(epochMillis: Long): String {
    if (epochMillis <= 0L) return "Never"
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    return sdf.format(Date(epochMillis))
}

/**
 * Tab 1: Unlimited Call Log Screen with Samsung One UI Gestures:
 * - Swipe Right -> Place Call (Green interactive reveal)
 * - Swipe Left  -> Send Message (Orange interactive reveal)
 * - Expandable row with Direct Call, Direct SMS, Disconnection Badge, and inline Call Recording player
 */
@Composable
fun UnlimitedCallLogScreen(
    calls: List<CallLogEntry>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    selectedFilter: Int,
    onFilterChange: (Int) -> Unit,
    onlyRecorded: Boolean,
    onToggleOnlyRecorded: () -> Unit,
    currentlyPlayingPath: String?,
    onTogglePlayRecording: (String) -> Unit,
    onSyncNow: () -> Unit
) {
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        // One UI-inspired Large Reachability Header
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Unlimited Call Vault",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${calls.size} calls preserved • Zero age or count limit",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
            IconButton(onClick = onSyncNow) {
                Icon(Icons.Default.Refresh, contentDescription = "Sync OS Call Log")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search name or number (4-5+ years history)...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(24.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val filters = listOf(
                0 to "All Calls",
                CallLog.Calls.INCOMING_TYPE to "Incoming",
                CallLog.Calls.OUTGOING_TYPE to "Outgoing",
                CallLog.Calls.MISSED_TYPE to "Missed",
                CallLog.Calls.REJECTED_TYPE to "Rejected"
            )
            items(filters) { (typeCode, label) ->
                FilterChip(
                    selected = selectedFilter == typeCode,
                    onClick = { onFilterChange(typeCode) },
                    label = { Text(label) }
                )
            }
            item {
                FilterChip(
                    selected = onlyRecorded,
                    onClick = onToggleOnlyRecorded,
                    label = { Text("Recorded Only") },
                    leadingIcon = {
                        Icon(
                            Icons.Default.GraphicEq,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Tip: Swipe right on any call to Dial • Swipe left to Message",
            style = MaterialTheme.typography.labelSmall,
            color = SamsungBlue
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            items(calls, key = { it.id }) { entry ->
                SamsungSwipeableCallCard(
                    entry = entry,
                    isPlaying = currentlyPlayingPath == entry.recordingFilePath && entry.recordingFilePath != null,
                    onCall = { placeCallIntent(context, entry.phoneNumber) },
                    onMessage = { openMessagesIntent(context, entry.phoneNumber) },
                    onPlayRecording = { path -> onTogglePlayRecording(path) }
                )
            }
        }
    }
}

@Composable
fun SamsungSwipeableCallCard(
    entry: CallLogEntry,
    isPlaying: Boolean,
    onCall: () -> Unit,
    onMessage: () -> Unit,
    onPlayRecording: (String) -> Unit
) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    var expanded by remember { mutableStateOf(false) }
    val swipeThreshold = 220f

    val bgColor by animateColorAsState(
        targetValue = when {
            offsetX > 60f -> SamsungGreenCall.copy(alpha = 0.85f)
            offsetX < -60f -> SamsungOrangeMessage.copy(alpha = 0.85f)
            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        },
        label = "swipeBg"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(bgColor)
    ) {
        // Background Gesture Action Indicators (Samsung One UI Swipe Reveal)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 22.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Call, contentDescription = "Swipe Right to Call", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Call", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Message", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.AutoMirrored.Filled.Message, contentDescription = "Swipe Left to Message", tint = Color.White)
            }
        }

        // Foreground Draggable One UI Card
        Card(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), 0) }
                .fillMaxWidth()
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        offsetX = (offsetX + delta).coerceIn(-340f, 340f)
                    },
                    onDragStopped = {
                        when {
                            offsetX >= swipeThreshold -> onCall()
                            offsetX <= -swipeThreshold -> onMessage()
                        }
                        offsetX = 0f
                    }
                )
                .clickable { expanded = !expanded },
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Call Type Icon Badge
                    val (icon, tint, typeLabel) = when (entry.callType) {
                        CallLog.Calls.INCOMING_TYPE -> Triple(Icons.AutoMirrored.Filled.CallReceived, SamsungBlue, "Incoming")
                        CallLog.Calls.OUTGOING_TYPE -> Triple(Icons.AutoMirrored.Filled.CallMade, SamsungGreenCall, "Outgoing")
                        CallLog.Calls.MISSED_TYPE -> Triple(Icons.AutoMirrored.Filled.CallMissed, SamsungRedMissed, "Missed")
                        CallLog.Calls.REJECTED_TYPE -> Triple(Icons.Default.Block, SamsungRedMissed, "Rejected")
                        else -> Triple(Icons.Default.Call, SamsungBlue, "Call")
                    }

                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(tint.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = typeLabel, tint = tint)
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = entry.contactName ?: entry.phoneNumber,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (entry.recordingFilePath != null) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    Icons.Default.Mic,
                                    contentDescription = "Recorded Call",
                                    tint = SamsungPurpleRecord,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        if (!entry.contactName.isNullOrBlank()) {
                            Text(
                                text = entry.phoneNumber,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                        Text(
                            text = "$typeLabel • ${formatTimestamp(entry.timestamp)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = formatDurationHuman(entry.durationSeconds),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = tint
                        )
                        if (entry.wasDisconnectedAbnormally || entry.disconnectCauseLabel != "NORMAL") {
                            Surface(
                                color = SamsungRedMissed.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Text(
                                    text = entry.disconnectCauseLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SamsungRedMissed,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                // Expanded Action Bar (Samsung Dialer Quick Actions + Recording Playback)
                if (expanded) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onCall,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Call")
                        }
                        OutlinedButton(
                            onClick = onMessage,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Message, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Message")
                        }
                        if (entry.recordingFilePath != null) {
                            Button(
                                onClick = { onPlayRecording(entry.recordingFilePath) },
                                modifier = Modifier.weight(1.2f),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(
                                    if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isPlaying) "Stop Audio" else "Play Rec")
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Tab 2: Detailed Call Log Analytics Dashboard
 * - Outgoing vs Incoming vs Missed vs Rejected vs Disconnected counts
 * - Total talk time & visual Donut chart
 * - Per-contact deep breakdown: total calls, talk duration, missed call count, and disconnection count
 */
@Composable
fun AnalyticsDashboardScreen(
    summary: CallSummaryStats,
    contactStats: List<ContactAnalyticsItem>,
    selectedRangeDays: Int,
    onRangeChange: (Int) -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 96.dp)
    ) {
        item {
            Text(
                text = "Call Intelligence & Analytics",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Evaluate multi-year talk time, missed call frequency & disconnections per contact",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }

        // Timeframe selector (All-Time Unlimited 5+ Years, 1 Year, 30 Days, 7 Days)
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val ranges = listOf(
                    0 to "All Time (Unlimited)",
                    365 to "Last 1 Year",
                    90 to "Last 90 Days",
                    30 to "Last 30 Days",
                    7 to "Last 7 Days"
                )
                items(ranges) { (days, label) ->
                    FilterChip(
                        selected = selectedRangeDays == days,
                        onClick = { onRangeChange(days) },
                        label = { Text(label) }
                    )
                }
            }
        }

        // Visual Ring Chart + Call Summary Card
        item {
            ElevatedCard(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Call Summary Overview",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        // Custom Compose Donut Chart
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(130.dp)) {
                            Canvas(modifier = Modifier.size(115.dp)) {
                                val total = summary.totalCalls.coerceAtLeast(1).toFloat()
                                val incSweep = (summary.incomingCalls / total) * 360f
                                val outSweep = (summary.outgoingCalls / total) * 360f
                                val misSweep = ((summary.missedCalls + summary.rejectedCalls) / total) * 360f

                                val strokeWidth = 28f
                                var startAngle = -90f

                                drawArc(
                                    color = SamsungBlue,
                                    startAngle = startAngle,
                                    sweepAngle = incSweep,
                                    useCenter = false,
                                    style = Stroke(width = strokeWidth, cap = StrokeCap.Butt),
                                    size = Size(size.width, size.height),
                                    topLeft = Offset.Zero
                                )
                                startAngle += incSweep
                                drawArc(
                                    color = SamsungGreenCall,
                                    startAngle = startAngle,
                                    sweepAngle = outSweep,
                                    useCenter = false,
                                    style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                )
                                startAngle += outSweep
                                drawArc(
                                    color = SamsungRedMissed,
                                    startAngle = startAngle,
                                    sweepAngle = misSweep,
                                    useCenter = false,
                                    style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${summary.totalCalls}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "Total Calls",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatLegendRow("Outgoing Calls", "${summary.outgoingCalls}", SamsungGreenCall)
                            StatLegendRow("Incoming Calls", "${summary.incomingCalls}", SamsungBlue)
                            StatLegendRow("Missed Calls", "${summary.missedCalls}", SamsungRedMissed)
                            StatLegendRow("Disconnected / Drops", "${summary.disconnectedDropCalls}", SamsungOrangeMessage)
                            StatLegendRow("Recorded Calls", "${summary.recordedCallsCount}", SamsungPurpleRecord)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Total Talk Duration Bar
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Total Talk Time", style = MaterialTheme.typography.labelMedium)
                                Text(
                                    formatDurationHuman(summary.totalDurationSeconds),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text("Outgoing Talk", style = MaterialTheme.typography.labelMedium)
                                Text(
                                    formatDurationHuman(summary.outgoingDurationSeconds),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SamsungGreenCall
                                )
                            }
                            Column {
                                Text("Incoming Talk", style = MaterialTheme.typography.labelMedium)
                                Text(
                                    formatDurationHuman(summary.incomingDurationSeconds),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SamsungBlue
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Per-Contact Talk Time, Missed & Disconnection Breakdown",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(contactStats, key = { it.normalizedNumber }) { item ->
            ElevatedCard(
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.contactName ?: item.displayNumber,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = item.displayNumber,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                        Row {
                            IconButton(onClick = { placeCallIntent(context, item.displayNumber) }) {
                                Icon(Icons.Default.Call, contentDescription = "Call", tint = SamsungGreenCall)
                            }
                            IconButton(onClick = { openMessagesIntent(context, item.displayNumber) }) {
                                Icon(Icons.AutoMirrored.Filled.Message, contentDescription = "Message", tint = SamsungOrangeMessage)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricPill("Total Talked", formatDurationHuman(item.totalDurationSeconds), SamsungBlue)
                        MetricPill("Total Calls", "${item.totalCalls}", MaterialTheme.colorScheme.primary)
                        MetricPill("Out / In", "${item.outgoingCount} / ${item.incomingCount}", SamsungGreenCall)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricPill("Missed Calls", "${item.missedCount} times", SamsungRedMissed)
                        MetricPill("Disconnected", "${item.disconnectedCount} times", SamsungOrangeMessage)
                        MetricPill("Avg Call", formatDurationHuman(item.averageDurationSeconds), SamsungPurpleRecord)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatLegendRow(label: String, value: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = "$label: ", style = MaterialTheme.typography.bodySmall)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MetricPill(label: String, value: String, accent: Color) {
    Surface(
        color = accent.copy(alpha = 0.1f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
            Text(
                text = value,
                style = MaterialTheme.typography.labelLarge,
                color = accent,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Tab 3: Samsung-Style Auto Call Recordings Vault & Hybrid Engine Controls (Option C)
 */
@Composable
fun CallRecordingsScreen(
    recordedCalls: List<CallLogEntry>,
    settings: UserSettings,
    currentlyPlayingPath: String?,
    onTogglePlay: (String) -> Unit,
    onToggleAutoRecord: (Boolean) -> Unit,
    onToggleHideNotification: (Boolean) -> Unit,
    onSelectEngineMode: (RecordingEngineMode) -> Unit,
    onRescanSamsungRecordings: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 96.dp)
    ) {
        item {
            Text(
                text = "Silent Call Recorder & Vault",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Samsung-style one-time toggle • Zero pre-call announcement • Silent background save",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }

        // Samsung-Style Recording Controls Card
        item {
            ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto-Record All Calls (Turn On Once)", fontWeight = FontWeight.Bold)
                            Text(
                                "Automatically records calls in the background with zero pre-call announcement",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(checked = settings.autoRecordEnabled, onCheckedChange = onToggleAutoRecord)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Hide 'Call Recording Saved' Notification", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Saves recordings silently to the list below without popping up status bar alerts",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(
                            checked = settings.hideRecordingSavedNotification,
                            onCheckedChange = onToggleHideNotification
                        )
                    }

                    Text(
                        text = "Galaxy S24 Ultra Recording Engine (Option C Hybrid):",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = SamsungBlue
                    )

                    RecordingEngineMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onSelectEngineMode(mode) }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            RadioButton(
                                selected = settings.recordingEngineMode == mode,
                                onClick = { onSelectEngineMode(mode) }
                            )
                            Column(modifier = Modifier.padding(start = 6.dp)) {
                                Text(mode.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    mode.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = onRescanSamsungRecordings,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Scan & Link Samsung Native Recordings (/Recordings/Call)")
                    }
                }
            }
        }

        item {
            Text(
                text = "Saved Call Recordings (${recordedCalls.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(recordedCalls, key = { it.id }) { call ->
            val path = call.recordingFilePath ?: return@items
            val isPlaying = currentlyPlayingPath == path

            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = call.contactName ?: call.phoneNumber,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${formatTimestamp(call.timestamp)} • ${formatDurationHuman(call.durationSeconds)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Source: ${call.recordingSource ?: "Audio Vault"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SamsungPurpleRecord
                        )
                    }
                    Button(
                        onClick = { onTogglePlay(path) },
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isPlaying) "Stop" else "Play")
                    }
                }
            }
        }
    }
}

/**
 * Tab 4: Per-Phone-Number Isolated Google Drive Backup & Multi-Device Restore Screen
 */
@Composable
fun BackupAndSettingsScreen(
    settings: UserSettings,
    availableBackups: List<RemotePhoneBackupSlot>,
    onSavePhoneNumber: (String) -> Unit,
    onConnectGoogleAccount: () -> Unit,
    onToggleAutoBackup: (Boolean) -> Unit,
    onBackupNow: () -> Unit,
    onRefreshBackups: () -> Unit,
    onRestoreSlot: (RemotePhoneBackupSlot) -> Unit,
    onRequestDefaultDialerRole: () -> Unit
) {
    var phoneInput by remember(settings.registeredPhoneNumber) {
        mutableStateOf(settings.registeredPhoneNumber)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 96.dp)
    ) {
        item {
            Text(
                text = "Multi-Phone Cloud Backup",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Per-Phone-Number Isolation: 5 phones on the same Google account will never overwrite each other's backups",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }

        // Per-Phone-Number Namespace Isolation Card
        item {
            ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.SimCard, contentDescription = null, tint = SamsungBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "This Phone's Dedicated Backup Number",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Backups on Google Drive are stored inside /CallVault_Unlimited_Backups/Phone_<YourNumber>/ so each SIM/device stays 100% separate.",
                        style = MaterialTheme.typography.bodySmall
                    )

                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Phone Number for This Device (e.g. +919876543210)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp)
                    )

                    Button(
                        onClick = { onSavePhoneNumber(phoneInput) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Save Phone Number Namespace")
                    }
                }
            }
        }

        // Google Drive Auto-Backup Card
        item {
            ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CloudDone, contentDescription = null, tint = SamsungGreenCall)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Google Drive Automatic Backup",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = if (settings.googleAccountEmail.isNotBlank())
                            "Connected Account: ${settings.googleAccountEmail}"
                        else
                            "No Google Account linked yet (Backups saved locally until connected)",
                        style = MaterialTheme.typography.bodySmall
                    )

                    if (settings.lastBackupTimestamp > 0L) {
                        Text(
                            text = "Last Backup: ${formatTimestamp(settings.lastBackupTimestamp)} → ${settings.lastBackupFolderName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SamsungBlue
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Scheduled Background Auto-Backup", fontWeight = FontWeight.SemiBold)
                            Text("Automatically backs up new calls via WorkManager", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = settings.autoDriveBackupEnabled, onCheckedChange = onToggleAutoBackup)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = onConnectGoogleAccount,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(if (settings.googleAccountEmail.isBlank()) "Link Google Drive" else "Switch Account")
                        }
                        Button(
                            onClick = onBackupNow,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Backup Now")
                        }
                    }
                }
            }
        }

        // Option C Default Dialer Role Switcher
        item {
            ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = SamsungOrangeMessage)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Default Dialer Role (Option C Hybrid Testing)", fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "Set CallVault Ultra as Default Dialer anytime to test built-in InCallService DisconnectCause tracking and Accessibility recording on your S24 Ultra.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedButton(
                        onClick = onRequestDefaultDialerRole,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Set / Test as Default Phone App")
                    }
                }
            }
        }

        // Restore Section: Shows every separate phone number's backup folder on Drive & Local
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Available Backups by Phone Number (${availableBackups.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onRefreshBackups) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh Backups")
                }
            }
        }

        items(availableBackups, key = { it.folderId }) { slot ->
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Phone: ${slot.phoneNumber}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(text = slot.folderName, style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = "Updated: ${formatTimestamp(slot.modifiedTimeMillis)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                    }
                    Button(
                        onClick = { onRestoreSlot(slot) },
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Restore")
                    }
                }
            }
        }
    }
}
