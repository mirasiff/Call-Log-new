package com.callvault.s24

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.callvault.s24.ui.MainViewModel
import com.callvault.s24.ui.screens.AnalyticsDashboardScreen
import com.callvault.s24.ui.screens.BackupAndSettingsScreen
import com.callvault.s24.ui.screens.CallRecordingsScreen
import com.callvault.s24.ui.screens.UnlimitedCallLogScreen
import com.callvault.s24.ui.theme.CallVaultTheme
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.services.drive.DriveScopes

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            CallVaultTheme {
                var currentTab by remember { mutableIntStateOf(0) }

                val calls by viewModel.filteredCallLogs.collectAsState()
                val recordedCalls by viewModel.recordedCalls.collectAsState()
                val summaryStats by viewModel.summaryStats.collectAsState()
                val contactStats by viewModel.contactAnalytics.collectAsState()
                val settings by viewModel.settings.collectAsState()
                val searchQuery by viewModel.searchQuery.collectAsState()
                val callTypeFilter by viewModel.callTypeFilter.collectAsState()
                val onlyRecorded by viewModel.onlyRecordedFilter.collectAsState()
                val analyticsRangeDays by viewModel.analyticsRangeDays.collectAsState()
                val statusBanner by viewModel.statusBanner.collectAsState()
                val currentlyPlayingPath by viewModel.currentlyPlayingPath.collectAsState()
                val availableBackups by viewModel.availableBackups.collectAsState()

                // Runtime Permission Launcher
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) {
                    viewModel.syncSystemCallLogNow()
                }

                // Google Sign-In Launcher for Per-Phone-Number Isolated Google Drive Backup
                val googleSignInLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                    runCatching {
                        val account = task.result
                        if (!account?.email.isNullOrBlank()) {
                            viewModel.updateGoogleAccountEmail(account!!.email!!)
                        }
                    }
                }

                // Default Dialer Role Launcher (for Option C Hybrid Testing)
                val dialerRoleLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) {
                    viewModel.syncSystemCallLogNow()
                }

                LaunchedEffect(Unit) {
                    val perms = mutableListOf(
                        Manifest.permission.READ_CALL_LOG,
                        Manifest.permission.WRITE_CALL_LOG,
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.RECORD_AUDIO
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        perms.add(Manifest.permission.READ_PHONE_NUMBERS)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.READ_MEDIA_AUDIO)
                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
                    }
                    permissionLauncher.launch(perms.toTypedArray())
                }

                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = currentTab == 0,
                                onClick = { currentTab = 0 },
                                icon = { Icon(Icons.Default.Call, contentDescription = "Recents") },
                                label = { Text("Call Log") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 1,
                                onClick = { currentTab = 1 },
                                icon = { Icon(Icons.Default.Analytics, contentDescription = "Analytics") },
                                label = { Text("Analytics") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 2,
                                onClick = { currentTab = 2 },
                                icon = { Icon(Icons.Default.GraphicEq, contentDescription = "Recordings") },
                                label = { Text("Recordings") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 3,
                                onClick = {
                                    currentTab = 3
                                    viewModel.refreshAvailableBackupSlots()
                                },
                                icon = { Icon(Icons.Default.Backup, contentDescription = "Backup") },
                                label = { Text("Drive Backup") }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            0 -> UnlimitedCallLogScreen(
                                calls = calls,
                                searchQuery = searchQuery,
                                onSearchChange = viewModel::setSearchQuery,
                                selectedFilter = callTypeFilter,
                                onFilterChange = viewModel::setCallTypeFilter,
                                onlyRecorded = onlyRecorded,
                                onToggleOnlyRecorded = viewModel::toggleOnlyRecordedFilter,
                                currentlyPlayingPath = currentlyPlayingPath,
                                onTogglePlayRecording = viewModel::togglePlayRecording,
                                onSyncNow = viewModel::syncSystemCallLogNow
                            )
                            1 -> AnalyticsDashboardScreen(
                                summary = summaryStats,
                                contactStats = contactStats,
                                selectedRangeDays = analyticsRangeDays,
                                onRangeChange = viewModel::setAnalyticsRangeDays
                            )
                            2 -> CallRecordingsScreen(
                                recordedCalls = recordedCalls,
                                settings = settings,
                                currentlyPlayingPath = currentlyPlayingPath,
                                onTogglePlay = viewModel::togglePlayRecording,
                                onToggleAutoRecord = viewModel::updateAutoRecord,
                                onToggleHideNotification = viewModel::updateHideRecordingNotification,
                                onSelectEngineMode = viewModel::updateRecordingEngineMode,
                                onRescanSamsungRecordings = viewModel::syncSystemCallLogNow
                            )
                            3 -> BackupAndSettingsScreen(
                                settings = settings,
                                availableBackups = availableBackups,
                                onSavePhoneNumber = viewModel::updateRegisteredPhoneNumber,
                                onConnectGoogleAccount = {
                                    val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                                        .requestEmail()
                                        .requestScopes(Scope(DriveScopes.DRIVE_FILE))
                                        .build()
                                    val client = GoogleSignIn.getClient(this@MainActivity, gso)
                                    googleSignInLauncher.launch(client.signInIntent)
                                },
                                onToggleAutoBackup = viewModel::updateAutoBackupEnabled,
                                onBackupNow = viewModel::triggerImmediateBackup,
                                onRefreshBackups = viewModel::refreshAvailableBackupSlots,
                                onRestoreSlot = viewModel::restoreFromSlot,
                                onRequestDefaultDialerRole = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        val roleManager = getSystemService(RoleManager::class.java)
                                        if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                                            dialerRoleLauncher.launch(
                                                roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
                                            )
                                        }
                                    } else {
                                        val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).apply {
                                            putExtra(
                                                TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME,
                                                packageName
                                            )
                                        }
                                        dialerRoleLauncher.launch(intent)
                                    }
                                }
                            )
                        }

                        if (statusBanner != null) {
                            Snackbar(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(16.dp),
                                action = {
                                    TextButton(onClick = viewModel::dismissBanner) {
                                        Text("OK")
                                    }
                                }
                            ) {
                                Text(statusBanner ?: "")
                            }
                        }
                    }
                }
            }
        }
    }
}
