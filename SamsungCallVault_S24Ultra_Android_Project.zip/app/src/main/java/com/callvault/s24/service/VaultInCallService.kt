package com.callvault.s24.service

import android.telecom.Call
import android.telecom.DisconnectCause
import android.telecom.InCallService
import com.callvault.s24.data.local.AppDatabase
import com.callvault.s24.data.local.AppPreferences
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.RecordingEngineMode
import com.callvault.s24.data.repository.CallLogRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Option C Hybrid Mode InCallService:
 * When the user sets CallVault Ultra as Default Dialer on their Galaxy S24 Ultra,
 * this service captures exact DisconnectCause codes (LOCAL_HANGUP, REMOTE_HANGUP, NETWORK_DROP, BUSY, REJECTED)
 * and triggers silent background call recording with zero pre-call announcement.
 */
class VaultInCallService : InCallService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            super.onStateChanged(call, state)
            val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
            val connectTime = call.details?.connectTimeMillis ?: System.currentTimeMillis()

            when (state) {
                Call.STATE_ACTIVE -> {
                    serviceScope.launch {
                        val settings = AppPreferences(applicationContext).settingsFlow.first()
                        if (settings.autoRecordEnabled &&
                            settings.recordingEngineMode != RecordingEngineMode.SAMSUNG_COMPANION
                        ) {
                            SilentCallRecorderManager.startSilentRecording(applicationContext, number)
                        }
                    }
                }
                Call.STATE_DISCONNECTED -> {
                    val disconnectCause = call.details?.disconnectCause
                    SilentCallRecorderManager.stopSilentRecording(applicationContext, connectTime)
                    recordDetailedDisconnectCause(call, disconnectCause)
                    call.unregisterCallback(this)
                }
            }
        }
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        call.registerCallback(callCallback)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        call.unregisterCallback(callCallback)
    }

    private fun recordDetailedDisconnectCause(call: Call, cause: DisconnectCause?) {
        serviceScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).callLogDao()
            val repo = CallLogRepository(applicationContext, dao)
            val settings = AppPreferences(applicationContext).settingsFlow.first()

            val number = call.details?.handle?.schemeSpecificPart ?: "Unknown"
            val creationMillis = call.details?.creationTimeMillis ?: System.currentTimeMillis()
            val connectMillis = call.details?.connectTimeMillis ?: 0L
            val durationSec = if (connectMillis > 0L) {
                ((System.currentTimeMillis() - connectMillis) / 1000L).coerceAtLeast(0L)
            } else 0L

            val causeCode = cause?.code ?: DisconnectCause.UNKNOWN
            val causeLabel = when (causeCode) {
                DisconnectCause.LOCAL -> "LOCAL_HANGUP"
                DisconnectCause.REMOTE -> "REMOTE_HANGUP"
                DisconnectCause.ERROR, DisconnectCause.CONNECTION_MANAGER_NOT_SUPPORTED -> "NETWORK_DROP"
                DisconnectCause.MISSED -> "MISSED"
                DisconnectCause.REJECTED -> "REJECTED"
                DisconnectCause.BUSY -> "BUSY"
                else -> "NORMAL"
            }

            val isAbnormalDrop = causeCode in listOf(
                DisconnectCause.ERROR,
                DisconnectCause.BUSY,
                DisconnectCause.REJECTED
            ) || (durationSec in 1..4 && causeCode == DisconnectCause.REMOTE)

            val isIncoming = call.details?.callDirection == Call.Details.DIRECTION_INCOMING
            val callType = when (causeCode) {
                DisconnectCause.MISSED -> 3
                DisconnectCause.REJECTED -> 5
                else -> if (isIncoming) 1 else 2
            }

            val entry = CallLogEntry(
                systemCallId = creationMillis,
                phoneNumber = number,
                normalizedNumber = repo.normalizePhoneNumber(number),
                contactName = call.details?.callerDisplayName?.takeIf { it.isNotBlank() },
                callType = callType,
                timestamp = creationMillis,
                durationSeconds = durationSec,
                devicePhoneNumber = settings.registeredPhoneNumber.ifBlank { repo.detectSimPhoneNumber() },
                disconnectCauseCode = causeCode,
                disconnectCauseLabel = causeLabel,
                wasDisconnectedAbnormally = isAbnormalDrop
            )
            dao.upsertCall(entry)
        }
    }
}
