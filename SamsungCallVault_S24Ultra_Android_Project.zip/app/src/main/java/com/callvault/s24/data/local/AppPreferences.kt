package com.callvault.s24.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.callvault.s24.data.model.RecordingEngineMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "callvault_s24_prefs")

data class UserSettings(
    val autoRecordEnabled: Boolean = true,
    val hideRecordingSavedNotification: Boolean = true,
    val suppressRecordingAnnouncement: Boolean = true,
    val recordingEngineMode: RecordingEngineMode = RecordingEngineMode.HYBRID_AUTO,
    val samsungRecordingsPath: String = "/storage/emulated/0/Recordings/Call",
    val registeredPhoneNumber: String = "",
    val autoDriveBackupEnabled: Boolean = true,
    val backupFrequencyHours: Long = 24L,
    val googleAccountEmail: String = "",
    val lastBackupTimestamp: Long = 0L,
    val lastBackupFolderName: String = ""
)

class AppPreferences(private val context: Context) {

    companion object {
        val AUTO_RECORD_ENABLED = booleanPreferencesKey("auto_record_enabled")
        val HIDE_RECORDING_NOTIFICATION = booleanPreferencesKey("hide_recording_notification")
        val SUPPRESS_ANNOUNCEMENT = booleanPreferencesKey("suppress_announcement")
        val RECORDING_ENGINE_MODE = stringPreferencesKey("recording_engine_mode")
        val SAMSUNG_RECORDINGS_PATH = stringPreferencesKey("samsung_recordings_path")
        val REGISTERED_PHONE_NUMBER = stringPreferencesKey("registered_phone_number")
        val AUTO_DRIVE_BACKUP_ENABLED = booleanPreferencesKey("auto_drive_backup_enabled")
        val BACKUP_FREQUENCY_HOURS = longPreferencesKey("backup_frequency_hours")
        val GOOGLE_ACCOUNT_EMAIL = stringPreferencesKey("google_account_email")
        val LAST_BACKUP_TIMESTAMP = longPreferencesKey("last_backup_timestamp")
        val LAST_BACKUP_FOLDER_NAME = stringPreferencesKey("last_backup_folder_name")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        val modeStr = prefs[RECORDING_ENGINE_MODE] ?: RecordingEngineMode.HYBRID_AUTO.name
        val mode = runCatching { RecordingEngineMode.valueOf(modeStr) }
            .getOrDefault(RecordingEngineMode.HYBRID_AUTO)

        UserSettings(
            autoRecordEnabled = prefs[AUTO_RECORD_ENABLED] ?: true,
            hideRecordingSavedNotification = prefs[HIDE_RECORDING_NOTIFICATION] ?: true,
            suppressRecordingAnnouncement = prefs[SUPPRESS_ANNOUNCEMENT] ?: true,
            recordingEngineMode = mode,
            samsungRecordingsPath = prefs[SAMSUNG_RECORDINGS_PATH] ?: "/storage/emulated/0/Recordings/Call",
            registeredPhoneNumber = prefs[REGISTERED_PHONE_NUMBER] ?: "",
            autoDriveBackupEnabled = prefs[AUTO_DRIVE_BACKUP_ENABLED] ?: true,
            backupFrequencyHours = prefs[BACKUP_FREQUENCY_HOURS] ?: 24L,
            googleAccountEmail = prefs[GOOGLE_ACCOUNT_EMAIL] ?: "",
            lastBackupTimestamp = prefs[LAST_BACKUP_TIMESTAMP] ?: 0L,
            lastBackupFolderName = prefs[LAST_BACKUP_FOLDER_NAME] ?: ""
        )
    }

    suspend fun setAutoRecordEnabled(enabled: Boolean) {
        context.dataStore.edit { it[AUTO_RECORD_ENABLED] = enabled }
    }

    suspend fun setHideRecordingNotification(hide: Boolean) {
        context.dataStore.edit { it[HIDE_RECORDING_NOTIFICATION] = hide }
    }

    suspend fun setRecordingEngineMode(mode: RecordingEngineMode) {
        context.dataStore.edit { it[RECORDING_ENGINE_MODE] = mode.name }
    }

    suspend fun setRegisteredPhoneNumber(phoneNumber: String) {
        context.dataStore.edit { it[REGISTERED_PHONE_NUMBER] = phoneNumber.trim() }
    }

    suspend fun setAutoDriveBackupEnabled(enabled: Boolean) {
        context.dataStore.edit { it[AUTO_DRIVE_BACKUP_ENABLED] = enabled }
    }

    suspend fun setBackupFrequencyHours(hours: Long) {
        context.dataStore.edit { it[BACKUP_FREQUENCY_HOURS] = hours }
    }

    suspend fun setGoogleAccountEmail(email: String) {
        context.dataStore.edit { it[GOOGLE_ACCOUNT_EMAIL] = email }
    }

    suspend fun updateLastBackupInfo(timestamp: Long, folderName: String) {
        context.dataStore.edit {
            it[LAST_BACKUP_TIMESTAMP] = timestamp
            it[LAST_BACKUP_FOLDER_NAME] = folderName
        }
    }
}
