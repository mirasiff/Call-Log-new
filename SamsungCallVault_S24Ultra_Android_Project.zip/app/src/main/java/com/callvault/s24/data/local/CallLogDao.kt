package com.callvault.s24.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.model.ContactAnalyticsItem
import kotlinx.coroutines.flow.Flow

@Dao
interface CallLogDao {

    @Query("SELECT * FROM unlimited_call_logs ORDER BY timestamp DESC")
    fun observeAllCalls(): Flow<List<CallLogEntry>>

    @Query("SELECT * FROM unlimited_call_logs ORDER BY timestamp DESC")
    suspend fun getAllCallsSnapshot(): List<CallLogEntry>

    @Query("""
        SELECT * FROM unlimited_call_logs
        WHERE (:callTypeFilter = 0 OR callType = :callTypeFilter)
          AND (:onlyRecorded = 0 OR recordingFilePath IS NOT NULL)
          AND (:searchQuery = '' OR phoneNumber LIKE '%' || :searchQuery || '%' OR contactName LIKE '%' || :searchQuery || '%')
        ORDER BY timestamp DESC
    """)
    fun observeFilteredCalls(
        callTypeFilter: Int,
        onlyRecorded: Int,
        searchQuery: String
    ): Flow<List<CallLogEntry>>

    @Query("SELECT * FROM unlimited_call_logs WHERE recordingFilePath IS NOT NULL ORDER BY timestamp DESC")
    fun observeRecordedCalls(): Flow<List<CallLogEntry>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCallsIgnoreDuplicate(calls: List<CallLogEntry>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCall(call: CallLogEntry): Long

    @Update
    suspend fun updateCall(call: CallLogEntry)

    @Query("SELECT MAX(timestamp) FROM unlimited_call_logs")
    suspend fun getLatestTimestamp(): Long?

    @Query("SELECT COUNT(*) FROM unlimited_call_logs")
    fun observeTotalCallCount(): Flow<Int>

    @Query("""
        UPDATE unlimited_call_logs
        SET recordingFilePath = :filePath, recordingSource = :source
        WHERE id = :callId
    """)
    suspend fun attachRecordingToCall(callId: Long, filePath: String, source: String)

    @Query("""
        SELECT * FROM unlimited_call_logs
        WHERE ABS(timestamp - :approxTimestamp) <= 180000
        ORDER BY ABS(timestamp - :approxTimestamp) ASC
        LIMIT 1
    """)
    suspend fun findClosestCallAroundTimestamp(approxTimestamp: Long): CallLogEntry?

    /**
     * Per-contact aggregated analytics:
     * - How many calls made to/from a particular contact
     * - How long talked to which person
     * - Which call has been missed how many times from which contact number
     * - Which call has been disconnected how many times
     */
    @Query("""
        SELECT 
            normalizedNumber AS normalizedNumber,
            MAX(phoneNumber) AS displayNumber,
            MAX(contactName) AS contactName,
            COUNT(*) AS totalCalls,
            SUM(CASE WHEN callType = 1 THEN 1 ELSE 0 END) AS incomingCount,
            SUM(CASE WHEN callType = 2 THEN 1 ELSE 0 END) AS outgoingCount,
            SUM(CASE WHEN callType = 3 THEN 1 ELSE 0 END) AS missedCount,
            SUM(CASE WHEN callType = 5 THEN 1 ELSE 0 END) AS rejectedCount,
            SUM(CASE WHEN wasDisconnectedAbnormally = 1 OR disconnectCauseLabel IN ('NETWORK_DROP', 'REMOTE_HANGUP', 'REJECTED', 'BUSY') THEN 1 ELSE 0 END) AS disconnectedCount,
            SUM(durationSeconds) AS totalDurationSeconds,
            CAST(AVG(CASE WHEN durationSeconds > 0 THEN durationSeconds ELSE NULL END) AS INTEGER) AS averageDurationSeconds,
            MAX(timestamp) AS lastCallTimestamp
        FROM unlimited_call_logs
        WHERE timestamp >= :sinceEpochMillis
        GROUP BY normalizedNumber
        ORDER BY totalDurationSeconds DESC, totalCalls DESC
    """)
    fun observeContactAnalytics(sinceEpochMillis: Long = 0L): Flow<List<ContactAnalyticsItem>>

    @Query("""
        SELECT * FROM unlimited_call_logs
        WHERE normalizedNumber = :normalizedNumber
        ORDER BY timestamp DESC
    """)
    fun observeCallsForContact(normalizedNumber: String): Flow<List<CallLogEntry>>
}
