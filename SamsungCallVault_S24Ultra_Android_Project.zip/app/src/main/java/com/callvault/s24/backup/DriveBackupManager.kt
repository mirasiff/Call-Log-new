package com.callvault.s24.backup

import android.content.Context
import android.os.Build
import com.callvault.s24.data.local.AppDatabase
import com.callvault.s24.data.local.AppPreferences
import com.callvault.s24.data.model.CallLogEntry
import com.callvault.s24.data.repository.CallLogRepository
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.ByteArrayContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale

@Serializable
data class VaultBackupPayload(
    val schemaVersion: Int = 2,
    val phoneNumberNamespace: String,
    val deviceModel: String,
    val exportedAtMillis: Long,
    val totalCalls: Int,
    val callLogs: List<CallLogEntry>
)

@Serializable
data class RemotePhoneBackupSlot(
    val folderId: String,
    val folderName: String,
    val phoneNumber: String,
    val latestFileId: String?,
    val latestFileName: String?,
    val modifiedTimeMillis: Long
)

class DriveBackupManager(private val context: Context) {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    companion object {
        private const val ROOT_FOLDER_NAME = "CallVault_Unlimited_Backups"
        private const val FOLDER_MIME = "application/vnd.google-apps.folder"
        private const val JSON_MIME = "application/json"
    }

    private fun buildDriveService(accountEmail: String): Drive? {
        if (accountEmail.isBlank()) return null
        val credential = GoogleAccountCredential.usingOAuth2(
            context,
            Collections.singleton(DriveScopes.DRIVE_FILE)
        ).apply {
            selectedAccountName = accountEmail
        }
        return Drive.Builder(
            NetHttpTransport(),
            GsonFactory.getDefaultInstance(),
            credential
        ).setApplicationName("CallVault").build()
    }

    suspend fun resolvePhoneNumberNamespace(
        prefs: AppPreferences,
        repo: CallLogRepository
    ): String {
        val settings = prefs.settingsFlow.first()
        val raw = settings.registeredPhoneNumber.ifBlank {
            repo.detectSimPhoneNumber()
        }.ifBlank {
            "Device_${Build.MODEL.replace(" ", "_")}"
        }
        val sanitized = raw.replace(Regex("[^0-9+A-Za-z_-]"), "")
        return "Phone_$sanitized"
    }

    suspend fun exportCsvForShare(): File = withContext(Dispatchers.IO) {
        val db = AppDatabase.getInstance(context)
        val repo = CallLogRepository(context, db.callLogDao())
        val calls = repo.getAllCallsForBackup()
        val exportsDir = File(context.filesDir, "exports").apply { mkdirs() }
        val file = File(exportsDir, "CallVault_CallLog_Export.csv")
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

        file.bufferedWriter().use { writer ->
            writer.write("DateTime,ContactName,PhoneNumber,Type,DurationSec,SIM,DisconnectReason,Recorded,Notes
")
            for (c in calls) {
                val typeStr = when (c.callType) {
                    1 -> "Incoming"
                    2 -> "Outgoing"
                    3 -> "Missed"
                    5 -> "Rejected"
                    else -> "Other"
                }
                val nameEsc = (c.contactName ?: "").replace(""", """")
                val noteEsc = (c.notes ?: "").replace(""", """").replace("
", " ")
                writer.write(
                    ""${sdf.format(Date(c.timestamp))}","$nameEsc","${c.phoneNumber}","$typeStr",${c.durationSeconds},"${c.simSlotLabel ?: "SIM 1"}","${c.disconnectCauseLabel}","${if (c.recordingFilePath != null) "Yes" else "No"}","$noteEsc"
"
                )
            }
        }
        file
    }

    suspend fun exportJsonForShare(): File = withContext(Dispatchers.IO) {
        val db = AppDatabase.getInstance(context)
        val prefs = AppPreferences(context)
        val repo = CallLogRepository(context, db.callLogDao())
        val calls = repo.getAllCallsForBackup()
        val phoneNamespace = resolvePhoneNumberNamespace(prefs, repo)
        val payload = VaultBackupPayload(
            schemaVersion = 2,
            phoneNumberNamespace = phoneNamespace,
            deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
            exportedAtMillis = System.currentTimeMillis(),
            totalCalls = calls.size,
            callLogs = calls
        )
        val exportsDir = File(context.filesDir, "exports").apply { mkdirs() }
        val file = File(exportsDir, "CallVault_Backup_$phoneNamespace.json")
        file.writeText(json.encodeToString(payload))
        file
    }

    suspend fun performBackupNow(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val db = AppDatabase.getInstance(context)
            val prefs = AppPreferences(context)
            val repo = CallLogRepository(context, db.callLogDao())
            val settings = prefs.settingsFlow.first()

            repo.syncSystemCallLogToUnlimitedVault(settings.registeredPhoneNumber)

            val allCalls = repo.getAllCallsForBackup()
            val phoneNamespace = resolvePhoneNumberNamespace(prefs, repo)
            val now = System.currentTimeMillis()
            val dateTag = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date(now))

            val payload = VaultBackupPayload(
                schemaVersion = 2,
                phoneNumberNamespace = phoneNamespace,
                deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
                exportedAtMillis = now,
                totalCalls = allCalls.size,
                callLogs = allCalls
            )

            val serializedJson = json.encodeToString(payload)
            val localDir = File(context.filesDir, "backups/$phoneNamespace").apply { mkdirs() }
            File(localDir, "CallVault_Latest_$phoneNamespace.json").writeText(serializedJson)

            val drive = buildDriveService(settings.googleAccountEmail)
            if (drive != null) {
                val rootFolderId = getOrCreateDriveFolder(drive, ROOT_FOLDER_NAME, null)
                val phoneFolderId = getOrCreateDriveFolder(drive, phoneNamespace, rootFolderId)
                upsertJsonFileInFolder(drive, phoneFolderId, "CallVault_Latest_$phoneNamespace.json", serializedJson)
                upsertJsonFileInFolder(drive, phoneFolderId, "CallVault_Snapshot_${phoneNamespace}_$dateTag.json", serializedJson)
                prefs.updateLastBackupInfo(now, "$ROOT_FOLDER_NAME/$phoneNamespace")
                "Backed up ${allCalls.size} calls to Google Drive ($ROOT_FOLDER_NAME/$phoneNamespace)"
            } else {
                prefs.updateLastBackupInfo(now, "Local/$phoneNamespace")
                "Saved ${allCalls.size} calls locally ($phoneNamespace)."
            }
        }
    }

    suspend fun listAvailablePhoneNumberBackups(): List<RemotePhoneBackupSlot> =
        withContext(Dispatchers.IO) {
            val slots = mutableListOf<RemotePhoneBackupSlot>()
            val prefs = AppPreferences(context)
            val settings = prefs.settingsFlow.first()

            runCatching {
                val drive = buildDriveService(settings.googleAccountEmail)
                if (drive != null) {
                    val rootId = findDriveFolderId(drive, ROOT_FOLDER_NAME, null)
                    if (rootId != null) {
                        val folderList = drive.files().list()
                            .setQ("'$rootId' in parents and mimeType = '$FOLDER_MIME' and trashed = false")
                            .setFields("files(id, name, modifiedTime)")
                            .execute()

                        for (folder in folderList.files.orEmpty()) {
                            val filesInPhoneFolder = drive.files().list()
                                .setQ("'${folder.id}' in parents and mimeType = '$JSON_MIME' and trashed = false")
                                .setOrderBy("modifiedTime desc")
                                .setFields("files(id, name, modifiedTime)")
                                .execute()

                            val latestFile = filesInPhoneFolder.files?.firstOrNull()
                            slots.add(
                                RemotePhoneBackupSlot(
                                    folderId = folder.id,
                                    folderName = "Google Drive: ${folder.name}",
                                    phoneNumber = folder.name.removePrefix("Phone_"),
                                    latestFileId = latestFile?.id,
                                    latestFileName = latestFile?.name,
                                    modifiedTimeMillis = latestFile?.modifiedTime?.value ?: System.currentTimeMillis()
                                )
                            )
                        }
                    }
                }
            }

            val localRoot = File(context.filesDir, "backups")
            localRoot.listFiles()?.filter { it.isDirectory }?.forEach { dir ->
                val latestLocal = dir.listFiles { f -> f.extension == "json" }?.maxByOrNull { it.lastModified() }
                if (latestLocal != null) {
                    slots.add(
                        RemotePhoneBackupSlot(
                            folderId = "LOCAL:${dir.name}",
                            folderName = "Local Storage: ${dir.name}",
                            phoneNumber = dir.name.removePrefix("Phone_"),
                            latestFileId = latestLocal.absolutePath,
                            latestFileName = latestLocal.name,
                            modifiedTimeMillis = latestLocal.lastModified()
                        )
                    )
                }
            }
            slots
        }

    suspend fun restoreFromBackupSlot(slot: RemotePhoneBackupSlot): Result<Int> =
        withContext(Dispatchers.IO) {
            runCatching {
                val db = AppDatabase.getInstance(context)
                val repo = CallLogRepository(context, db.callLogDao())
                val prefs = AppPreferences(context)
                val settings = prefs.settingsFlow.first()

                val rawJson = if (slot.folderId.startsWith("LOCAL:")) {
                    File(slot.latestFileId ?: error("No backup file found")).readText()
                } else {
                    val drive = buildDriveService(settings.googleAccountEmail)
                        ?: error("Google Drive account not connected")
                    val fileId = slot.latestFileId ?: error("No remote backup file in folder")
                    val out = ByteArrayOutputStream()
                    drive.files().get(fileId).executeMediaAndDownloadTo(out)
                    out.toString("UTF-8")
                }

                val payload = json.decodeFromString<VaultBackupPayload>(rawJson)
                repo.restoreCallsFromBackup(payload.callLogs)
            }
        }

    private fun findDriveFolderId(drive: Drive, name: String, parentId: String?): String? {
        val parentQuery = if (parentId != null) "'$parentId' in parents and " else ""
        val query = "${parentQuery}mimeType = '$FOLDER_MIME' and name = '$name' and trashed = false"
        return drive.files().list().setQ(query).setFields("files(id, name)").execute().files?.firstOrNull()?.id
    }

    private fun getOrCreateDriveFolder(drive: Drive, name: String, parentId: String?): String {
        findDriveFolderId(drive, name, parentId)?.let { return it }
        val meta = com.google.api.services.drive.model.File().apply {
            this.name = name
            this.mimeType = FOLDER_MIME
            if (parentId != null) this.parents = listOf(parentId)
        }
        return drive.files().create(meta).setFields("id").execute().id
    }

    private fun upsertJsonFileInFolder(drive: Drive, folderId: String, fileName: String, jsonContent: String) {
        val query = "'$folderId' in parents and name = '$fileName' and trashed = false"
        val existing = drive.files().list().setQ(query).setFields("files(id)").execute().files?.firstOrNull()
        val mediaContent = ByteArrayContent.fromString(JSON_MIME, jsonContent)
        if (existing != null) {
            drive.files().update(existing.id, null, mediaContent).execute()
        } else {
            val meta = com.google.api.services.drive.model.File().apply {
                name = fileName
                mimeType = JSON_MIME
                parents = listOf(folderId)
            }
            drive.files().create(meta, mediaContent).setFields("id").execute()
        }
    }
}
